"""Standard response envelope for every agent-facing tool.

Every tool returns a dict matching this schema::

    {
        "status": "ok" | "not_found" | "ambiguous" | "error",
        "data": <tool-specific payload>,
        "confidence": 0.0-1.0 | None,
        "confidence_basis": "short string explaining the score",
        "sources": [{"doc_id": str, "page": int|None,
                     "clause_ref": str|None, "as_of_date": str|None}],
        "ambiguity_note": str | None,
    }

Builder functions enforce the schema so individual tools never
produce malformed envelopes.
"""

from __future__ import annotations

from typing import Any


# ---------------------------------------------------------------------------
# Source helper
# ---------------------------------------------------------------------------

def make_source(
    doc_id: str,
    page: int | None = None,
    clause_ref: str | None = None,
    as_of_date: str | None = None,
) -> dict:
    """Build a single source citation dict."""
    return {
        "doc_id": str(doc_id),
        "page": page,
        "clause_ref": clause_ref,
        "as_of_date": as_of_date,
    }


# ---------------------------------------------------------------------------
# Confidence helpers
# ---------------------------------------------------------------------------

def clamp_confidence(value: float | None) -> float | None:
    """Clamp a confidence score to [0.0, 1.0] or return None."""
    if value is None:
        return None
    return max(0.0, min(1.0, float(value)))


# ---------------------------------------------------------------------------
# Envelope builders
# ---------------------------------------------------------------------------

def ok(
    data: Any,
    confidence: float | None = None,
    confidence_basis: str = "",
    sources: list[dict] | None = None,
) -> dict:
    """Successful response."""
    return {
        "status": "ok",
        "data": data,
        "confidence": clamp_confidence(confidence),
        "confidence_basis": confidence_basis,
        "sources": sources or [],
        "ambiguity_note": None,
    }


def not_found(
    message: str = "No matching record found.",
    confidence: float | None = None,
    confidence_basis: str = "",
    sources: list[dict] | None = None,
) -> dict:
    """Nothing matched — do not fabricate."""
    return {
        "status": "not_found",
        "data": {"message": message},
        "confidence": clamp_confidence(confidence),
        "confidence_basis": confidence_basis,
        "sources": sources or [],
        "ambiguity_note": None,
    }


def ambiguous(
    candidates: list[Any],
    note: str,
    confidence: float | None = None,
    confidence_basis: str = "",
    sources: list[dict] | None = None,
) -> dict:
    """Multiple plausible matches — do not guess."""
    return {
        "status": "ambiguous",
        "data": {"candidates": candidates},
        "confidence": clamp_confidence(confidence),
        "confidence_basis": confidence_basis,
        "sources": sources or [],
        "ambiguity_note": note,
    }


def error(
    message: str,
    sources: list[dict] | None = None,
) -> dict:
    """Internal error — surface the message, never fabricate data."""
    return {
        "status": "error",
        "data": {"error": message},
        "confidence": None,
        "confidence_basis": "",
        "sources": sources or [],
        "ambiguity_note": None,
    }
