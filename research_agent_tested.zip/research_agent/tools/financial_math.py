"""Shared deterministic financial math for the research_agent.

Every ratio, percentage, growth and arithmetic result comes from here —
computed in Python, never by the LLM. Exposed as the ``calculate`` tool.

The safe expression evaluator supports: ``+ - * / ** %``, parentheses,
named variables, and the functions ``abs, round, min, max, sum``.
"""

from __future__ import annotations

import ast
import math
import operator
import re

Number = int | float

# ---------------------------------------------------------------------------
# Core operations
# ---------------------------------------------------------------------------


def ratio(num: Number | None, den: Number | None, ndigits: int | None = 4) -> float | None:
    """num / den, rounded; None when the denominator is zero/None/invalid."""
    if den in (0, 0.0, None) or num is None:
        return None
    try:
        r = float(num) / float(den)
    except (TypeError, ValueError, ZeroDivisionError):
        return None
    return round(r, ndigits) if ndigits is not None else r


def pct_change(current: Number | None, prior: Number | None, ndigits: int | None = 2) -> float | None:
    """(current - prior) / |prior| * 100; None when prior is zero/None."""
    if prior in (0, 0.0, None) or current is None:
        return None
    try:
        r = (float(current) - float(prior)) / abs(float(prior)) * 100
    except (TypeError, ValueError, ZeroDivisionError):
        return None
    return round(r, ndigits) if ndigits is not None else r


def variance(current: Number | None, prior: Number | None, ndigits: int | None = 2) -> float | None:
    """Absolute change current - prior."""
    if current is None or prior is None:
        return None
    r = float(current) - float(prior)
    return round(r, ndigits) if ndigits is not None else r


def growth(current: Number | None, prior: Number | None, ndigits: int | None = 2) -> float | None:
    """Alias of pct_change (period-over-period growth %)."""
    return pct_change(current, prior, ndigits)


def cagr(begin: Number | None, end: Number | None, years: Number | None,
         ndigits: int | None = 2) -> float | None:
    """Compound annual growth rate %; None if inputs are non-positive/invalid."""
    try:
        b, e, n = float(begin), float(end), float(years)
    except (TypeError, ValueError):
        return None
    if b <= 0 or e <= 0 or n <= 0:
        return None
    r = (math.pow(e / b, 1.0 / n) - 1.0) * 100
    return round(r, ndigits) if ndigits is not None else r


def common_size(part: Number | None, whole: Number | None, ndigits: int | None = 2) -> float | None:
    """part / whole * 100 (common-size %); None when whole is zero/None."""
    r = ratio(part, whole, ndigits=None)
    return round(r * 100, ndigits) if r is not None and ndigits is not None else (
        r * 100 if r is not None else None)


# ---------------------------------------------------------------------------
# Safe expression evaluator  (used by the ``calculate`` tool)
# ---------------------------------------------------------------------------

_SAFE_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

_SAFE_FUNCS = {
    "abs": abs,
    "round": round,
    "min": min,
    "max": max,
    "sum": sum,
}

_NUMBER_WITH_COMMAS = re.compile(r"(\d{1,3}(?:,\d{2,3})+(?:\.\d+)?)")


def _strip_commas(expr: str) -> str:
    """Remove commas from Indian/Western formatted numbers in the expression."""
    return _NUMBER_WITH_COMMAS.sub(lambda m: m.group(0).replace(",", ""), expr)


def _eval_node(node: ast.AST, variables: dict[str, float]) -> float:
    """Recursively evaluate an AST node safely."""
    if isinstance(node, ast.Expression):
        return _eval_node(node.body, variables)
    if isinstance(node, ast.Constant):
        if isinstance(node.value, int):
            return int(node.value)
        if isinstance(node.value, float):
            return float(node.value)
        raise ValueError(f"unsupported constant: {node.value!r}")
    if isinstance(node, ast.Name):
        if node.id in variables:
            return variables[node.id]
        raise ValueError(f"undefined variable: {node.id}")
    if isinstance(node, ast.UnaryOp):
        op = _SAFE_OPS.get(type(node.op))
        if op is None:
            raise ValueError(f"unsupported unary op: {type(node.op).__name__}")
        return op(_eval_node(node.operand, variables))
    if isinstance(node, ast.BinOp):
        op = _SAFE_OPS.get(type(node.op))
        if op is None:
            raise ValueError(f"unsupported binary op: {type(node.op).__name__}")
        left = _eval_node(node.left, variables)
        right = _eval_node(node.right, variables)
        return op(left, right)
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id in _SAFE_FUNCS:
            args = [_eval_node(a, variables) for a in node.args]
            return _SAFE_FUNCS[node.func.id](*args)
        raise ValueError(f"unsupported function: {ast.dump(node.func)}")
    raise ValueError(f"unsupported expression node: {type(node).__name__}")


def evaluate(expression: str, variables: dict | None = None) -> dict:
    """Evaluate a math expression safely and return a result dict.

    Returns ``{"result": float, "basis": str}`` on success or
    ``{"error": str}`` on failure.
    """
    variables = {k: float(v) for k, v in (variables or {}).items()}
    expr = _strip_commas(expression.strip())

    # Substitute variable values into the expression string for the basis
    basis_expr = expr
    for name, val in variables.items():
        basis_expr = re.sub(rf"\b{re.escape(name)}\b", str(val), basis_expr)

    try:
        tree = ast.parse(expr, mode="eval")
        result = _eval_node(tree, variables)
        if isinstance(result, float) and (math.isnan(result) or math.isinf(result)):
            return {"error": f"result is {result}"}
        result = round(result, 10)
        return {"result": result, "basis": f"{basis_expr} = {result}"}
    except ZeroDivisionError:
        return {"error": "division by zero"}
    except Exception as exc:
        return {"error": str(exc)}
