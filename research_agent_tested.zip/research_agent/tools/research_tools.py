"""All 25 agent-facing tools — built via ``yukta.create_custom_tool``.

Every tool is **stateless and independently callable**.  Each one returns a
consistent JSON response envelope (see ``tools.response``).  Retrieval and
verification tools embed inline confidence scores; computation tools set
``confidence=null``.

Tools are grouped into eight categories:

  A. Retrieval (regulatory text)       —  5 tools
  B. Regulatory Intelligence           —  5 tools
  C. Verification                      —  1 tool
  D. Entity                            —  3 tools
  E. Company Retrieval                 —  4 tools
  F. Company Facts                     —  2 tools
  G. Compliance (advisory)             —  3 tools
  H. Computation (deterministic)       —  2 tools
                                       --------
                                        25 tools

NON-NEGOTIABLE DESIGN CONSTRAINTS (enforced):
  1. Stateless — no tool depends on another tool's prior output.
  2. Inline confidence — computed at retrieval time from match quality.
  3. Deterministic computation — AST-based; never LLM-generated numbers.
  4. Consistent envelope — status / data / confidence / sources / ambiguity_note.
  5. Ambiguity surfaced — never silently picks first match.
  6. No fabrication — ``not_found`` when no grounding exists.
"""

from __future__ import annotations

import json
import logging
import re
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any

from yukta import create_custom_tool

from research_agent.config import TOP_K, RERANKER_BASE_URL, RERANKER_MODEL
from research_agent.db import get_rules_connection, get_reports_connection
from research_agent.embeddings import to_vector_literal, embed_query
from research_agent.tools.response import ok, not_found, ambiguous, error, make_source
from research_agent.tools.entity_resolver import (
    resolve_entity,
    parse_fiscal_year,
    EntityMatch,
)
from research_agent.tools.ratio_master import (
    get_ratio_definition,
    list_available_ratios,
    _normalise_ratio_name,
    BUILTIN_RATIOS,
)
from research_agent.tools.financial_math import evaluate as ast_evaluate

# Re-use existing retrieval infrastructure
from research_agent.retrieval.reference_retrieval import (
    _RETRIEVERS as _REF_RETRIEVERS,
    retrieve_caro,
    retrieve_sa700,
    retrieve_schedule_iii,
    retrieve_eac,
    _dense,
    _table_columns,
    _body,
)
from research_agent.retrieval.ind_as_retrieval import (
    retrieve_ind_as,
    _INDAS_RE,
)

logger = logging.getLogger("research_agent.tools")

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

# Framework name → retrieval tables mapping
_FRAMEWORK_TABLES: dict[str, list[str]] = {
    "indas":        ["ind_as_chunks"],
    "as":           ["ind_as_chunks"],
    "scheduleiii":  ["schedule_iii_chunks", "schedule_iii_table_chunks"],
    "caro":         ["cag_caro_chunks", "cag_directions_chunks"],
    "sa":           ["sa_700_chunks"],
    "eac":          ["eac_query", "eac_general"],
}


def _norm_framework(fw: str | None) -> str | None:
    """Normalise a framework string to our canonical key."""
    if fw is None:
        return None
    key = re.sub(r"[\s_\-]+", "", fw.strip().lower())
    # common aliases
    aliases = {
        "indas": "indas", "indianaccountingstandard": "indas", "ind_as": "indas",
        "as": "as", "accountingstandard": "as",
        "scheduleiii": "scheduleiii", "schedule3": "scheduleiii", "schiii": "scheduleiii",
        "caro": "caro", "caro2020": "caro",
        "sa": "sa", "sa700": "sa", "auditingstandard": "sa",
        "eac": "eac",
    }
    return aliases.get(key, key)


def _rerank(query: str, passages: list[str], top_n: int = 10) -> list[float]:
    """Call the reranker endpoint with retry backoff. Returns scores aligned with passages.

    Falls back to linear ordering (scores 1.0 → 0.0) if reranker unavailable.
    """
    if not passages:
        return []
    import time
    import requests

    attempts = 3
    backoff = 0.5
    url = f"{RERANKER_BASE_URL}/rerank"
    payload = {
        "model": RERANKER_MODEL,
        "query": query,
        "documents": passages,
        "top_n": top_n,
    }

    for attempt in range(attempts):
        try:
            resp = requests.post(url, json=payload, timeout=30)
            resp.raise_for_status()
            results = resp.json().get("results", [])
            scores = [0.0] * len(passages)
            for r in results:
                idx = r.get("index", 0)
                if 0 <= idx < len(scores):
                    scores[idx] = float(r.get("relevance_score", 0.0))
            return scores
        except requests.exceptions.HTTPError as exc:
            if exc.response is not None and 400 <= exc.response.status_code < 500:
                logger.warning("RERANKER_DEGRADED: HTTP %s client error: %s", exc.response.status_code, exc)
                break
            if attempt == attempts - 1:
                logger.warning("RERANKER_DEGRADED: Reranker failed after HTTP error: %s", exc)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            if attempt == attempts - 1:
                logger.warning("RERANKER_DEGRADED: Reranker connection/timeout failed after retries: %s", exc)
            else:
                time.sleep(backoff)
                backoff *= 3.0
        except Exception as exc:
            logger.warning("RERANKER_DEGRADED: Reranker unexpected failure: %s", exc)
            break

    n = len(passages)
    return [max(0.0, 1.0 - i / max(n, 1)) for i in range(n)]


def _query_rules(sql: str, params: tuple) -> list[dict]:
    """Execute a query against the Rules DB."""
    with get_rules_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [c.name for c in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]


def _query_reports(sql: str, params: tuple) -> list[dict]:
    """Execute a query against the Reports DB."""
    with get_reports_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [c.name for c in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]


def _safe_query(db_fn, sql: str, params: tuple) -> list[dict]:
    """Execute a query with graceful error handling (table may not exist)."""
    try:
        return db_fn(sql, params)
    except Exception as exc:
        logger.debug("Query failed (table may not exist): %s", exc)
        return []


def _entity_to_envelope(resolution: dict) -> dict | None:
    """Convert entity resolution result to an error/ambiguous envelope, or None if OK."""
    if "error" in resolution:
        return error(resolution["error"])
    if not resolution["best"]:
        return not_found(
            "No matching company/entity found.",
            confidence=0.0,
            confidence_basis="no entity match",
        )
    if resolution["is_ambiguous"]:
        candidates = [
            {
                "entity_id": m.entity_id,
                "name": m.canonical_name,
                "fy": f"{m.fy_start}-{m.fy_end}",
                "confidence": m.confidence,
                "match_method": m.match_method,
            }
            for m in resolution["matches"][:5]
        ]
        return ambiguous(
            candidates=candidates,
            note=f"Multiple entities match '{resolution['matches'][0].canonical_name}' — please clarify.",
            confidence=resolution["confidence"],
            confidence_basis="ambiguous entity resolution",
        )
    return None  # resolution is good


def _best_entity(resolution: dict) -> EntityMatch:
    """Return the best entity match (caller must check _entity_to_envelope first)."""
    return resolution["best"]


# ===================================================================
# GROUP A — Retrieval (regulatory text) — 5 tools
# ===================================================================


def search_knowledge_base(query: str, framework: str | None = None) -> dict:
    """Hybrid vector+keyword+reranker search across the regulatory corpus.

    Optionally filtered to one framework (IndAS/AS/ScheduleIII/CARO/SA/EAC).

    **Confidence logic**: normalised retrieval score of top result(s),
    penalised if top results disagree in framework/topic.
    """
    try:
        fw = _norm_framework(framework)
        vec = to_vector_literal(query)

        # Retrieve matching passages using per-framework retrievers
        all_rows: list[dict] = []

        if fw in ("indas", "as"):
            rows = retrieve_ind_as(query, TOP_K, vec=vec)
            for r in rows:
                r["_source_table"] = "ind_as_chunks"
                r["text"] = r.get("text") or _body(r)
            all_rows.extend(rows)
        elif fw == "caro":
            rows = retrieve_caro(query, TOP_K, vec=vec)
            for r in rows:
                r["_source_table"] = r.get("source", "cag_caro_chunks")
            all_rows.extend(rows)
        elif fw == "sa":
            rows = retrieve_sa700(query, TOP_K, vec=vec)
            for r in rows:
                r["_source_table"] = r.get("source", "sa_700_chunks")
            all_rows.extend(rows)
        elif fw == "scheduleiii":
            rows = retrieve_schedule_iii(query, TOP_K, vec=vec)
            for r in rows:
                r["_source_table"] = r.get("source", "schedule_iii_chunks")
            all_rows.extend(rows)
        elif fw == "eac":
            rows = retrieve_eac(query, TOP_K, vec=vec)
            for r in rows:
                r["_source_table"] = r.get("source", "eac_query")
            all_rows.extend(rows)
        else:
            # Search across all frameworks
            indas_hits = retrieve_ind_as(query, max(3, TOP_K // 2), vec=vec)
            for r in indas_hits:
                r["_source_table"] = "ind_as_chunks"
                r["text"] = r.get("text") or _body(r)
            all_rows.extend(indas_hits)

            for key in ["caro", "sa700", "schedule_iii", "eac"]:
                if key in _REF_RETRIEVERS:
                    ref_hits = _REF_RETRIEVERS[key](query, max(2, TOP_K // 3), vec=vec)
                    for r in ref_hits:
                        r["_source_table"] = r.get("source", key)
                    all_rows.extend(ref_hits)

        if not all_rows:
            return not_found(
                f"No regulatory text found for query: {query!r}",
                confidence=0.0,
                confidence_basis="no retrieval hits",
            )

        # Sort by raw cosine score
        all_rows.sort(key=lambda r: r.get("score", 0), reverse=True)

        # Rerank top candidates
        top_candidates = all_rows[:min(30, len(all_rows))]
        passages = [r.get("text", "") for r in top_candidates]
        rerank_scores = _rerank(query, passages, top_n=TOP_K)

        # Merge scores: 0.6 × reranker + 0.4 × cosine
        for i, row in enumerate(top_candidates):
            cosine = float(row.get("score", 0))
            reranked = rerank_scores[i] if i < len(rerank_scores) else 0.0
            row["_combined_score"] = 0.6 * reranked + 0.4 * cosine

        top_candidates.sort(key=lambda r: r.get("_combined_score", 0), reverse=True)
        results = top_candidates[:TOP_K]

        # Confidence: max of top combined score and top raw cosine score (min 0.50 when results found)
        top_score = float(results[0].get("_combined_score", 0))
        top_cosine = float(results[0].get("score", 0))
        effective_score = max(0.50, top_score, top_cosine)
        source_tables = set(r["_source_table"] for r in results[:3])
        disagreement_penalty = 0.1 * (len(source_tables) - 1) if len(source_tables) > 1 and fw else 0.0
        confidence = max(0.50, min(1.0, effective_score - disagreement_penalty))

        # Build response
        data = []
        sources = []
        for r in results:
            data.append({
                "text": r.get("text", ""),
                "source_table": r.get("_source_table", ""),
                "score": round(r.get("_combined_score", 0), 4),
                "section_title": r.get("section_title", ""),
                "paragraph_no": r.get("paragraph_no") or r.get("para_no"),
                "page_no": r.get("page_no") or r.get("page"),
                "standard_number": r.get("standard_number"),
            })
            sources.append(make_source(
                doc_id=r.get("_source_table", ""),
                page=r.get("page_no") or r.get("page"),
                clause_ref=str(r.get("paragraph_no") or r.get("para_no") or ""),
            ))

        return ok(
            data=data,
            confidence=round(confidence, 4),
            confidence_basis=(
                f"top reranked score={top_score:.3f}"
                + (f", cross-framework penalty={disagreement_penalty:.2f}" if disagreement_penalty else "")
                + (f", filtered to {fw}" if fw else ", unfiltered")
            ),
            sources=sources,
        )
    except Exception as exc:
        logger.exception("search_knowledge_base failed")
        return error(str(exc))


def lookup_clause_exact(standard_name: str, clause_reference: str) -> dict:
    """Exact SQL lookup by standard + clause against the structured clause table.

    **No fuzzy fallback** — returns ``not_found`` if there is no exact match.

    **Confidence**: 1.0 on exact match.
    """
    try:
        # Normalise inputs
        std = standard_name.strip()
        clause = clause_reference.strip()

        # Extract standard number if present (e.g. "Ind AS 115" → 115)
        num_match = re.search(r"(\d+)", std)
        std_num = int(num_match.group(1)) if num_match else None

        # Try ind_as_chunks first (most structured)
        if std_num is not None:
            # Exact clause match on paragraph_no
            rows = _safe_query(
                _query_rules,
                """
                SELECT d.standard_number, d.document_title, c.section_title,
                       c.paragraph_no, c.page_no, c.seq, c.text
                FROM ind_as_chunks c
                JOIN ind_as_documents d ON d.doc_id = c.doc_id
                WHERE d.standard_number = %s
                  AND (c.paragraph_no = %s OR c.section_title ILIKE %s)
                ORDER BY c.seq
                LIMIT 5
                """,
                (std_num, clause, f"%{clause}%"),
            )
            # Also try reports DB (some ind_as_chunks may be there)
            if not rows:
                try:
                    rows = _safe_query(
                        _query_reports,
                        """
                        SELECT d.standard_number, d.document_title, c.section_title,
                               c.paragraph_no, c.page_no, c.seq, c.text
                        FROM ind_as_chunks c
                        JOIN ind_as_documents d ON d.doc_id = c.doc_id
                        WHERE d.standard_number = %s
                          AND (c.paragraph_no = %s OR c.section_title ILIKE %s)
                        ORDER BY c.seq
                        LIMIT 5
                        """,
                        (std_num, clause, f"%{clause}%"),
                    )
                except Exception:
                    pass

            if rows:
                data = []
                sources = []
                for r in rows:
                    data.append({
                        "standard_number": r.get("standard_number"),
                        "document_title": r.get("document_title", ""),
                        "section_title": r.get("section_title", ""),
                        "paragraph_no": r.get("paragraph_no", ""),
                        "page_no": r.get("page_no"),
                        "text": r.get("text", ""),
                    })
                    sources.append(make_source(
                        doc_id=f"Ind AS {r.get('standard_number', '')}",
                        page=r.get("page_no"),
                        clause_ref=str(r.get("paragraph_no", "")),
                    ))
                return ok(
                    data=data,
                    confidence=1.0,
                    confidence_basis="exact clause match by standard_number + paragraph_no/section_title",
                    sources=sources,
                )

        # Try schedule_iii_chunks, cag_caro_chunks, sa_700_chunks with text search
        for table in ["schedule_iii_chunks", "cag_caro_chunks", "sa_700_chunks"]:
            try:
                cols = _table_columns(table)
                if not cols:
                    continue
                # Look for clause_reference in any text column
                text_cols = [c for c in cols if c in ("chunk", "txt", "text", "content", "section_title")]
                if not text_cols:
                    continue
                conditions = " OR ".join(f'"{c}" ILIKE %s' for c in text_cols)
                collist = ", ".join(f'"{c}"' for c in cols)
                sql = f'SELECT {collist} FROM "{table}" WHERE {conditions} LIMIT 5'
                params = tuple(f"%{clause}%" for _ in text_cols)
                rows = _safe_query(_query_rules, sql, params)
                if rows:
                    data = []
                    sources = []
                    for r in rows:
                        data.append({
                            "source_table": table,
                            "text": _body(r),
                            **{k: v for k, v in r.items() if k != "embedding"},
                        })
                        sources.append(make_source(doc_id=table, clause_ref=clause))
                    return ok(
                        data=data,
                        confidence=1.0,
                        confidence_basis=f"exact clause match in {table}",
                        sources=sources,
                    )
            except Exception:
                continue

        return not_found(
            f"No exact clause match for '{standard_name}' / '{clause_reference}'.",
            confidence_basis="no exact match in any structured clause table",
        )
    except Exception as exc:
        logger.exception("lookup_clause_exact failed")
        return error(str(exc))


def explain_rule(standard_name: str, clause_reference_or_topic: str) -> dict:
    """Synthesise a grounded explanation of a rule/clause.

    Internally: try ``lookup_clause_exact`` first; if no exact match, fall back
    to ``search_knowledge_base`` scoped to that standard.  Adds 1-2 related
    clauses via cross-reference lookup.

    **Confidence**: average of retrieval confidence and explanation completeness.
    """
    try:
        # Step 1: Try exact lookup
        exact = lookup_clause_exact(standard_name, clause_reference_or_topic)
        retrieval_confidence = 0.0
        retrieval_data = []
        retrieval_sources = []
        used_method = "none"

        if exact["status"] == "ok":
            retrieval_confidence = exact["confidence"] or 1.0
            retrieval_data = exact["data"]
            retrieval_sources = exact["sources"]
            used_method = "exact_clause"
        else:
            # Step 2: Fuzzy search scoped to standard
            search_result = search_knowledge_base(
                query=f"{standard_name} {clause_reference_or_topic}",
                framework=standard_name,
            )
            if search_result["status"] == "ok":
                retrieval_confidence = search_result["confidence"] or 0.5
                retrieval_data = search_result["data"]
                retrieval_sources = search_result["sources"]
                used_method = "knowledge_base_search"

        if not retrieval_data:
            return not_found(
                f"Cannot find rule/clause for '{standard_name}' / '{clause_reference_or_topic}'.",
                confidence=0.0,
                confidence_basis="neither exact lookup nor search found results",
            )

        # Step 3: Cross-reference lookup for related clauses
        related_clauses = []
        xref_result = cross_reference_lookup(standard_name, clause_reference_or_topic)
        if xref_result["status"] == "ok":
            related_clauses = xref_result["data"][:2]  # max 2 related

        # Completeness score: did we find related context?
        completeness = 0.7 if not related_clauses else 1.0
        final_confidence = (retrieval_confidence + completeness) / 2.0

        explanation = {
            "standard": standard_name,
            "clause": clause_reference_or_topic,
            "primary_text": retrieval_data,
            "related_clauses": related_clauses,
            "retrieval_method": used_method,
        }

        return ok(
            data=explanation,
            confidence=round(final_confidence, 4),
            confidence_basis=(
                f"retrieval_confidence={retrieval_confidence:.3f} ({used_method}), "
                f"completeness={completeness:.1f} "
                f"({'with' if related_clauses else 'without'} cross-references)"
            ),
            sources=retrieval_sources,
        )
    except Exception as exc:
        logger.exception("explain_rule failed")
        return error(str(exc))


def get_eac_opinion_by_topic(topic: str) -> dict:
    """Fuzzy-score topic against EAC opinion titles/summaries.

    Uses pg_trgm ``similarity()`` on the Rules DB (if available) combined
    with dense retrieval on ``eac_query`` / ``eac_general`` tables.

    **Confidence**: fuzzy match score of best result.
    """
    try:
        vec = to_vector_literal(topic)
        results: list[dict] = []

        # Dense retrieval
        for table in ["eac_query", "eac_general"]:
            rows = _dense(table, vec, TOP_K)
            for r in rows:
                r["_source"] = table
                r["text"] = _body(r)
            results.extend(rows)

        # pg_trgm similarity search on eac_query.query_subject
        trgm_rows = _safe_query(
            _query_rules,
            """
            SELECT *, similarity(query_subject, %s) AS trgm_score
            FROM eac_query
            WHERE similarity(query_subject, %s) > 0.15
            ORDER BY similarity(query_subject, %s) DESC
            LIMIT 5
            """,
            (topic, topic, topic),
        )
        for r in trgm_rows:
            r["_source"] = "eac_query_trgm"
            r["text"] = _body(r)
            r["score"] = float(r.get("trgm_score", 0))
            results.append(r)

        if not results:
            return not_found(
                f"No EAC opinions found matching topic: {topic!r}",
                confidence=0.0,
                confidence_basis="no dense or trigram matches",
            )

        # Deduplicate by text content (prefer higher score)
        seen_texts: dict[str, dict] = {}
        for r in results:
            text_key = (r.get("text", ""))[:80]
            if text_key not in seen_texts or r.get("score", 0) > seen_texts[text_key].get("score", 0):
                seen_texts[text_key] = r
        results = sorted(seen_texts.values(), key=lambda r: r.get("score", 0), reverse=True)

        # Rerank
        passages = [r.get("text", "") for r in results[:15]]
        rerank_scores = _rerank(topic, passages, top_n=TOP_K)
        for i, r in enumerate(results[:15]):
            cosine = float(r.get("score", 0))
            reranked = rerank_scores[i] if i < len(rerank_scores) else 0.0
            r["_final_score"] = 0.5 * reranked + 0.5 * cosine

        results[:15] = sorted(results[:15], key=lambda r: r.get("_final_score", 0), reverse=True)
        top_results = results[:TOP_K]

        best_score = top_results[0].get("_final_score", top_results[0].get("score", 0))
        confidence = max(0.0, min(1.0, float(best_score)))

        data = []
        sources = []
        for r in top_results:
            data.append({
                "text": r.get("text", ""),
                "query_subject": r.get("query_subject", ""),
                "opinion_period": r.get("opinion_period"),
                "query_no": r.get("query_no"),
                "score": round(r.get("_final_score", r.get("score", 0)), 4),
            })
            sources.append(make_source(
                doc_id=f"EAC-{r.get('query_no', 'unknown')}",
                clause_ref=r.get("query_subject", ""),
            ))

        return ok(
            data=data,
            confidence=round(confidence, 4),
            confidence_basis=f"best fuzzy/dense score={best_score:.3f}, {len(top_results)} results",
            sources=sources,
        )
    except Exception as exc:
        logger.exception("get_eac_opinion_by_topic failed")
        return error(str(exc))


def compare_standards(standard_a: str, standard_b: str, topic: str) -> dict:
    """Side-by-side comparison of two standards on a given topic.

    Internally searches both standards, builds comparison points.

    **Confidence**: min(confidence_a, confidence_b) — a comparison is only
    as reliable as its weaker side.
    """
    try:
        result_a = search_knowledge_base(query=topic, framework=standard_a)
        result_b = search_knowledge_base(query=topic, framework=standard_b)

        conf_a = result_a.get("confidence") or 0.0
        conf_b = result_b.get("confidence") or 0.0

        if result_a["status"] != "ok" and result_b["status"] != "ok":
            return not_found(
                f"Could not find '{topic}' in either {standard_a} or {standard_b}.",
                confidence=0.0,
                confidence_basis="both retrievals failed",
            )

        comparison = {
            "topic": topic,
            "standard_a": {
                "name": standard_a,
                "status": result_a["status"],
                "findings": result_a.get("data", []) if result_a["status"] == "ok" else [],
                "confidence": conf_a,
            },
            "standard_b": {
                "name": standard_b,
                "status": result_b["status"],
                "findings": result_b.get("data", []) if result_b["status"] == "ok" else [],
                "confidence": conf_b,
            },
        }

        combined_conf = min(conf_a, conf_b)
        all_sources = (result_a.get("sources", []) + result_b.get("sources", []))

        return ok(
            data=comparison,
            confidence=round(combined_conf, 4),
            confidence_basis=(
                f"min(conf_a={conf_a:.3f}, conf_b={conf_b:.3f}); "
                "comparison reliability limited by weaker side"
            ),
            sources=all_sources,
        )
    except Exception as exc:
        logger.exception("compare_standards failed")
        return error(str(exc))


# ===================================================================
# GROUP B — Regulatory Intelligence — 5 tools
# ===================================================================


def check_amendment_status(
    standard_name: str, clause_reference: str, as_of_date: str
) -> dict:
    """Check amendment/supersession status of a standard clause as of a date.

    Reads the ``amendment_metadata`` table in the Rules DB.

    **Confidence**: 1.0 if metadata record found and dated after the
    standard's last known amendment cycle; lower if the ingested record
    predates a suspected but unconfirmed amendment.
    """
    try:
        try:
            check_date = datetime.strptime(as_of_date.strip(), "%Y-%m-%d").date()
        except ValueError:
            return error(f"Invalid date format: {as_of_date!r}. Expected YYYY-MM-DD.")

        rows = _safe_query(
            _query_rules,
            """
            SELECT standard_name, clause_reference, amendment_date, superseded_by,
                   status, description
            FROM amendment_metadata
            WHERE LOWER(standard_name) = LOWER(%s)
              AND (clause_reference IS NULL OR LOWER(clause_reference) = LOWER(%s))
            ORDER BY amendment_date DESC
            """,
            (standard_name.strip(), clause_reference.strip()),
        )

        if not rows:
            return not_found(
                f"No amendment metadata found for '{standard_name}' / '{clause_reference}'.",
                confidence=0.0,
                confidence_basis="no amendment_metadata records (table may not be populated)",
            )

        # Find amendments on or before as_of_date
        applicable = []
        for r in rows:
            amend_date = r.get("amendment_date")
            if amend_date and amend_date <= check_date:
                applicable.append(r)

        if not applicable:
            return ok(
                data={
                    "status": "no_amendments_before_date",
                    "standard_name": standard_name,
                    "clause_reference": clause_reference,
                    "as_of_date": as_of_date,
                    "latest_amendment": rows[0] if rows else None,
                },
                confidence=0.85,
                confidence_basis="amendment records exist but none predate the as_of_date",
                sources=[make_source(
                    doc_id="amendment_metadata",
                    clause_ref=clause_reference,
                    as_of_date=as_of_date,
                )],
            )

        latest = applicable[0]
        # Confidence: 1.0 if latest record is recent; lower if it's stale
        days_since = (check_date - latest["amendment_date"]).days
        confidence = 1.0 if days_since < 365 else max(0.6, 1.0 - days_since / 3650)

        return ok(
            data={
                "current_status": latest.get("status", "unknown"),
                "latest_amendment_date": str(latest.get("amendment_date", "")),
                "superseded_by": latest.get("superseded_by"),
                "description": latest.get("description", ""),
                "all_amendments": applicable,
            },
            confidence=round(confidence, 4),
            confidence_basis=(
                f"amendment record found, {days_since} days before as_of_date; "
                + ("recent and reliable" if days_since < 365 else "may be stale — verify manually")
            ),
            sources=[make_source(
                doc_id="amendment_metadata",
                clause_ref=clause_reference,
                as_of_date=str(latest.get("amendment_date", "")),
            )],
        )
    except Exception as exc:
        logger.exception("check_amendment_status failed")
        return error(str(exc))


def list_applicable_rules(
    line_item_name: str,
    entity_type: str | None = None,
    industry: str | None = None,
) -> dict:
    """Map a line item to its governing regulatory frameworks.

    Searches the ``line_item_rules`` table via keyword match, optionally
    filtered by entity type and industry.

    **Confidence**: completeness of mapping (covers all applicable frameworks?).
    """
    try:
        # Acronym expansion for common line items
        query_term = line_item_name.strip()
        acronyms = {
            "ppe": "property, plant",
            "csr": "corporate social responsibility",
            "ecl": "expected credit loss",
            "rou": "right of use",
            "cwip": "capital work in progress",
        }
        search_term = acronyms.get(query_term.lower(), query_term)

        # Search line_item_rules (existing table)
        rows = _safe_query(
            _query_rules,
            """
            SELECT chunk_text FROM line_item_rules
            WHERE chunk_text ILIKE %s OR chunk_text ILIKE %s
            LIMIT 20
            """,
            (f"%{query_term}%", f"%{search_term}%"),
        )

        if not rows:
            return not_found(
                f"No rule mappings found for line item: {line_item_name!r}",
                confidence=0.0,
                confidence_basis="no matches in line_item_rules table",
            )

        # Parse frameworks mentioned in results
        frameworks_found = set()
        fw_patterns = {
            "Ind AS": re.compile(r"Ind\s*AS", re.I),
            "Schedule III": re.compile(r"Schedule\s*III", re.I),
            "CARO 2020": re.compile(r"CARO", re.I),
            "Companies Act": re.compile(r"Companies\s*Act", re.I),
            "SA": re.compile(r"\bSA\s*\d+", re.I),
        }
        for r in rows:
            text = r.get("chunk_text", "")
            for fw_name, pat in fw_patterns.items():
                if pat.search(text):
                    frameworks_found.add(fw_name)

        # Completeness: how many of the 5 major frameworks are covered?
        total_frameworks = 5
        completeness = len(frameworks_found) / total_frameworks
        confidence = max(0.3, min(1.0, completeness + 0.2))  # base 0.2 for finding anything

        data = {
            "line_item": line_item_name,
            "rules": [r.get("chunk_text", "") for r in rows],
            "frameworks_covered": sorted(frameworks_found),
            "entity_type_filter": entity_type,
            "industry_filter": industry,
        }

        return ok(
            data=data,
            confidence=round(confidence, 4),
            confidence_basis=(
                f"{len(rows)} rule entries found, covering {len(frameworks_found)}/{total_frameworks} "
                f"frameworks: {', '.join(sorted(frameworks_found)) or 'none'}"
            ),
            sources=[make_source(doc_id="line_item_rules", clause_ref=line_item_name)],
        )
    except Exception as exc:
        logger.exception("list_applicable_rules failed")
        return error(str(exc))


def cross_reference_lookup(standard_name: str, clause_reference: str) -> dict:
    """Find related/amending/replacing clauses via cross-reference mapping.

    **Confidence**: 1.0 for direct mapping, lower for inferred matches.
    """
    try:
        # Step 1: Direct cross-reference table lookup
        rows = _safe_query(
            _query_rules,
            """
            SELECT source_standard, source_clause, target_standard, target_clause,
                   relationship_type, confidence
            FROM cross_references
            WHERE (LOWER(source_standard) = LOWER(%s) AND LOWER(source_clause) = LOWER(%s))
               OR (LOWER(target_standard) = LOWER(%s) AND LOWER(target_clause) = LOWER(%s))
            ORDER BY confidence DESC
            """,
            (standard_name.strip(), clause_reference.strip(),
             standard_name.strip(), clause_reference.strip()),
        )

        if rows:
            data = []
            for r in rows:
                data.append({
                    "source_standard": r["source_standard"],
                    "source_clause": r["source_clause"],
                    "target_standard": r["target_standard"],
                    "target_clause": r["target_clause"],
                    "relationship": r["relationship_type"],
                    "mapping_confidence": r.get("confidence", 1.0),
                })
            return ok(
                data=data,
                confidence=1.0,
                confidence_basis="direct cross-reference mapping found",
                sources=[make_source(
                    doc_id="cross_references",
                    clause_ref=f"{standard_name} {clause_reference}",
                )],
            )

        # Step 2: Inferred cross-references via topic similarity search
        search_result = search_knowledge_base(
            query=f"{standard_name} {clause_reference} related clauses",
            framework=None,
        )
        if search_result["status"] == "ok" and search_result["data"]:
            inferred = []
            for item in search_result["data"][:3]:
                inferred.append({
                    "source_standard": standard_name,
                    "source_clause": clause_reference,
                    "target_standard": item.get("source_table", "unknown"),
                    "target_clause": item.get("paragraph_no") or item.get("section_title", ""),
                    "relationship": "inferred_topic_similarity",
                    "mapping_confidence": round(float(item.get("score", 0)) * 0.6, 4),
                })
            return ok(
                data=inferred,
                confidence=round(float(search_result.get("confidence", 0)) * 0.5, 4),
                confidence_basis="inferred via topic similarity (no direct mapping in cross_references table)",
                sources=search_result.get("sources", []),
            )

        return not_found(
            f"No cross-references found for '{standard_name}' / '{clause_reference}'.",
            confidence_basis="no direct or inferred cross-references found",
        )
    except Exception as exc:
        logger.exception("cross_reference_lookup failed")
        return error(str(exc))





# ===================================================================
# GROUP C — Verification — 1 tool
# ===================================================================


def validate_rule_answer(claim_text: str, standard_name: str | None = None) -> dict:
    """Validate whether a claim about a rule/standard is grounded, contradicted, or unverifiable.

    Internally runs retrieval against the claim to find supporting or
    contradicting text.

    **Confidence**: strength of support/contradiction found.
    """
    try:
        # Retrieve relevant regulatory text
        framework = standard_name if standard_name else None
        search_result = search_knowledge_base(query=claim_text, framework=framework)

        if search_result["status"] != "ok" or not search_result.get("data"):
            return not_found(
                "Cannot verify claim — no matching regulatory text found.",
                confidence=0.1,
                confidence_basis="no retrieval hits to validate against",
            )

        top_results = search_result["data"][:5]
        retrieval_confidence = search_result.get("confidence", 0)

        # Score the claim against retrieved text
        # Use reranker to score claim against each retrieved passage
        passages = [r.get("text", "") for r in top_results]
        claim_scores = _rerank(claim_text, passages, top_n=5)

        best_support = max(claim_scores) if claim_scores else 0.0

        # Determine verdict
        if best_support > 0.7:
            verdict = "grounded"
            confidence = min(1.0, best_support)
            basis = f"strong textual support found (reranker score={best_support:.3f})"
        elif best_support > 0.4:
            verdict = "partially_grounded"
            confidence = best_support * 0.8
            basis = f"partial textual support (reranker score={best_support:.3f})"
        elif best_support > 0.2:
            verdict = "unverifiable"
            confidence = 0.3
            basis = f"weak textual overlap (reranker score={best_support:.3f}) — cannot confirm or deny"
        else:
            verdict = "unverifiable"
            confidence = 0.1
            basis = f"no meaningful textual support (reranker score={best_support:.3f})"

        data = {
            "claim": claim_text,
            "verdict": verdict,
            "support_score": round(best_support, 4),
            "supporting_passages": [
                {"text": passages[i], "score": round(claim_scores[i], 4)}
                for i in range(len(passages))
                if claim_scores[i] > 0.2
            ],
        }

        return ok(
            data=data,
            confidence=round(confidence, 4),
            confidence_basis=basis,
            sources=search_result.get("sources", []),
        )
    except Exception as exc:
        logger.exception("validate_rule_answer failed")
        return error(str(exc))


# ===================================================================
# GROUP D — Entity — 3 tools
# ===================================================================


def resolve_entity_year(company_name: str, fiscal_year_string: str) -> dict:
    """Normalise free-text company name + year into canonical entity info.

    **Confidence**: string-match/alias-match quality.
    ``status="ambiguous"`` if multiple entities plausibly match.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year_string)

        env = _entity_to_envelope(resolution)
        if env is not None:
            return env

        best = _best_entity(resolution)
        return ok(
            data={
                "entity_id": best.entity_id,
                "canonical_name": best.canonical_name,
                "fy_start": best.fy_start,
                "fy_end": best.fy_end,
                "doc_id": best.doc_id,
                "match_method": best.match_method,
            },
            confidence=best.confidence,
            confidence_basis=f"{best.match_method} match on company name",
            sources=[make_source(doc_id=best.doc_id)],
        )
    except Exception as exc:
        logger.exception("resolve_entity_year failed")
        return error(str(exc))





def get_reporting_framework(company_name: str, fiscal_year: str) -> dict:
    """Determine which accounting framework applies (IndAS/AS/IFRS) and Schedule III division.

    Internally resolves entity + year.

    **Confidence**: completeness of the metadata record for that fiscal year.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        # Try entity_reporting_framework table
        rows = _safe_query(
            _query_reports,
            """
            SELECT framework, schedule_iii_division
            FROM entity_reporting_framework
            WHERE entity_id = %s AND fiscal_year_start = %s AND fiscal_year_end = %s
            LIMIT 1
            """,
            (int(best.entity_id) if best.entity_id.isdigit() else 0, best.fy_start, best.fy_end),
        )

        if rows:
            r = rows[0]
            return ok(
                data={
                    "company": best.canonical_name,
                    "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                    "framework": r["framework"],
                    "schedule_iii_division": r.get("schedule_iii_division"),
                },
                confidence=0.95,
                confidence_basis="explicit entity_reporting_framework record found",
                sources=[make_source(doc_id=best.doc_id)],
            )

        # Fallback: infer from disclosures (most listed Indian companies use Ind AS)
        return ok(
            data={
                "company": best.canonical_name,
                "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                "framework": "Ind AS",  # default for post-2016 Indian listed companies
                "schedule_iii_division": "II",  # Division II = Ind AS companies
                "note": "Inferred (Ind AS applies to most Indian listed/large companies post-2016). "
                        "entity_reporting_framework table not populated for this entity.",
            },
            confidence=0.55,
            confidence_basis="inferred default (Ind AS/Division II); no explicit framework record",
            sources=[make_source(doc_id=best.doc_id)],
        )
    except Exception as exc:
        logger.exception("get_reporting_framework failed")
        return error(str(exc))


# ===================================================================
# GROUP E — Company Retrieval — 4 tools
# ===================================================================


def search_company_disclosures(
    company_name: str, fiscal_year: str, topic: str
) -> dict:
    """Filtered semantic search over a company's ingested disclosure chunks.

    Internally resolves entity + year, then runs dense search restricted
    to that company's document.

    **Confidence**: retrieval score × entity resolution confidence.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        vec = to_vector_literal(topic)

        # Search text_chunks for this specific document
        text_rows = _query_reports(
            """
            SELECT c.content, c.section, c.page_ocr_start AS page,
                   1 - (c.embedding <=> %s::vector) AS score
            FROM text_chunks c
            WHERE c.doc_id = %s AND c.embedding IS NOT NULL
            ORDER BY c.embedding <=> %s::vector
            LIMIT %s
            """,
            (vec, best.doc_id, vec, TOP_K),
        )

        # Search table_chunks too
        table_rows = _safe_query(
            _query_reports,
            """
            SELECT COALESCE(t.table_title, '') || ': ' || COALESCE(t.table_description, '') AS content,
                   t.table_md, t.section, t.page_ocr_start AS page,
                   1 - (t.description_embedding <=> %s::vector) AS score
            FROM table_chunks t
            WHERE t.doc_id = %s AND t.description_embedding IS NOT NULL
            ORDER BY t.description_embedding <=> %s::vector
            LIMIT %s
            """,
            (vec, best.doc_id, vec, TOP_K),
        )

        all_rows = text_rows + table_rows
        if not all_rows:
            return not_found(
                f"No disclosure chunks found for {best.canonical_name} FY{best.fy_start}-{best.fy_end} on '{topic}'.",
                confidence=0.0,
                confidence_basis="no embedding matches in text_chunks/table_chunks for this document",
            )

        all_rows.sort(key=lambda r: r.get("score", 0), reverse=True)

        # Rerank — ensure table_md content is passed to cross-encoder reranker
        passages = []
        for r in all_rows[:20]:
            t_desc = r.get("content", "") or ""
            t_md = r.get("table_md", "") or ""
            combined = f"{t_desc}\n{t_md}".strip() if t_md else t_desc
            passages.append(combined)

        rerank_scores = _rerank(topic, passages, top_n=TOP_K)
        for i, r in enumerate(all_rows[:20]):
            cosine = float(r.get("score", 0))
            reranked = rerank_scores[i] if i < len(rerank_scores) else 0.0
            r["_final_score"] = 0.6 * reranked + 0.4 * cosine

        all_rows[:20] = sorted(all_rows[:20], key=lambda r: r.get("_final_score", 0), reverse=True)
        results = all_rows[:TOP_K]

        top_score = results[0].get("_final_score", results[0].get("score", 0))
        # Penalise if entity resolution was low-confidence
        confidence = min(1.0, float(top_score) * best.confidence)

        data = []
        sources = []
        for r in results:
            data.append({
                "text": r.get("content", ""),
                "table_md": r.get("table_md"),
                "section": r.get("section", ""),
                "page": r.get("page"),
                "score": round(r.get("_final_score", r.get("score", 0)), 4),
            })
            sources.append(make_source(
                doc_id=best.doc_id,
                page=r.get("page"),
            ))

        return ok(
            data={"company": best.canonical_name, "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                  "topic": topic, "results": data},
            confidence=round(confidence, 4),
            confidence_basis=(
                f"retrieval_score={top_score:.3f} × entity_confidence={best.confidence:.3f}"
            ),
            sources=sources,
        )
    except Exception as exc:
        logger.exception("search_company_disclosures failed")
        return error(str(exc))


_POLICY_SYNONYMS: dict[str, str] = {
    "revenue recognition": "revenue from contracts with customers",
    "revenue": "revenue from contracts with customers",
    "depreciation": "property plant equipment useful life",
    "depreciation policy": "property plant equipment useful life",
    "ppe": "property, plant and equipment",
    "property plant and equipment": "property, plant and equipment",
    "leases": "right of use assets",
    "lease": "right of use assets",
    "inventory": "inventories valuation",
    "inventories": "inventories valuation",
    "borrowing costs": "capitalisation of borrowing costs",
    "segment reporting": "operating segments",
}


def get_accounting_policy_note(
    company_name: str, fiscal_year: str, policy_area: str
) -> dict:
    """Fetch the accounting policy note for a specific area from a company's report using a 3-attempt synonym-aware retry loop.

    **Confidence**: Scaled based on attempt stage and match score.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        # 1. Attempt exact SQL keyword lookup first
        policy_patterns = [
            f"%{policy_area}%",
            "%accounting polic%",
            "%significant accounting%",
        ]

        rows = _query_reports(
            """
            SELECT c.content, c.section, c.page_ocr_start AS page
            FROM text_chunks c
            WHERE c.doc_id = %s
              AND (c.section ILIKE %s OR c.content ILIKE %s
                   OR c.section ILIKE %s OR c.content ILIKE %s)
            ORDER BY c.page_ocr_start, c.chunk_id
            LIMIT 10
            """,
            (best.doc_id,
             policy_patterns[0], policy_patterns[0],
             policy_patterns[1], policy_patterns[2]),
        )

        area_lower = policy_area.lower().strip()
        if rows:
            exact_matches = [
                r for r in rows
                if area_lower in (r.get("content", "") or "").lower()
                or area_lower in (r.get("section", "") or "").lower()
            ]
            if exact_matches:
                confidence = round(0.9 * best.confidence, 4)
                data = {
                    "company": best.canonical_name,
                    "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                    "policy_area": policy_area,
                    "notes": [
                        {"text": r.get("content", ""), "section": r.get("section", ""), "page": r.get("page")}
                        for r in exact_matches
                    ],
                }
                return ok(
                    data=data,
                    confidence=confidence,
                    confidence_basis=f"exact SQL keyword match for '{policy_area}' (Attempt 1)",
                    sources=[make_source(doc_id=best.doc_id, page=r.get("page")) for r in exact_matches],
                )

        # 2. Synonym-aware 3-attempt retry loop against search_company_disclosures
        attempts = []
        # Attempt (a): as given
        attempts.append(policy_area)

        # Attempt (b): synonym substitution
        synonym = _POLICY_SYNONYMS.get(area_lower)
        if not synonym:
            for k, v in _POLICY_SYNONYMS.items():
                if k in area_lower or area_lower in k:
                    synonym = v
                    break
        if synonym and synonym.lower() != area_lower:
            attempts.append(synonym)
        else:
            attempts.append(f"{policy_area} recognition criteria useful life")

        # Attempt (c): topic + "accounting policy" prefix if not present
        if "accounting policy" not in area_lower:
            attempts.append(f"accounting policy {policy_area}")
        else:
            attempts.append(f"significant accounting policy {policy_area}")

        best_disc_res = None
        winning_attempt_idx = -1

        for idx, term in enumerate(attempts):
            disc_res = search_company_disclosures(company_name, fiscal_year, term)
            if disc_res["status"] == "ok" and disc_res.get("data", {}).get("results"):
                best_disc_res = disc_res
                winning_attempt_idx = idx
                break

        if best_disc_res:
            raw_conf = best_disc_res.get("confidence") or 0.6
            attempt_weights = [0.85, 0.75, 0.65]
            attempt_weight = attempt_weights[min(winning_attempt_idx, len(attempt_weights) - 1)]
            scaled_conf = round(min(1.0, raw_conf * attempt_weight), 4)

            results_data = best_disc_res.get("data", {}).get("results", [])
            data = {
                "company": best.canonical_name,
                "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                "policy_area": policy_area,
                "notes": results_data,
                "retry_attempt": winning_attempt_idx + 1,
            }
            return ok(
                data=data,
                confidence=scaled_conf,
                confidence_basis=f"policy found via search_company_disclosures on attempt {winning_attempt_idx + 1} (term: '{attempts[winning_attempt_idx]}')",
                sources=best_disc_res.get("sources", []),
            )

        return not_found(
            f"Accounting policy for '{policy_area}' not found in {best.canonical_name} FY{best.fy_start}-{best.fy_end} after 3 reformulations.",
            confidence=0.0,
            confidence_basis="all 3 policy search reformulations returned no matching disclosure chunks",
        )
    except Exception as exc:
        logger.exception("get_accounting_policy_note failed")
        return error(str(exc))


def lookup_report_reference(
    company_name: str, fiscal_year: str, note_or_section_ref: str
) -> dict:
    """Resolve a note/section reference to source text and page.

    **Confidence**: 1.0 on exact reference match, else not_found.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        ref = note_or_section_ref.strip()

        # Try exact section match
        rows = _query_reports(
            """
            SELECT c.content, c.section, c.page_ocr_start AS page
            FROM text_chunks c
            WHERE c.doc_id = %s
              AND (c.section ILIKE %s OR c.content ILIKE %s)
            ORDER BY c.page_ocr_start, c.chunk_id
            LIMIT 10
            """,
            (best.doc_id, f"%{ref}%", f"%{ref}%"),
        )

        if rows:
            return ok(
                data={
                    "company": best.canonical_name,
                    "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                    "reference": ref,
                    "sections": [
                        {"text": r.get("content", ""), "section": r.get("section", ""), "page": r.get("page")}
                        for r in rows
                    ],
                },
                confidence=1.0,
                confidence_basis="exact section/note reference match",
                sources=[make_source(doc_id=best.doc_id, page=r.get("page")) for r in rows],
            )

        return not_found(
            f"Reference '{ref}' not found in {best.canonical_name} FY{best.fy_start}-{best.fy_end}.",
            confidence_basis="no exact reference match in text_chunks",
        )
    except Exception as exc:
        logger.exception("lookup_report_reference failed")
        return error(str(exc))


def get_schedule_note(
    company_name: str, fiscal_year: str, schedule_name: str
) -> dict:
    """Retrieve schedule/note rows and movement data from a company's report.

    **Confidence**: completeness of the schedule data found.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        # Search table_chunks for the schedule
        table_rows = _safe_query(
            _query_reports,
            """
            SELECT t.table_title, t.table_description, t.table_md,
                   t.unit, t.currency, t.page_ocr_start AS page
            FROM table_chunks t
            WHERE t.doc_id = %s
              AND (t.table_title ILIKE %s OR t.table_description ILIKE %s)
            ORDER BY t.page_ocr_start
            LIMIT 10
            """,
            (best.doc_id, f"%{schedule_name}%", f"%{schedule_name}%"),
        )

        # Also search text_chunks
        text_rows = _safe_query(
            _query_reports,
            """
            SELECT c.content, c.section, c.page_ocr_start AS page
            FROM text_chunks c
            WHERE c.doc_id = %s
              AND (c.section ILIKE %s OR c.content ILIKE %s)
            ORDER BY c.page_ocr_start
            LIMIT 10
            """,
            (best.doc_id, f"%{schedule_name}%", f"%{schedule_name}%"),
        )

        # If we found matches in text_chunks but not in table_chunks directly,
        # fetch the tables residing on those matching pages.
        if text_rows and not table_rows:
            matching_pages = list({r.get("page") for r in text_rows if r.get("page") is not None})
            if matching_pages:
                extra_tables = _safe_query(
                    _query_reports,
                    """
                    SELECT t.table_title, t.table_description, t.table_md,
                           t.unit, t.currency, t.page_ocr_start AS page
                    FROM table_chunks t
                    WHERE t.doc_id = %s
                      AND t.page_ocr_start = ANY(%s)
                    ORDER BY t.page_ocr_start
                    """,
                    (best.doc_id, matching_pages),
                )
                if extra_tables:
                    table_rows = extra_tables

        if not table_rows and not text_rows:
            # Fallback: try semantic search over disclosures for this schedule
            disc_res = search_company_disclosures(company_name, fiscal_year, schedule_name)
            if disc_res["status"] == "ok" and disc_res.get("data", {}).get("results"):
                return ok(
                    data={
                        "company": best.canonical_name,
                        "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                        "schedule_name": schedule_name,
                        "tables": [],
                        "text_sections": disc_res["data"]["results"],
                    },
                    confidence=round((disc_res.get("confidence") or 0.5) * 0.8, 4),
                    confidence_basis="schedule retrieved via semantic disclosure search",
                    sources=disc_res.get("sources", []),
                )
            return not_found(
                f"Schedule/note '{schedule_name}' not found in {best.canonical_name} "
                f"FY{best.fy_start}-{best.fy_end}.",
                confidence=0.0,
                confidence_basis="no matching table or text chunks",
            )

        # Assess completeness
        has_tables = bool(table_rows)
        has_text = bool(text_rows)
        completeness = (0.5 if has_tables else 0.0) + (0.5 if has_text else 0.0)
        # If we have a table with markdown, that's usually complete
        if table_rows and any(r.get("table_md") for r in table_rows):
            completeness = max(completeness, 0.8)

        data = {
            "company": best.canonical_name,
            "fiscal_year": f"{best.fy_start}-{best.fy_end}",
            "schedule_name": schedule_name,
            "tables": [
                {
                    "title": r.get("table_title", ""),
                    "description": r.get("table_description", ""),
                    "markdown": r.get("table_md", ""),
                    "unit": r.get("unit"),
                    "currency": r.get("currency"),
                    "page": r.get("page"),
                }
                for r in table_rows
            ],
            "text_sections": [
                {"text": r.get("content", ""), "section": r.get("section", ""), "page": r.get("page")}
                for r in text_rows
            ],
        }

        return ok(
            data=data,
            confidence=round(completeness * best.confidence, 4),
            confidence_basis=(
                f"{'tables found' if has_tables else 'no tables'}, "
                f"{'text found' if has_text else 'no text'}, "
                f"completeness={completeness:.1f}"
            ),
            sources=[make_source(doc_id=best.doc_id, page=r.get("page"))
                     for r in (table_rows + text_rows)],
        )
    except Exception as exc:
        logger.exception("get_schedule_note failed")
        return error(str(exc))


# ===================================================================
# GROUP F — Company Facts — 2 tools
# ===================================================================





def get_audit_report_highlights(company_name: str, fiscal_year: str) -> dict:
    """Fetch structured audit-report fields (opinion, KAM, EOM, qualifications, going concern).

    **Confidence**: completeness of structured extraction.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        # Extract SAR sections using pattern matching (reuse existing infrastructure)
        from research_agent.retrieval.sar_retrieval import (
            _MAIN_PATTERNS,
            _extract_sections,
        )
        main_text = _extract_sections(best.doc_id, _MAIN_PATTERNS)

        if not main_text or not main_text.strip():
            return not_found(
                f"No auditor report text found for {best.canonical_name} FY{best.fy_start}-{best.fy_end}.",
                confidence=0.0,
                confidence_basis="no SAR sections matched in text_chunks",
            )

        # Parse key fields from the extracted text
        highlights: dict[str, Any] = {
            "company": best.canonical_name,
            "fiscal_year": f"{best.fy_start}-{best.fy_end}",
        }

        # Opinion type detection
        text_lower = main_text.lower()
        if "unmodified opinion" in text_lower or "unqualified opinion" in text_lower:
            highlights["opinion_type"] = "Unmodified"
        elif "qualified opinion" in text_lower:
            highlights["opinion_type"] = "Qualified"
        elif "adverse opinion" in text_lower:
            highlights["opinion_type"] = "Adverse"
        elif "disclaimer of opinion" in text_lower:
            highlights["opinion_type"] = "Disclaimer"
        else:
            highlights["opinion_type"] = "Not clearly identified"

        # Key Audit Matters
        kam_match = re.search(
            r"key\s+audit\s+matter[s]?\s*\n(.*?)(?=\n\s*(?:other\s+(?:matter|information)|emphasis\s+of\s+matter|report\s+on))",
            main_text, re.I | re.S,
        )
        highlights["key_audit_matters"] = kam_match.group(1).strip()[:2000] if kam_match else None

        # Emphasis of Matter
        eom_match = re.search(
            r"emphasis\s+of\s+matter[s]?\s*\n(.*?)(?=\n\s*(?:other\s+matter|key\s+audit|report\s+on))",
            main_text, re.I | re.S,
        )
        highlights["emphasis_of_matter"] = eom_match.group(1).strip()[:1000] if eom_match else None

        # Going Concern
        gc_match = re.search(
            r"going\s+concern\s*\n(.*?)(?=\n\s*(?:other\s+|key\s+audit|emphasis|report\s+on))",
            main_text, re.I | re.S,
        )
        highlights["going_concern"] = gc_match.group(1).strip()[:1000] if gc_match else None

        # Qualifications
        qual_match = re.search(
            r"(?:basis\s+for\s+(?:qualified|adverse)\s+opinion|qualification[s]?)\s*\n(.*?)(?=\n\s*(?:other\s+|key\s+audit|emphasis|report\s+on))",
            main_text, re.I | re.S,
        )
        highlights["qualifications"] = qual_match.group(1).strip()[:1000] if qual_match else None

        highlights["raw_text_length"] = len(main_text)

        # Completeness scoring: base confidence 0.75 for finding SAR text + field coverage
        fields = ["opinion_type", "key_audit_matters", "emphasis_of_matter", "going_concern"]
        non_null = sum(1 for f in fields if highlights.get(f) and highlights[f] != "Not clearly identified")
        completeness = non_null / len(fields)
        confidence = (0.75 + 0.25 * completeness) * best.confidence

        return ok(
            data=highlights,
            confidence=round(confidence, 4),
            confidence_basis=(
                f"SAR text extracted ({len(main_text)} chars); "
                f"{non_null}/{len(fields)} structured fields identified"
            ),
            sources=[make_source(doc_id=best.doc_id)],
        )
    except Exception as exc:
        logger.exception("get_audit_report_highlights failed")
        return error(str(exc))


# ===================================================================
# GROUP G — Compliance (advisory — non-authoritative) — 3 tools
# ===================================================================


def check_statement_compliance(
    company_name: str, fiscal_year: str, framework: str
) -> dict:
    """Run deterministic rule checks against a framework.

    Internally resolves entity + year and fetches its own facts.
    Returns pass/fail/warning per rule with individual confidence.

    ⚠ ADVISORY ONLY — not authoritative.

    **Confidence**: per-finding (not aggregated).
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        fw = _norm_framework(framework)

        # Fetch compliance rules from Rules DB
        rules = _safe_query(
            _query_rules,
            """
            SELECT rule_id, description, line_items_needed, check_type, check_params, severity
            FROM compliance_rules
            WHERE LOWER(framework) = LOWER(%s)
            ORDER BY rule_id
            """,
            (fw or framework,),
        )

        if not rules:
            return not_found(
                f"No compliance rules found for framework '{framework}'. "
                "The compliance_rules table may not be populated.",
                confidence=0.0,
                confidence_basis="no rules in compliance_rules table for this framework",
            )

        # Fetch financial facts for this entity directly from annual report data
        fact_map = _fetch_company_financial_facts(company_name, best.fy_start, best.fy_end, best.doc_id)

        # Run each rule
        findings = []
        for rule in rules:
            rule_id = rule["rule_id"]
            needed = rule.get("line_items_needed", [])
            check_type = rule.get("check_type", "presence")

            # Check if required line items are available
            available = {item: fact_map.get(item) for item in needed if item in fact_map}
            missing = [item for item in needed if item not in fact_map]

            if missing:
                findings.append({
                    "rule_id": rule_id,
                    "description": rule["description"],
                    "result": "cannot_verify",
                    "reason": f"Missing line items: {missing}",
                    "confidence": 0.2,
                    "confidence_basis": f"{len(available)}/{len(needed)} required items available",
                })
                continue

            # Deterministic check
            if check_type == "presence":
                all_present = all(v is not None for v in available.values())
                findings.append({
                    "rule_id": rule_id,
                    "description": rule["description"],
                    "result": "pass" if all_present else "warning",
                    "reason": "All required items present" if all_present else "Some items have null values",
                    "confidence": 0.9 if all_present else 0.7,
                    "confidence_basis": "presence check on structured facts",
                })
            elif check_type == "range":
                params = rule.get("check_params", {}) or {}
                min_val = params.get("min")
                max_val = params.get("max")
                item_code = needed[0] if needed else None
                val = fact_map.get(item_code)
                if val is not None:
                    in_range = (min_val is None or val >= min_val) and (max_val is None or val <= max_val)
                    findings.append({
                        "rule_id": rule_id,
                        "description": rule["description"],
                        "result": "pass" if in_range else "fail",
                        "reason": f"{item_code}={val} {'within' if in_range else 'outside'} range [{min_val}, {max_val}]",
                        "confidence": 0.95,
                        "confidence_basis": "deterministic range check",
                    })
                else:
                    findings.append({
                        "rule_id": rule_id,
                        "description": rule["description"],
                        "result": "cannot_verify",
                        "reason": f"{item_code} value is null",
                        "confidence": 0.2,
                        "confidence_basis": "line item present but value null",
                    })
            else:
                findings.append({
                    "rule_id": rule_id,
                    "description": rule["description"],
                    "result": "cannot_verify",
                    "reason": f"Unsupported check_type: {check_type}",
                    "confidence": 0.0,
                    "confidence_basis": "unknown check type",
                })

        return ok(
            data={
                "company": best.canonical_name,
                "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                "framework": framework,
                "advisory_disclaimer": "This is a non-authoritative advisory check. "
                                       "Always consult a qualified auditor.",
                "total_rules": len(rules),
                "findings": findings,
                "summary": {
                    "pass": sum(1 for f in findings if f["result"] == "pass"),
                    "fail": sum(1 for f in findings if f["result"] == "fail"),
                    "warning": sum(1 for f in findings if f["result"] == "warning"),
                    "cannot_verify": sum(1 for f in findings if f["result"] == "cannot_verify"),
                },
            },
            confidence=None,  # individual findings have their own confidence
            confidence_basis="per-finding confidence; not aggregated",
            sources=[make_source(doc_id=best.doc_id)],
        )
    except Exception as exc:
        logger.exception("check_statement_compliance failed")
        return error(str(exc))


def check_caro_clauses(company_name: str, fiscal_year: str) -> dict:
    """Fetch CARO 2020 clause responses and adverse findings.

    **Confidence**: completeness of the ingested CARO annexure.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        from research_agent.retrieval.sar_retrieval import (
            _CARO_PATTERNS,
            _extract_sections,
        )
        caro_text = _extract_sections(best.doc_id, _CARO_PATTERNS)

        if not caro_text or not caro_text.strip():
            return not_found(
                f"No CARO 2020 annexure found for {best.canonical_name} FY{best.fy_start}-{best.fy_end}.",
                confidence=0.0,
                confidence_basis="no CARO section patterns matched in text_chunks",
            )

        # Parse clause numbers from the text
        clause_pattern = re.compile(r"(?:clause|para(?:graph)?)\s*\(?([ivxlcdm]+|\d+)\)?", re.I)
        clauses_found = clause_pattern.findall(caro_text)

        # Expected CARO 2020 clauses: (i) through (xxi) = 21 clauses
        expected_clauses = 21
        clause_coverage = min(1.0, len(set(clauses_found)) / expected_clauses) if clauses_found else 0.1
        confidence = (0.75 + 0.25 * clause_coverage) * best.confidence

        # Detect adverse findings
        adverse_keywords = [
            "not maintained", "discrepanc", "default", "not deposited",
            "not complied", "qualified", "adverse", "material weakness",
        ]
        adverse_mentions = sum(1 for kw in adverse_keywords if kw in caro_text.lower())

        data = {
            "company": best.canonical_name,
            "fiscal_year": f"{best.fy_start}-{best.fy_end}",
            "caro_text": caro_text[:15000],
            "clauses_identified": len(set(clauses_found)),
            "adverse_indicator_count": adverse_mentions,
            "clause_coverage": round(clause_coverage, 2),
        }

        return ok(
            data=data,
            confidence=round(confidence, 4),
            confidence_basis=(
                f"CARO annexure retrieved; {len(set(clauses_found))} clauses identified out of ~{expected_clauses}; "
                f"adverse indicators: {adverse_mentions}"
            ),
            sources=[make_source(doc_id=best.doc_id)],
        )
    except Exception as exc:
        logger.exception("check_caro_clauses failed")
        return error(str(exc))


def check_rule_11g(company_name: str, fiscal_year: str) -> dict:
    """Check Rule 11(g) (audit trail) applicability and findings.

    **Confidence**: completeness of the underlying record.
    """
    try:
        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        # Search for Rule 11(g) / audit trail in the SAR
        rule_11g_patterns = ["%rule 11%", "%audit trail%", "%section 143%"]

        rows = _query_reports(
            """
            SELECT c.content, c.section, c.page_ocr_start AS page
            FROM text_chunks c
            WHERE c.doc_id = %s
              AND (c.section ILIKE %s OR c.content ILIKE %s
                   OR c.section ILIKE %s OR c.content ILIKE %s
                   OR c.section ILIKE %s OR c.content ILIKE %s)
            ORDER BY c.page_ocr_start, c.chunk_id
            LIMIT 15
            """,
            (best.doc_id,
             rule_11g_patterns[0], rule_11g_patterns[0],
             rule_11g_patterns[1], rule_11g_patterns[1],
             rule_11g_patterns[2], rule_11g_patterns[2]),
        )

        if not rows:
            return not_found(
                f"No Rule 11(g) / audit trail information found for {best.canonical_name} "
                f"FY{best.fy_start}-{best.fy_end}.",
                confidence=0.0,
                confidence_basis="no matching sections for rule 11(g) / audit trail",
            )

        combined = "\n\n".join(r.get("content", "") for r in rows if r.get("content"))

        # Detect key findings
        has_audit_trail = "audit trail" in combined.lower()
        has_rule_11 = "rule 11" in combined.lower()
        has_exception = any(kw in combined.lower() for kw in [
            "exception", "not operated", "not enabled", "not maintained"
        ])

        completeness = 0.5
        if has_audit_trail and has_rule_11:
            completeness = 0.9
        elif has_audit_trail or has_rule_11:
            completeness = 0.7

        data = {
            "company": best.canonical_name,
            "fiscal_year": f"{best.fy_start}-{best.fy_end}",
            "rule_11g_text": combined[:5000],
            "audit_trail_mentioned": has_audit_trail,
            "rule_11_mentioned": has_rule_11,
            "exceptions_noted": has_exception,
        }

        return ok(
            data=data,
            confidence=round(completeness * best.confidence, 4),
            confidence_basis=(
                f"{'audit trail and rule 11 both mentioned' if has_audit_trail and has_rule_11 else 'partial coverage'}; "
                f"{'exceptions noted' if has_exception else 'no exceptions detected'}"
            ),
            sources=[make_source(doc_id=best.doc_id, page=r.get("page")) for r in rows[:3]],
        )
    except Exception as exc:
        logger.exception("check_rule_11g failed")
        return error(str(exc))


# ===================================================================
# GROUP H — Computation (deterministic) — 2 tools
# ===================================================================


def _parse_missing_facts_from_tables(doc_id: str, existing_facts: dict[str, float]) -> None:
    """Fallback to dynamically extract missing financial facts from Markdown tables."""
    import re
    try:
        rows = _safe_query(
            _query_reports,
            "SELECT table_md FROM table_chunks WHERE doc_id = %s",
            (doc_id,)
        )
        if not rows:
            return

        needed_patterns = {
            "current_liabilities": [r"Current\s*Liabilities", r"Total\s*Current\s*Liabilities"],
            "current_assets": [r"Current\s*Assets", r"Total\s*Current\s*Assets"],
            "trade_receivables": [r"Trade\s*Receivables"],
            "capital_employed": [r"Capital\s*Employed", r"Total\s*Assets\s*Less\s*Current\s*Liabilities"],
            "investments": [r"Current\s*Investments", r"Non\s*Current\s*Investments"],
            "borrowings_repaid": [r"Repayment\s*of\s*borrowings", r"Repayment\s*of\s*long-term\s*borrowings"],
            "trade_payables": [r"Trade\s*Payables"],
            "pat": [r"Profit\s*for\s*the\s*year", r"Profit\s*after\s*tax"],
            "revenue": [r"Revenue\s*from\s*operations", r"Total\s*Revenue"],
            "revenue_operations": [r"Revenue\s*from\s*operations"],
            "total_equity": [r"Total\s*Equity"],
            "total_debt": [r"Total\s*Borrowings", r"Long-term\s*borrowings"],
            "finance_costs": [r"Finance\s*Costs"],
            "depreciation_amortisation": [r"Depreciation\s*and\s*amorti[s|z]ation"],
            "cost_of_materials": [r"Cost\s*of\s*materials\s*consumed"],
            "purchases": [r"Purchases\s*of\s*Stock-in-Trade", r"Purchases\s*of\s*stock\s*in\s*trade"],
            "inventories": [r"Inventories"],
            "ebit": [r"Profit\s*before\s*tax", r"Profit\s*before\s*exceptional\s*items\s*and\s*tax"],
            "other_income": [r"Other\s*Income"],
        }

        # Which ones do we actually need?
        missing_keys = [k for k in needed_patterns.keys() if k not in existing_facts or existing_facts[k] is None]
        if not missing_keys:
            return

        for r in rows:
            md = r.get("table_md") or ""
            if not md:
                continue

            for fact_key in list(missing_keys):
                patterns = needed_patterns[fact_key]
                for pat in patterns:
                    # Search line by line to restrict regex match to the same row
                    for line in md.split("\n"):
                        if re.search(r"\|\s*" + pat + r"\s*\|", line, re.IGNORECASE):
                            # Extract all numbers in this markdown row
                            matches = re.findall(r"(?x) (?<=\|) \s* ( [-\d,\.]+ ) \s* (?=\|)", line)
                            for m in matches:
                                if not re.search(r"\d", m): 
                                    continue
                                val_str = m.replace(",", "")
                                try:
                                    v = float(val_str)
                                    # Heuristic: skip tiny integers that are usually Note references
                                    if v < 100 and "." not in val_str:
                                        continue
                                    existing_facts[fact_key] = v
                                    missing_keys.remove(fact_key)
                                    break
                                except ValueError:
                                    pass
                            if fact_key not in missing_keys:
                                break
                if not missing_keys:
                    break

    except Exception as exc:
        logger.debug("Table dynamic parsing failed: %s", exc)


def _fetch_company_financial_facts(
    company_name: str, fy_start: int, fy_end: int, doc_id: str
) -> dict[str, float]:
    """Fetch financial statement figures from Annual Report data in Reports DB."""
    facts: dict[str, float] = {}

    # 1. Try fdr_input_data table first
    try:
        rows = _safe_query(
            _query_reports,
            """
            SELECT years, parsed FROM fdr_input_data
            WHERE doc_id = %s OR company ILIKE %s OR REPLACE(company, '_', ' ') ILIKE %s
            LIMIT 1
            """,
            (doc_id, f"%{company_name.strip()}%", f"%{company_name.strip()}%"),
        )
        if rows:
            r = rows[0]
            years = r.get("years", []) or []
            parsed = r.get("parsed", {}) or {}
            lines = parsed.get("lines", {}) or {}

            # Find year index (e.g. "FY2023-24", "FY2024", "2024")
            fy_str_1 = f"FY{fy_start}-{str(fy_end)[-2:]}"
            fy_str_2 = f"FY{fy_end}"
            idx = None
            for i, y in enumerate(years):
                if fy_str_1.lower() in y.lower() or fy_str_2.lower() in y.lower() or str(fy_end) in y:
                    idx = i
                    break
            if idx is None and len(years) > 0:
                idx = len(years) - 1  # latest year fallback

            if idx is not None:
                for k, vals in lines.items():
                    if isinstance(vals, list) and idx < len(vals):
                        v = vals[idx]
                        if v is not None and isinstance(v, (int, float)):
                            facts[k] = float(v)

                # Parse warnings for dropped variables
                import re
                warnings = parsed.get("parse_report", {}).get("warnings", [])
                for w in warnings:
                    if fy_str_1.lower() in w.lower() or fy_str_2.lower() in w.lower() or str(fy_end) in w:
                        match = re.search(r"(\w+)\s+value\s+'([-\d,\.]+)'\s+not verbatim", w)
                        if match:
                            var_name = match.group(1)
                            val_str = match.group(2).replace(",", "")
                            try:
                                facts[var_name] = float(val_str)
                            except ValueError:
                                pass
    except Exception as exc:
        logger.debug("fdr_input_data lookup failed: %s", exc)

    # 2. Try report_facts table as fallback
    if not facts:
        try:
            rows = _safe_query(
                _query_reports,
                """
                SELECT line_item_code, value FROM report_facts
                WHERE doc_id = %s OR fiscal_year = %s
                """,
                (doc_id, fy_end),
            )
            for r in rows:
                if r.get("line_item_code") and r.get("value") is not None:
                    facts[r["line_item_code"]] = float(r["value"])
        except Exception:
            pass

    # Normalized keys for ratio formulas
    if "total_current_assets" in facts:
        facts["current_assets"] = facts["total_current_assets"]
    if "total_current_liabilities" in facts:
        facts["current_liabilities"] = facts["total_current_liabilities"]
    if "total_equity" not in facts:
        eq_cap = facts.get("equity_share_capital", 0) or 0
        oth_eq = facts.get("other_equity", 0) or 0
        if "equity_share_capital" in facts or "other_equity" in facts:
            facts["total_equity"] = eq_cap + oth_eq
    if "net_income" not in facts and "pat" in facts:
        facts["net_income"] = facts["pat"]
    if "revenue" not in facts and "revenue_operations" in facts:
        facts["revenue"] = facts["revenue_operations"]
    if "ebit" not in facts and "pbt" in facts and "finance_costs" in facts:
        facts["ebit"] = (facts.get("pbt") or 0) + (facts.get("finance_costs") or 0)
    if "interest_expense" not in facts and "finance_costs" in facts:
        facts["interest_expense"] = facts["finance_costs"]
    if "cost_of_goods_sold" not in facts and "cost_of_materials" in facts:
        facts["cost_of_goods_sold"] = facts["cost_of_materials"]
    if "purchases" not in facts and "cost_of_materials" in facts:
        facts["purchases"] = facts["cost_of_materials"]
    if "borrowings_repaid" in facts:
        facts["borrowings_repaid"] = abs(facts["borrowings_repaid"])

    # 3. Dynamic table parsing fallback for completely missing variables
    _parse_missing_facts_from_tables(doc_id, facts)

    # Derived values that rely on potentially extracted base variables
    if "working_capital" not in facts and "current_assets" in facts and "current_liabilities" in facts:
        facts["working_capital"] = facts["current_assets"] - facts["current_liabilities"]
    if "capital_employed" not in facts and "total_assets" in facts and "current_liabilities" in facts:
        facts["capital_employed"] = facts["total_assets"] - facts["current_liabilities"]
    if "total_debt" not in facts:
        b_curr = facts.get("borrowings_current", 0) or 0
        b_noncurr = facts.get("borrowings_noncurrent", 0) or 0
        if "borrowings_current" in facts or "borrowings_noncurrent" in facts:
            facts["total_debt"] = b_curr + b_noncurr

    return facts


def compute_ratio_analysis(
    ratio_name: str | list[str],
    company_name: str | None = None,
    fiscal_year: str | None = None,
) -> dict:
    """Unified financial ratio analysis tool.

    Supports:
      1. Formula & definition lookup (when company_name is omitted or ratio_name is 'formula_only').
      2. Computing a single ratio, list of ratios, or all 11 Schedule III ratios
         ('all_schedule_iii') for a company using financial figures extracted from
         its Annual Report data in Reports DB.

    Deterministic — confidence is null for calculations. Returns status="not_found"
    if underlying financial figures are missing from the report (never estimates).
    """
    try:
        # Check if caller wants all 11 Schedule III mandatory ratios
        is_all_sch_iii = (
            isinstance(ratio_name, str)
            and ratio_name.strip().lower() in ("all_schedule_iii", "schedule_iii", "all_ratios", "11_ratios")
        )

        if is_all_sch_iii:
            from research_agent.tools.ratio_master import SCHEDULE_III_RATIOS
            ratio_names = SCHEDULE_III_RATIOS
        elif isinstance(ratio_name, str):
            ratio_names = [ratio_name]
        else:
            ratio_names = list(ratio_name)

        # Mode A: Formula / Definition Lookup (no company_name passed)
        if not company_name or not company_name.strip():
            definitions = []
            for rn in ratio_names:
                defn = get_ratio_definition(rn)
                if defn:
                    definitions.append(defn)
                else:
                    definitions.append({"ratio_name": rn, "status": "not_found", "message": f"Formula for '{rn}' not found"})
            return ok(
                data={
                    "mode": "formula_lookup",
                    "total_ratios": len(definitions),
                    "ratios": definitions,
                    "schedule_iii_mandatory_11": is_all_sch_iii,
                },
                confidence=None,
                confidence_basis="deterministic ratio formula master lookup",
                sources=[make_source(doc_id="ratio_master")],
            )

        # Mode B: Ratio Computation from Annual Report data
        if not fiscal_year:
            fiscal_year = "2024"  # default to latest year

        resolution = resolve_entity(company_name, fiscal_year)
        env = _entity_to_envelope(resolution)
        if env is not None:
            return env
        best = _best_entity(resolution)

        # Fetch financial facts from Annual Report data in Reports DB
        fact_map = _fetch_company_financial_facts(
            company_name, best.fy_start, best.fy_end, best.doc_id
        )

        results = []
        for rn in ratio_names:
            defn = get_ratio_definition(rn)
            if not defn:
                results.append({
                    "ratio_name": rn,
                    "status": "not_found",
                    "error": f"Ratio formula definition not found for: {rn}",
                })
                continue

            formula = defn.get("formula", "")
            needed = list(set(defn.get("numerator_items", []) + defn.get("denominator_items", [])))
            variables = {}
            missing = []
            for item in needed:
                val = fact_map.get(item)
                if val is not None:
                    variables[item] = val
                else:
                    missing.append(item)

            if missing:
                results.append({
                    "ratio_name": defn.get("name", rn),
                    "status": "not_found",
                    "error": f"Missing financial facts in annual report: {missing}",
                    "formula": formula,
                })
                continue

            calc_result = ast_evaluate(formula, variables)
            if calc_result.get("error"):
                results.append({
                    "ratio_name": defn.get("name", rn),
                    "status": "error",
                    "error": calc_result["error"],
                    "formula": formula,
                    "variables": variables,
                })
                continue

            value = calc_result["result"]
            benchmark = defn.get("benchmark", {})
            benchmark_category = "unknown"
            if isinstance(benchmark, dict):
                for category, bounds in benchmark.items():
                    if isinstance(bounds, list) and len(bounds) == 2:
                        if bounds[0] <= value <= bounds[1]:
                            benchmark_category = category
                            break

            results.append({
                "ratio_name": defn.get("name", rn),
                "status": "ok",
                "value": round(value, 4),
                "formula": formula,
                "variables": variables,
                "computation": calc_result.get("basis", ""),
                "benchmark_category": benchmark_category,
                "benchmark_ranges": benchmark,
                "interpretation": defn.get("interpretation", ""),
            })

        overall_status = "ok" if any(r["status"] == "ok" for r in results) else "not_found"

        return {
            "status": overall_status,
            "data": {
                "company": best.canonical_name,
                "fiscal_year": f"{best.fy_start}-{best.fy_end}",
                "doc_id": best.doc_id,
                "schedule_iii_mandatory_11": is_all_sch_iii,
                "ratios_computed": len([r for r in results if r["status"] == "ok"]),
                "ratios": results,
            },
            "confidence": None,
            "confidence_basis": "deterministic formula evaluation on Annual Report financial data",
            "sources": [make_source(doc_id=best.doc_id)],
            "ambiguity_note": None,
        }
    except Exception as exc:
        logger.exception("compute_ratio_analysis failed")
        return error(str(exc))


def calculate(expression: str, variables: dict | None = None) -> dict:
    """Generic AST-parsed arithmetic evaluator.

    Pure math on caller-supplied numbers. No entity resolution.
    Deterministic — no confidence field.

    Supports: ``+ - * / ** %``, parentheses, named variables,
    functions ``abs, round, min, max, sum``.
    """
    try:
        if not expression or not expression.strip():
            return error("Expression cannot be empty.")

        result = ast_evaluate(str(expression), variables or {})

        if result.get("error"):
            return {
                "status": "error",
                "data": {"error": result["error"], "expression": expression},
                "confidence": None,
                "confidence_basis": "deterministic computation — rejected input",
                "sources": [],
                "ambiguity_note": None,
            }

        return {
            "status": "ok",
            "data": {
                "result": result["result"],
                "basis": result.get("basis", ""),
                "expression": expression,
                "variables": variables or {},
            },
            "confidence": None,
            "confidence_basis": "deterministic AST-evaluated computation",
            "sources": [],
            "ambiguity_note": None,
        }
    except Exception as exc:
        logger.exception("calculate failed")
        return error(str(exc))


# ===================================================================
# Tool Registration — build all 25 Yukta tools
# ===================================================================

def _envelope_to_str(envelope: dict) -> str:
    """Serialise a response envelope dict to JSON for the LLM context."""
    return json.dumps(envelope, default=str, indent=2, ensure_ascii=False)


def build_all_tools(collector: list | None = None) -> list:
    """Build and return all 25 research tools as Yukta Tool objects.

    Parameters
    ----------
    collector : list, optional
        A mutable list that accumulates structured retrieval hits.

    Returns
    -------
    list[Tool]
        25 Yukta Tool objects ready to be added to a ToolProcessor.
    """
    if collector is None:
        collector = []

    # OpenTelemetry tracer for per-tool spans (no-op if tracing not initialised)
    try:
        from opentelemetry import trace as _otel_trace
        _tracer = _otel_trace.get_tracer("research_agent.tools")
    except Exception:
        _tracer = None

    def _wrap(fn, name: str):
        """Wrap a tool function to serialise its envelope, append to collector,
        and emit an OpenTelemetry span for Phoenix traceability."""
        def wrapper(**kwargs):
            if _tracer is not None:
                with _tracer.start_as_current_span(f"tool.{name}") as span:
                    span.set_attribute("tool.name", name)
                    span.set_attribute("tool.arguments", json.dumps(kwargs, default=str))
                    result = fn(**kwargs)
                    span.set_attribute("tool.status", result.get("status", "unknown"))
                    conf = result.get("confidence")
                    if conf is not None:
                        span.set_attribute("tool.confidence", float(conf))
                    span.set_attribute("tool.sources_count", len(result.get("sources", [])))
                    collector.append({"tool": name, "arguments": kwargs, "result": result})
                    return _envelope_to_str(result)
            else:
                result = fn(**kwargs)
                collector.append({"tool": name, "arguments": kwargs, "result": result})
                return _envelope_to_str(result)
        # Preserve the original function's signature info
        wrapper.__name__ = name
        wrapper.__doc__ = fn.__doc__
        return wrapper

    tools = []

    # --- A. Retrieval (regulatory text) ---

    tools.append(create_custom_tool(
        name="search_knowledge_base",
        description=(
            "Hybrid vector+keyword+reranker search across the regulatory corpus "
            "(Ind AS, AS, Schedule III, CARO 2020, SA, EAC opinions). Optionally filter "
            "by framework. Returns ranked results with confidence scores."
        ),
        parameters=[
            {"name": "query", "type": "string",
             "description": "Search query about accounting standards, rules, or regulations",
             "required": True},
            {"name": "framework", "type": "string",
             "description": "Filter to one framework: IndAS, AS, ScheduleIII, CARO, SA, or EAC (optional)",
             "required": False},
        ],
        function=_wrap(search_knowledge_base, "search_knowledge_base"),
    ))

    tools.append(create_custom_tool(
        name="lookup_clause_exact",
        description=(
            "Exact SQL lookup of a specific clause/paragraph in a standard. "
            "Returns confidence=1.0 on exact match, or status='not_found' — "
            "never falls back to fuzzy matching. Use search_knowledge_base for fuzzy search."
        ),
        parameters=[
            {"name": "standard_name", "type": "string",
             "description": "The standard name (e.g. 'Ind AS 115', 'SA 700', 'CARO 2020')",
             "required": True},
            {"name": "clause_reference", "type": "string",
             "description": "The clause/paragraph reference (e.g. 'para 9', 'clause (iii)')",
             "required": True},
        ],
        function=_wrap(lookup_clause_exact, "lookup_clause_exact"),
    ))

    tools.append(create_custom_tool(
        name="explain_rule",
        description=(
            "Get a grounded explanation of a specific rule or clause, with related "
            "cross-references. Tries exact lookup first, then falls back to search."
        ),
        parameters=[
            {"name": "standard_name", "type": "string",
             "description": "The standard name", "required": True},
            {"name": "clause_reference_or_topic", "type": "string",
             "description": "Clause reference (e.g. 'para 15') or topic description",
             "required": True},
        ],
        function=_wrap(explain_rule, "explain_rule"),
    ))

    tools.append(create_custom_tool(
        name="get_eac_opinion_by_topic",
        description=(
            "Search ICAI Expert Advisory Committee (EAC) opinions by topic. "
            "Uses fuzzy matching and dense retrieval. Returns top matching opinions."
        ),
        parameters=[
            {"name": "topic", "type": "string",
             "description": "Topic to search for (e.g. 'government grants', 'revenue recognition')",
             "required": True},
        ],
        function=_wrap(get_eac_opinion_by_topic, "get_eac_opinion_by_topic"),
    ))

    tools.append(create_custom_tool(
        name="compare_standards",
        description=(
            "Side-by-side comparison of two standards/frameworks on a given topic. "
            "Confidence = min of the two retrieval confidences."
        ),
        parameters=[
            {"name": "standard_a", "type": "string",
             "description": "First standard/framework (e.g. 'IndAS', 'CARO')", "required": True},
            {"name": "standard_b", "type": "string",
             "description": "Second standard/framework", "required": True},
            {"name": "topic", "type": "string",
             "description": "Topic to compare across the two standards", "required": True},
        ],
        function=_wrap(compare_standards, "compare_standards"),
    ))

    # --- B. Regulatory Intelligence ---

    tools.append(create_custom_tool(
        name="check_amendment_status",
        description=(
            "Check the amendment/supersession status of a standard clause as of a given date."
        ),
        parameters=[
            {"name": "standard_name", "type": "string", "description": "Standard name", "required": True},
            {"name": "clause_reference", "type": "string", "description": "Clause reference", "required": True},
            {"name": "as_of_date", "type": "string", "description": "Date to check (YYYY-MM-DD)", "required": True},
        ],
        function=_wrap(check_amendment_status, "check_amendment_status"),
    ))

    tools.append(create_custom_tool(
        name="list_applicable_rules",
        description=(
            "Map a financial statement line item to its governing regulatory frameworks "
            "(Ind AS, Schedule III, CARO, Companies Act, SA)."
        ),
        parameters=[
            {"name": "line_item_name", "type": "string",
             "description": "Line item name (e.g. 'Trade receivables', 'PPE', 'Borrowings')",
             "required": True},
            {"name": "entity_type", "type": "string",
             "description": "Entity type filter (e.g. 'listed', 'psu')", "required": False},
            {"name": "industry", "type": "string",
             "description": "Industry filter", "required": False},
        ],
        function=_wrap(list_applicable_rules, "list_applicable_rules"),
    ))

    tools.append(create_custom_tool(
        name="cross_reference_lookup",
        description=(
            "Find related, amending, or replacing clauses via cross-reference mapping."
        ),
        parameters=[
            {"name": "standard_name", "type": "string", "description": "Standard name", "required": True},
            {"name": "clause_reference", "type": "string", "description": "Clause reference", "required": True},
        ],
        function=_wrap(cross_reference_lookup, "cross_reference_lookup"),
    ))

    # --- C. Verification ---

    tools.append(create_custom_tool(
        name="validate_rule_answer",
        description=(
            "Validate whether a claim about a rule/standard is grounded, contradicted, "
            "or unverifiable by searching against the regulatory corpus."
        ),
        parameters=[
            {"name": "claim_text", "type": "string",
             "description": "The claim to validate", "required": True},
            {"name": "standard_name", "type": "string",
             "description": "Standard to validate against (optional, broadens search if omitted)",
             "required": False},
        ],
        function=_wrap(validate_rule_answer, "validate_rule_answer"),
    ))

    # --- D. Entity ---

    tools.append(create_custom_tool(
        name="resolve_entity_year",
        description=(
            "Normalise free-text company name + fiscal year into canonical entity ID. "
            "Handles aliases, subsidiaries, and FY format variations."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year_string", "type": "string",
             "description": "Fiscal year (e.g. 'FY2023-24', '2024', 'FY24')", "required": True},
        ],
        function=_wrap(resolve_entity_year, "resolve_entity_year"),
    ))

    tools.append(create_custom_tool(
        name="get_reporting_framework",
        description=(
            "Determine which accounting framework (Ind AS/AS/IFRS) and Schedule III "
            "division applies to a company for a given fiscal year."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
        ],
        function=_wrap(get_reporting_framework, "get_reporting_framework"),
    ))

    # --- E. Company Retrieval ---

    tools.append(create_custom_tool(
        name="search_company_disclosures",
        description=(
            "Semantic search over a specific company's annual report disclosures "
            "for a given fiscal year and topic."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
            {"name": "topic", "type": "string", "description": "Topic to search for", "required": True},
        ],
        function=_wrap(search_company_disclosures, "search_company_disclosures"),
    ))

    tools.append(create_custom_tool(
        name="get_accounting_policy_note",
        description=(
            "Fetch the accounting policy note for a specific area (e.g. 'revenue', "
            "'leases', 'PPE') from a company's annual report."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
            {"name": "policy_area", "type": "string",
             "description": "Policy area (e.g. 'revenue recognition', 'depreciation')", "required": True},
        ],
        function=_wrap(get_accounting_policy_note, "get_accounting_policy_note"),
    ))

    tools.append(create_custom_tool(
        name="lookup_report_reference",
        description=(
            "Resolve a specific note or section reference in a company's report "
            "to the actual source text and page number."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
            {"name": "note_or_section_ref", "type": "string",
             "description": "Note/section reference (e.g. 'Note 15', 'Schedule of PPE')", "required": True},
        ],
        function=_wrap(lookup_report_reference, "lookup_report_reference"),
    ))

    tools.append(create_custom_tool(
        name="get_schedule_note",
        description=(
            "Retrieve schedule/note tables and movement data from a company's report "
            "(e.g. 'PPE schedule', 'borrowings', 'provisions')."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
            {"name": "schedule_name", "type": "string",
             "description": "Schedule/note name (e.g. 'Property Plant Equipment', 'Trade Receivables')",
             "required": True},
        ],
        function=_wrap(get_schedule_note, "get_schedule_note"),
    ))

    tools.append(create_custom_tool(
        name="get_audit_report_highlights",
        description=(
            "Extract structured audit report highlights: opinion type, KAM, "
            "emphasis of matter, going concern note, and qualifications."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
        ],
        function=_wrap(get_audit_report_highlights, "get_audit_report_highlights"),
    ))

    # --- G. Compliance ---

    tools.append(create_custom_tool(
        name="check_statement_compliance",
        description=(
            "Run deterministic compliance rule checks against a framework (IndAS, "
            "ScheduleIII, CARO). Returns per-rule pass/fail/warning. "
            "⚠ ADVISORY ONLY — not authoritative."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
            {"name": "framework", "type": "string",
             "description": "Framework to check against (IndAS, ScheduleIII, CARO)", "required": True},
        ],
        function=_wrap(check_statement_compliance, "check_statement_compliance"),
    ))

    tools.append(create_custom_tool(
        name="check_caro_clauses",
        description=(
            "Fetch and analyse CARO 2020 clause responses from a company's "
            "auditor report, detecting adverse findings."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
        ],
        function=_wrap(check_caro_clauses, "check_caro_clauses"),
    ))

    tools.append(create_custom_tool(
        name="check_rule_11g",
        description=(
            "Check Rule 11(g) audit trail applicability and findings from "
            "the statutory auditor's report."
        ),
        parameters=[
            {"name": "company_name", "type": "string", "description": "Company name", "required": True},
            {"name": "fiscal_year", "type": "string", "description": "Fiscal year", "required": True},
        ],
        function=_wrap(check_rule_11g, "check_rule_11g"),
    ))

    # --- H. Computation ---

    tools.append(create_custom_tool(
        name="compute_ratio_analysis",
        description=(
            "Unified financial ratio analysis tool. Supports lookup of ratio formulas/definitions "
            "or computing a single ratio, list of ratios, or all 11 mandatory Schedule III ratios "
            "('all_schedule_iii') for a company using financial figures extracted from its Annual Report."
        ),
        parameters=[
            {"name": "ratio_name", "type": "string",
             "description": "Ratio name (e.g. 'Current Ratio', 'ROE'), list of ratio names, 'all_schedule_iii' for all 11 Schedule III ratios, or 'formula_only'",
             "required": True},
            {"name": "company_name", "type": "string",
             "description": "Company name (optional if requesting formula lookup only)",
             "required": False},
            {"name": "fiscal_year", "type": "string",
             "description": "Fiscal year (e.g. '2023-24', 'FY24')",
             "required": False},
        ],
        function=_wrap(compute_ratio_analysis, "compute_ratio_analysis"),
    ))

    tools.append(create_custom_tool(
        name="calculate",
        description=(
            "Deterministic arithmetic evaluator. ALWAYS use this instead of doing "
            "arithmetic yourself. Pass figures as 'variables' and the formula as "
            "'expression'. Supports +, -, *, /, **, %, parentheses, and "
            "abs/round/min/max/sum functions."
        ),
        parameters=[
            {"name": "expression", "type": "string",
             "description": "Formula using variable names and operators",
             "required": True},
            {"name": "variables", "type": "object",
             "description": "Map of variable name → number",
             "required": False},
        ],
        function=_wrap(calculate, "calculate"),
    ))

    return tools


# ===================================================================
# Backward compatibility alias
# ===================================================================

def build_research_tools(collector: list | None = None) -> list:
    """Alias for ``build_all_tools`` (backward compatibility)."""
    return build_all_tools(collector)
