"""Internal entity resolution for company-facing tools.

Normalises free-text ``company_name`` + ``fiscal_year_string`` into a
canonical ``(entity_id, canonical_name, fy_start, fy_end, doc_id,
confidence)`` tuple against the Reports DB ``documents`` table.

Resolution strategy (executed in order, first hit wins):
  1. Exact match on ``documents.company``
  2. ILIKE pattern match (handles partial names)
  3. ``pg_trgm similarity()`` — trigram fuzzy match (if extension available)
  4. Python ``difflib.SequenceMatcher`` fallback (silent, no new deps)

Confidence scoring:
  - Exact match  → 1.0
  - ILIKE hit    → 0.85
  - similarity() → the similarity score itself (0.0–1.0, typically >0.3)
  - difflib      → the ratio (0.0–1.0)

If multiple entities match with close scores (within 0.1), returns an
ambiguous result with all candidates — never silently picks one.
"""

from __future__ import annotations

import difflib
import logging
import re
from dataclasses import dataclass

from research_agent.db import get_reports_connection

logger = logging.getLogger("research_agent.tools.entity_resolver")

# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass
class EntityMatch:
    """A single candidate entity match."""
    entity_id: str          # doc_id or entity_id
    canonical_name: str     # company name as stored
    fy_start: int
    fy_end: int
    doc_id: str
    confidence: float
    match_method: str       # "exact" | "ilike" | "similarity" | "difflib"


# ---------------------------------------------------------------------------
# Fiscal-year string normalisation
# ---------------------------------------------------------------------------

_FY_PATTERNS = [
    # "FY2023-24", "FY 2023-2024", "FY2024"
    re.compile(r"FY\s*(\d{4})\s*[-–]\s*(\d{2,4})", re.I),
    # "2023-24", "2023-2024"
    re.compile(r"(\d{4})\s*[-–]\s*(\d{2,4})"),
    # "FY24", "FY2024"
    re.compile(r"FY\s*(\d{2,4})", re.I),
    # bare "2024"
    re.compile(r"(\d{4})"),
]


def parse_fiscal_year(fy_string: str) -> tuple[int, int]:
    """Parse a fiscal-year string into ``(fy_start, fy_end)``.

    Examples::
        "FY2023-24"   → (2023, 2024)
        "2023-2024"   → (2023, 2024)
        "FY24"        → (2023, 2024)  # assumes April-March Indian FY
        "2024"        → (2023, 2024)
    """
    s = fy_string.strip()

    # Pattern 1 & 2: range
    for pat in _FY_PATTERNS[:2]:
        m = pat.search(s)
        if m:
            start = int(m.group(1))
            end_raw = m.group(2)
            end = int(end_raw) if len(end_raw) == 4 else int(str(start)[:2] + end_raw)
            if end < 100:
                end = 2000 + end
            if start < 100:
                start = 2000 + start
            if end <= start:
                end = start + 1
            return start, end

    # Pattern 3: "FY24" → ending year
    m = _FY_PATTERNS[2].search(s)
    if m:
        val = int(m.group(1))
        if val < 100:
            val = 2000 + val
        return val - 1, val

    # Pattern 4: bare year
    m = _FY_PATTERNS[3].search(s)
    if m:
        val = int(m.group(1))
        # Assume it's the ending year of an Indian FY
        return val - 1, val

    raise ValueError(f"Cannot parse fiscal year from: {fy_string!r}")


# ---------------------------------------------------------------------------
# pg_trgm availability check (cached per process)
# ---------------------------------------------------------------------------

_pg_trgm_available: dict[str, bool] = {}  # keyed by db name


def _check_pg_trgm(conn, db_label: str = "reports") -> bool:
    """Check whether pg_trgm extension is enabled, caching the result."""
    if db_label in _pg_trgm_available:
        return _pg_trgm_available[db_label]
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM pg_extension WHERE extname = 'pg_trgm' LIMIT 1"
            )
            available = cur.fetchone() is not None
    except Exception:
        available = False
    _pg_trgm_available[db_label] = available
    if not available:
        logger.warning(
            "pg_trgm extension not available on %s DB — falling back to difflib "
            "for fuzzy entity matching. Consider: CREATE EXTENSION IF NOT EXISTS pg_trgm;",
            db_label,
        )
    return available


# ---------------------------------------------------------------------------
# Core resolution logic
# ---------------------------------------------------------------------------


def _clean_company(name: str) -> str:
    """Normalise company name for matching."""
    return re.sub(r"\s+", " ", name.strip())


def _ilike_pattern(name: str) -> str:
    """Build an ILIKE pattern from a company name."""
    return "%" + re.sub(r"[\s_]+", "%", _clean_company(name)) + "%"


def resolve_entity(
    company_name: str,
    fiscal_year_string: str,
) -> dict:
    """Resolve company_name + fiscal_year into canonical entity info.

    Returns a dict with keys:
        matches: list[EntityMatch]   — all candidates, sorted by confidence desc
        best: EntityMatch | None     — top match (None if no match)
        is_ambiguous: bool           — True if ≥2 candidates within 0.1 confidence
        confidence: float            — confidence of the best match (0 if none)
    """
    try:
        fy_start, fy_end = parse_fiscal_year(fiscal_year_string)
    except ValueError:
        return {
            "matches": [],
            "best": None,
            "is_ambiguous": False,
            "confidence": 0.0,
            "error": f"Cannot parse fiscal year: {fiscal_year_string!r}",
        }

    clean = _clean_company(company_name)
    pattern = _ilike_pattern(company_name)
    matches: list[EntityMatch] = []

    with get_reports_connection() as conn:
        # --- Step 1: Exact match (company + FY) ---
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT doc_id, company, fy_start, fy_end
                FROM documents
                WHERE LOWER(TRIM(company)) = LOWER(%s)
                  AND fy_start = %s AND fy_end = %s
                """,
                (clean, fy_start, fy_end),
            )
            for row in cur.fetchall():
                matches.append(EntityMatch(
                    entity_id=str(row[0]),
                    canonical_name=row[1],
                    fy_start=row[2], fy_end=row[3],
                    doc_id=str(row[0]),
                    confidence=1.0,
                    match_method="exact",
                ))

        if matches:
            return {
                "matches": matches,
                "best": matches[0],
                "is_ambiguous": False,
                "confidence": 1.0,
            }

        # --- Step 2: ILIKE match (company + FY) ---
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT doc_id, company, fy_start, fy_end
                FROM documents
                WHERE company ILIKE %s
                  AND fy_start = %s AND fy_end = %s
                """,
                (pattern, fy_start, fy_end),
            )
            for row in cur.fetchall():
                matches.append(EntityMatch(
                    entity_id=str(row[0]),
                    canonical_name=row[1],
                    fy_start=row[2], fy_end=row[3],
                    doc_id=str(row[0]),
                    confidence=0.85,
                    match_method="ilike",
                ))

        if matches:
            return {
                "matches": matches,
                "best": matches[0],
                "is_ambiguous": len(matches) > 1,
                "confidence": 0.85,
            }

        # --- Step 3: pg_trgm similarity (if extension installed) ---
        if _check_pg_trgm(conn, "reports"):
            try:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT doc_id, company, fy_start, fy_end,
                               similarity(company, %s) AS sim
                        FROM documents
                        WHERE fy_start = %s AND fy_end = %s
                          AND similarity(company, %s) > 0.3
                        ORDER BY sim DESC
                        LIMIT 5
                        """,
                        (clean, fy_start, fy_end, clean),
                    )
                    for row in cur.fetchall():
                        matches.append(EntityMatch(
                            entity_id=str(row[0]),
                            canonical_name=row[1],
                            fy_start=row[2], fy_end=row[3],
                            doc_id=str(row[0]),
                            confidence=round(float(row[4]), 4),
                            match_method="similarity",
                        ))
            except Exception as exc:
                logger.debug("pg_trgm query failed: %s", exc)

        # --- Step 4: Python difflib fallback ---
        if not matches:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT doc_id, company, fy_start, fy_end
                    FROM documents
                    WHERE fy_start = %s AND fy_end = %s
                    """,
                    (fy_start, fy_end),
                )
                all_rows = cur.fetchall()

            clean_lower = clean.lower()
            for row in all_rows:
                sim = difflib.SequenceMatcher(
                    None, clean_lower, (row[1] or "").lower()
                ).ratio()
                if sim > 0.4:
                    matches.append(EntityMatch(
                        entity_id=str(row[0]),
                        canonical_name=row[1],
                        fy_start=row[2], fy_end=row[3],
                        doc_id=str(row[0]),
                        confidence=round(sim * 0.9, 4),  # slight penalty vs pg_trgm
                        match_method="difflib",
                    ))
            matches.sort(key=lambda m: -m.confidence)
            matches = matches[:5]

    # Deduplicate by doc_id
    seen: set[str] = set()
    deduped: list[EntityMatch] = []
    for m in matches:
        if m.doc_id not in seen:
            seen.add(m.doc_id)
            deduped.append(m)
    matches = deduped

    # Sort by confidence descending
    matches.sort(key=lambda m: -m.confidence)

    best = matches[0] if matches else None
    is_ambiguous = (
        len(matches) >= 2
        and abs(matches[0].confidence - matches[1].confidence) < 0.1
    )

    return {
        "matches": matches,
        "best": best,
        "is_ambiguous": is_ambiguous,
        "confidence": best.confidence if best else 0.0,
    }
