"""Ratio formula master data — deterministic definitions.

Each ratio specifies its canonical name, formula expression (for the AST
evaluator), the line-item codes required for numerator and denominator,
optional benchmark ranges, and an interpretation function.

The ``get_ratio_definition`` function first checks the Rules DB
``ratio_formulas`` table (if it exists), then falls back to these
built-in definitions — ensuring the tool works even before the DB
table is populated.
"""

from __future__ import annotations

import logging
from typing import Any

from research_agent.db import get_rules_connection

logger = logging.getLogger("research_agent.tools.ratio_master")


# ---------------------------------------------------------------------------
# Built-in ratio definitions (fallback if DB table absent)
# ---------------------------------------------------------------------------

BUILTIN_RATIOS: dict[str, dict[str, Any]] = {
    "current_ratio": {
        "name": "Current Ratio",
        "formula": "current_assets / current_liabilities",
        "numerator_items": ["current_assets"],
        "denominator_items": ["current_liabilities"],
        "benchmark": {"healthy": [1.5, 3.0], "warning": [1.0, 1.5], "critical": [0, 1.0]},
        "interpretation": "Measures short-term liquidity. >1.5 healthy, <1.0 potential liquidity risk.",
    },
    "quick_ratio": {
        "name": "Quick Ratio (Acid Test)",
        "formula": "(current_assets - inventories) / current_liabilities",
        "numerator_items": ["current_assets", "inventories"],
        "denominator_items": ["current_liabilities"],
        "benchmark": {"healthy": [1.0, 3.0], "warning": [0.5, 1.0], "critical": [0, 0.5]},
        "interpretation": "Liquidity excluding inventory. >1.0 adequate, <0.5 critical.",
    },
    "debt_to_equity": {
        "name": "Debt-to-Equity Ratio",
        "formula": "total_debt / total_equity",
        "numerator_items": ["total_debt"],
        "denominator_items": ["total_equity"],
        "benchmark": {"healthy": [0, 1.5], "warning": [1.5, 2.5], "critical": [2.5, 100]},
        "interpretation": "Financial leverage. <1.5 conservative, >2.5 highly leveraged.",
    },
    "debt_equity_ratio": {
        "name": "Debt-to-Equity Ratio",
        "formula": "total_debt / total_equity",
        "numerator_items": ["total_debt"],
        "denominator_items": ["total_equity"],
        "benchmark": {"healthy": [0, 1.5], "warning": [1.5, 2.5], "critical": [2.5, 100]},
        "interpretation": "Financial leverage. <1.5 conservative, >2.5 highly leveraged.",
    },
    "interest_coverage": {
        "name": "Interest Coverage Ratio",
        "formula": "ebit / interest_expense",
        "numerator_items": ["ebit"],
        "denominator_items": ["interest_expense"],
        "benchmark": {"healthy": [3.0, 100], "warning": [1.5, 3.0], "critical": [0, 1.5]},
        "interpretation": "Ability to service debt. >3 comfortable, <1.5 risky.",
    },
    "return_on_equity": {
        "name": "Return on Equity (ROE)",
        "formula": "net_income / total_equity * 100",
        "numerator_items": ["net_income"],
        "denominator_items": ["total_equity"],
        "benchmark": {"healthy": [15, 100], "warning": [8, 15], "critical": [0, 8]},
        "interpretation": "Profitability relative to equity. >15% strong, <8% weak.",
    },
    "return_on_assets": {
        "name": "Return on Assets (ROA)",
        "formula": "net_income / total_assets * 100",
        "numerator_items": ["net_income"],
        "denominator_items": ["total_assets"],
        "benchmark": {"healthy": [5, 100], "warning": [2, 5], "critical": [0, 2]},
        "interpretation": "Asset utilisation efficiency. >5% good, <2% poor.",
    },
    "net_profit_margin": {
        "name": "Net Profit Margin",
        "formula": "net_income / revenue * 100",
        "numerator_items": ["net_income"],
        "denominator_items": ["revenue"],
        "benchmark": {"healthy": [10, 100], "warning": [5, 10], "critical": [0, 5]},
        "interpretation": "Profitability per rupee of revenue.",
    },
    "gross_profit_margin": {
        "name": "Gross Profit Margin",
        "formula": "(revenue - cost_of_goods_sold) / revenue * 100",
        "numerator_items": ["revenue", "cost_of_goods_sold"],
        "denominator_items": ["revenue"],
        "benchmark": {"healthy": [30, 100], "warning": [15, 30], "critical": [0, 15]},
        "interpretation": "Margin after direct costs.",
    },
    "asset_turnover": {
        "name": "Asset Turnover Ratio",
        "formula": "revenue / total_assets",
        "numerator_items": ["revenue"],
        "denominator_items": ["total_assets"],
        "benchmark": {"healthy": [1.0, 100], "warning": [0.5, 1.0], "critical": [0, 0.5]},
        "interpretation": "Revenue generation per unit of assets.",
    },
    "inventory_turnover": {
        "name": "Inventory Turnover Ratio",
        "formula": "cost_of_goods_sold / inventories",
        "numerator_items": ["cost_of_goods_sold"],
        "denominator_items": ["inventories"],
        "benchmark": {"healthy": [5, 100], "warning": [2, 5], "critical": [0, 2]},
        "interpretation": "How fast inventory is sold. Higher = more efficient.",
    },
    "trade_receivable_turnover": {
        "name": "Trade Receivable Turnover",
        "formula": "revenue / trade_receivables",
        "numerator_items": ["revenue"],
        "denominator_items": ["trade_receivables"],
        "benchmark": {"healthy": [6, 100], "warning": [3, 6], "critical": [0, 3]},
        "interpretation": "Collection efficiency. Higher = faster collection.",
    },
    "trade_payable_turnover": {
        "name": "Trade Payable Turnover",
        "formula": "purchases / trade_payables",
        "numerator_items": ["purchases"],
        "denominator_items": ["trade_payables"],
        "benchmark": {"healthy": [4, 100], "warning": [2, 4], "critical": [0, 2]},
        "interpretation": "Payment velocity to suppliers.",
    },
    "debt_service_coverage": {
        "name": "Debt Service Coverage Ratio (DSCR)",
        "formula": "(pat + finance_costs + depreciation_amortisation) / (finance_costs + borrowings_repaid)",
        "numerator_items": ["pat", "finance_costs", "depreciation_amortisation"],
        "denominator_items": ["finance_costs", "borrowings_repaid"],
        "benchmark": {"healthy": [1.5, 100], "warning": [1.0, 1.5], "critical": [0, 1.0]},
        "interpretation": "Ability to service debt principal and interest obligations.",
    },
    "net_capital_turnover": {
        "name": "Net Capital Turnover Ratio",
        "formula": "revenue_operations / working_capital",
        "numerator_items": ["revenue_operations"],
        "denominator_items": ["working_capital"],
        "benchmark": {"healthy": [2.0, 100], "warning": [1.0, 2.0], "critical": [0, 1.0]},
        "interpretation": "Sales generated per rupee of working capital.",
    },
    "net_profit_ratio": {
        "name": "Net Profit Ratio",
        "formula": "pat / revenue_operations * 100",
        "numerator_items": ["pat"],
        "denominator_items": ["revenue_operations"],
        "benchmark": {"healthy": [10, 100], "warning": [5, 10], "critical": [0, 5]},
        "interpretation": "Net profit percentage on revenue from operations.",
    },
    "return_on_capital_employed": {
        "name": "Return on Capital Employed (ROCE)",
        "formula": "ebit / capital_employed * 100",
        "numerator_items": ["ebit"],
        "denominator_items": ["capital_employed"],
        "benchmark": {"healthy": [15, 100], "warning": [8, 15], "critical": [0, 8]},
        "interpretation": "Efficiency of total capital employed (Equity + Debt).",
    },
    "return_on_investment": {
        "name": "Return on Investment (ROI)",
        "formula": "other_income / investments * 100",
        "numerator_items": ["other_income"],
        "denominator_items": ["investments"],
        "benchmark": {"healthy": [6, 100], "warning": [3, 6], "critical": [0, 3]},
        "interpretation": "Return generated on total investments.",
    },
}

# The 11 Schedule III mandatory disclosure ratios under Companies Act (Division II / Ind AS)
SCHEDULE_III_RATIOS = [
    "current_ratio",
    "debt_to_equity",
    "debt_service_coverage",
    "return_on_equity",
    "inventory_turnover",
    "trade_receivable_turnover",
    "trade_payable_turnover",
    "net_capital_turnover",
    "net_profit_ratio",
    "return_on_capital_employed",
    "return_on_investment",
]

# Normalisation: allow lookup by several name variants
_ALIAS_MAP: dict[str, str] = {}
for _key, _val in BUILTIN_RATIOS.items():
    _ALIAS_MAP[_key.lower()] = _key
    _ALIAS_MAP[_val["name"].lower()] = _key
# Extra common aliases
_ALIAS_MAP["roe"] = "return_on_equity"
_ALIAS_MAP["roa"] = "return_on_assets"
_ALIAS_MAP["d/e"] = "debt_to_equity"
_ALIAS_MAP["d/e ratio"] = "debt_to_equity"
_ALIAS_MAP["npm"] = "net_profit_margin"
_ALIAS_MAP["gpm"] = "gross_profit_margin"
_ALIAS_MAP["opm"] = "operating_profit_margin"


def _normalise_ratio_name(name: str) -> str | None:
    """Map a user-supplied ratio name to our canonical key."""
    key = name.strip().lower().replace("-", "_").replace(" ", "_")
    if key in _ALIAS_MAP:
        return _ALIAS_MAP[key]
    # Try substring match
    for alias, canonical in _ALIAS_MAP.items():
        if key in alias or alias in key:
            return canonical
    return None


# ---------------------------------------------------------------------------
# DB lookup (with fallback to builtins)
# ---------------------------------------------------------------------------

def get_ratio_definition(ratio_name: str) -> dict | None:
    """Look up a ratio definition — DB first, then builtins.

    Returns the full definition dict, or None if not found.
    """
    # 1. Try DB table
    try:
        with get_rules_connection() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT ratio_name, formula, numerator_items, denominator_items,
                           benchmark, interpretation
                    FROM ratio_formulas
                    WHERE LOWER(ratio_name) = LOWER(%s)
                       OR LOWER(ratio_name) = LOWER(%s)
                    LIMIT 1
                    """,
                    (ratio_name.strip(), ratio_name.strip().replace(" ", "_")),
                )
                row = cur.fetchone()
                if row:
                    cols = [d.name for d in cur.description]
                    return dict(zip(cols, row))
    except Exception as exc:
        logger.debug("ratio_formulas DB lookup failed (table may not exist): %s", exc)

    # 2. Fallback to builtins
    canon = _normalise_ratio_name(ratio_name)
    if canon and canon in BUILTIN_RATIOS:
        return BUILTIN_RATIOS[canon]

    return None


def list_available_ratios() -> list[str]:
    """Return all known ratio names (builtins + DB)."""
    names = [v["name"] for v in BUILTIN_RATIOS.values()]
    try:
        with get_rules_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT DISTINCT ratio_name FROM ratio_formulas")
                for row in cur.fetchall():
                    if row[0] not in names:
                        names.append(row[0])
    except Exception as exc:
        logger.debug("Failed to fetch ratio_formulas from DB: %s", exc)
    return sorted(set(names))
