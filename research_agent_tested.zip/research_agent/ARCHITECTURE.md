# Research Agent — Architecture & Code Structure

## Overview

A production-grade financial auditing research agent built on the **yukta** agent framework.
Covers Indian Accounting Standards (Ind AS), Schedule III, CARO 2020, Standards on Auditing (SA),
ICAI Expert Advisory Committee (EAC) opinions, and company annual report data from two PostgreSQL databases.

---

## End-to-End Query Flow

```mermaid
flowchart TD
    A["User Query"] --> B["server.py /api/query"]
    B --> C["query_pipeline.py"]
    
    subgraph Pipeline ["Query Preprocessing Pipeline"]
        C --> D["Step 1: Rephrase via Gemma LLM"]
        D --> E["Step 2: Embed via bge-m3 (1024-dim)"]
        E --> F["Step 3: Intent Classify (regex)"]
        F --> G["Step 4: Entity/FY Extract"]
    end
    
    G --> H["QueryContext\n(intent, hints, embedding)"]
    H --> I["Augmented Query\n[Intent: X] [Tools: Y]\nrephrased_query"]
    I --> J["yukta Agent\n(system prompt + 25 tools)"]
    
    subgraph Agent ["Yukta Agent Loop (max 8 iterations)"]
        J --> K{"LLM selects tool(s)\nbased on intent hints"}
        K --> L["Tool Execution\n(_wrap with OTel span)"]
        L --> M["Tool Result\n(envelope: status/data/confidence/sources)"]
        M --> K
    end
    
    K --> N["Final LLM Response"]
    N --> O["server.py formats\nQueryResponse"]
    O --> P["JSON Response to UI"]
    
    L -.->|"OTel spans"| Q["Phoenix\n(traceability)"]
```

---

## Code File Structure

```
research_agent/
├── server.py                 # FastAPI app, /api/query endpoint, Phoenix init
├── config.py                 # All env-configurable settings (DB, LLM, Phoenix)
├── db.py                     # Postgres connection helpers (Rules DB + Reports DB)
├── embeddings.py             # bge-m3 embedding client (1024-dim)
├── query_pipeline.py         # NEW: rephrase → embed → intent classify → entity extract
├── .env                      # Environment variables (DB URLs, Phoenix endpoint)
│
├── agents/
│   └── research_agent.py     # build_research_agent() → yukta Agent with 25 tools
│
├── tools/
│   ├── research_tools.py     # All 25 tool implementations + build_all_tools()
│   ├── response.py           # Standard envelope: ok/not_found/ambiguous/error
│   ├── entity_resolver.py    # Company name → canonical entity_id resolution
│   ├── ratio_master.py       # Ratio definitions, formulas, Schedule III catalog
│   └── financial_math.py     # AST-based arithmetic evaluator
│
├── retrieval/
│   ├── ind_as_retrieval.py   # Ind AS vector + keyword retrieval
│   ├── reference_retrieval.py # CARO, SA 700, Schedule III, EAC retrieval
│   ├── annual_report_retrieval.py # Company report retrieval
│   └── sar_retrieval.py      # Statutory Audit Report retrieval
│
├── skills/
│   └── research-skill/
│       └── SKILL.md          # System prompt (intent routing + response rules)
│
├── static/
│   ├── index.html            # Web UI
│   ├── app.js                # Frontend logic (tool inspector)
│   └── styles.css            # Styling
│
└── tests/                    # Unit + golden query tests
```

---

## Database Architecture

```mermaid
erDiagram
    RULES_DB {
        string ind_as_chunks "Ind AS standard paragraphs + embeddings"
        string schedule_iii_chunks "Schedule III classification rules"
        string sa_700_chunks "Standards on Auditing (SA 700 series)"
        string cag_caro_chunks "CARO 2020 clauses + CAG directions"
        string eac_query "EAC opinion queries"
        string eac_general "EAC general guidance"
        string line_item_rules "Line item → regulation mapping"
        string ind_as_appendix "Illustrative examples"
    }

    REPORTS_DB {
        string documents "Company annual report metadata"
        string text_chunks "Narrative text chunks + embeddings"
        string table_chunks "Financial table markdown + embeddings"
        string fdr_input_data "Parsed financial diagnostics (JSON)"
        string tb_input_data "Trial balance data"
        string v_financial_tables "Financial table view"
    }
```

| Database | Host | Port | Purpose |
|:---------|:-----|:-----|:--------|
| **Rules DB** (`financial_llm`) | 192.168.200.29 | 11352 | Regulatory standards, rules, EAC opinions |
| **Reports DB** (`finance_llm`) | 192.168.200.29 | 5478 | Company annual reports, financial data |

---

## Tool Taxonomy (25 Tools)

| # | Category | Tool Name | Purpose |
|:--|:---------|:----------|:--------|
| 1 | A. Retrieval | `search_knowledge_base` | Hybrid search across regulatory corpus |
| 2 | A. Retrieval | `lookup_clause_exact` | Exact SQL lookup of a clause |
| 3 | A. Retrieval | `explain_rule` | Grounded explanation of a rule |
| 4 | A. Retrieval | `get_eac_opinion_by_topic` | EAC opinion search |
| 5 | A. Retrieval | `compare_standards` | Side-by-side framework comparison |
| 6 | B. Regulatory | `check_amendment_status` | Amendment/supersession status |
| 7 | B. Regulatory | `list_applicable_rules` | Line item → regulation mapping |
| 8 | B. Regulatory | `cross_reference_lookup` | Related/amending clauses |
| 9 | C. Verification | `validate_rule_answer` | Validate a claim against corpus |
| 10 | D. Entity | `resolve_entity_year` | Company + FY normalisation |
| 11 | D. Entity | `get_reporting_framework` | Ind AS / AS / IFRS determination |
| 12 | E. Company | `search_company_disclosures` | Semantic search in annual reports |
| 13 | E. Company | `get_accounting_policy_note` | Accounting policy retrieval |
| 14 | E. Company | `lookup_report_reference` | Note/section reference resolution |
| 15 | E. Company | `get_schedule_note` | Schedule/note table retrieval |
| 16 | E. Company | `get_audit_report_highlights` | Structured audit highlights |
| 17 | G. Compliance | `check_statement_compliance` | Disclosure adequacy check |
| 18 | G. Compliance | `check_caro_clauses` | CARO 2020 clause audit |
| 19 | G. Compliance | `check_rule_11g` | Rule 11(g) audit trail check |
| 20 | H. Computation | `compute_ratio_analysis` | Financial ratio computation |
| 21 | H. Computation | `calculate` | Deterministic arithmetic |

---

## Phoenix Traceability

```mermaid
flowchart LR
    A["server.py startup"] --> B["yukta.init_tracing()"]
    B --> C["OTLP Exporter → Phoenix"]
    
    D["agent.run()"] --> E["LLM span"]
    E --> F["tool.search_knowledge_base span"]
    E --> G["tool.compute_ratio_analysis span"]
    E --> H["tool.get_audit_report_highlights span"]
    
    F --> C
    G --> C
    H --> C
    
    C --> I["Phoenix UI\nhttp://localhost:6006"]
```

**Span Attributes per tool call:**
- `tool.name` — Tool function name
- `tool.arguments` — JSON serialised input parameters
- `tool.status` — `ok` / `not_found` / `ambiguous` / `error`
- `tool.confidence` — 0.0–1.0 confidence score
- `tool.sources_count` — Number of source citations

---

## Query Pipeline Detail

```mermaid
sequenceDiagram
    participant U as User
    participant S as server.py
    participant P as query_pipeline.py
    participant LLM as Gemma LLM
    participant E as bge-m3
    participant A as yukta Agent
    participant T as Tools
    participant R as Reranker

    U->>S: POST /api/query
    S->>P: preprocess_query(raw_query)
    P->>LLM: Rephrase (max 40 words)
    LLM-->>P: rephrased_query
    P->>E: embed_query(rephrased)
    E-->>P: 1024-dim vector
    P->>P: Intent classify (regex)
    P->>P: Entity/FY extract
    P-->>S: QueryContext
    S->>A: agent.run("[Intent: X] rephrased")
    loop max 8 iterations
        A->>T: Call tool (with OTel span)
        T->>R: Rerank retrieved passages
        R-->>T: Reranked results
        T-->>A: Tool result envelope
    end
    A-->>S: Final response
    S-->>U: QueryResponse JSON
```

---

## Configuration Reference

| Variable | Default | Purpose |
|:---------|:--------|:--------|
| `RULES_DB_URL` | `postgresql://...@192.168.200.29:11352/financial_llm` | Rules database |
| `ANNUAL_REPORTS_DB_URL` | `postgresql://...@192.168.200.29:5478/finance_llm` | Reports database |
| `EMBEDDING_BASE_URL` | `http://192.168.200.22:11450/v1/embeddings` | bge-m3 embeddings |
| `RERANKER_BASE_URL` | `http://192.168.200.22:11451` | bge-reranker |
| `LLM_BASE_URL` | `http://10.10.116.215:30004` | Gemma LLM |
| `LLM_MODEL_NAME` | `gemma-4-26b-a4b-it` | LLM model |
| `ENABLE_TRACING` | `true` | Enable Phoenix tracing |
| `PHOENIX_ENDPOINT` | `http://localhost:6006/v1/traces` | Phoenix OTLP endpoint |
| `PHOENIX_PROJECT_NAME` | `research-agent` | Phoenix project name |
| `TOP_K_OVERALL` | `10` | Final retrieval count |
| `TOP_K_PRE_RERANK` | `50` | Pre-rerank candidate count |
| `MAX_TOOL_ITERATIONS` | `8` | Agent loop limit |
