"""Research Agent builder — creates a single Yukta agent with all 14 tools.

Usage::

    from research_agent.agents.research_agent import build_research_agent

    collector: list = []
    agent = build_research_agent(collector)
    result = agent.run("Does ONGC's trade-receivable disclosure comply with Schedule III?")
    print(result["response"])
"""

from __future__ import annotations

import logging
from pathlib import Path

from yukta import AgentConfig, SystemPrompt, ToolProcessor, create_agent
from yukta.core.Clients.remote_client import RemoteEndpointClient

from research_agent.config import (
    GENERATION_MAX_OUTPUT_TOKENS,
    GENERATION_TIMEOUT,
    LLM_BASE_URL,
    LLM_MODEL_NAME,
    MAX_TOOL_ITERATIONS,
)
from research_agent.tools.research_tools import build_research_tools

logger = logging.getLogger("research_agent.agents")

# ---------------------------------------------------------------------------
# System prompt (loaded from SKILL.md)
# ---------------------------------------------------------------------------

_SKILL_PATH = Path(__file__).resolve().parent.parent / "skills" / "research-skill" / "SKILL.md"


def _load_system_prompt() -> str:
    """Load the research agent system prompt from SKILL.md."""
    if _SKILL_PATH.exists():
        return _SKILL_PATH.read_text(encoding="utf-8")
    logger.warning("SKILL.md not found at %s — using fallback prompt", _SKILL_PATH)
    return (
        "You are a research assistant for Indian financial auditing. "
        "Answer questions using ONLY your retrieval tools. Cite all sources inline."
    )


# ---------------------------------------------------------------------------
# LLM client factory
# ---------------------------------------------------------------------------


def build_llm(temperature: float = 0.2,
              max_tokens: int = GENERATION_MAX_OUTPUT_TOKENS) -> RemoteEndpointClient:
    """Return a RemoteEndpointClient pointed at the configured LLM endpoint.

    ``RemoteEndpointClient`` appends ``/v1/chat/completions`` to ``base_url``,
    so we strip a trailing ``/v1`` from the configured URL to avoid ``/v1/v1``.
    """
    base = LLM_BASE_URL.rstrip("/")
    if base.endswith("/v1"):
        base = base[: -len("/v1")].rstrip("/")
    return RemoteEndpointClient(
        model_name=LLM_MODEL_NAME,
        base_url=base,
        api_key="not-needed",
        temperature=temperature,
        max_tokens=max_tokens,
        timeout=GENERATION_TIMEOUT,
    )


# ---------------------------------------------------------------------------
# Agent builder
# ---------------------------------------------------------------------------


def build_research_agent(collector: list | None = None,
                         temperature: float = 0.2):
    """Build and return the standalone Research Agent.

    Parameters
    ----------
    collector : list, optional
        Mutable list that accumulates structured retrieval hits per tool call.
        If None, an internal list is created.
    temperature : float
        LLM sampling temperature (default 0.2 for factual retrieval).

    Returns
    -------
    Agent
        A fully configured Yukta Agent with 14 research tools and the
        research-skill system prompt.
    """
    if collector is None:
        collector = []

    # Build the LLM client
    llm = build_llm(temperature=temperature)

    # Build all 14 tools and register them in a ToolProcessor
    tools = build_research_tools(collector)
    processor = ToolProcessor()
    for tool in tools:
        processor.add_tool(tool)

    # Load system prompt from SKILL.md
    prompt_text = _load_system_prompt()

    # Create the agent
    agent = create_agent(
        name="Research Agent",
        system_prompt=SystemPrompt("Research Agent", prompt_text),
        tools_processor=processor,
        llm_client=llm,
        config=AgentConfig(
            temperature=temperature,
            max_iter=MAX_TOOL_ITERATIONS,
            enable_logging=True,
            verbose=False,
        ),
    )

    logger.info(
        "Research Agent built: %d tools, model=%s, max_iter=%d",
        len(tools), LLM_MODEL_NAME, MAX_TOOL_ITERATIONS,
    )
    return agent
