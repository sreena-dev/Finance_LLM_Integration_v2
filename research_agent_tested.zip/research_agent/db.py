"""Postgres connection pool helpers for the research_agent.

Two separate ThreadedConnectionPool instances:
  * **Rules DB** (``RULES_DB_URL``): Ind AS standards, EAC opinions, SA 700,
    CARO/CAG, Schedule III, Ind AS appendix, and line-item rules.
  * **Reports DB** (``ANNUAL_REPORTS_DB_URL``): Company annual reports
    (documents, text_chunks, table_chunks) and SAR sections.
"""

from __future__ import annotations

import logging
from contextlib import contextmanager
import psycopg2
from psycopg2.pool import ThreadedConnectionPool

from research_agent.config import ANNUAL_REPORTS_DB_URL, RULES_DB_URL

import threading

logger = logging.getLogger("research_agent.db")

_rules_pool: ThreadedConnectionPool | None = None
_reports_pool: ThreadedConnectionPool | None = None
_pool_lock = threading.Lock()


def _init_pools():
    global _rules_pool, _reports_pool
    if _rules_pool is None or _reports_pool is None:
        with _pool_lock:
            if _rules_pool is None:
                _rules_pool = ThreadedConnectionPool(minconn=2, maxconn=20, dsn=RULES_DB_URL)
            if _reports_pool is None:
                _reports_pool = ThreadedConnectionPool(minconn=2, maxconn=20, dsn=ANNUAL_REPORTS_DB_URL)


@contextmanager
def get_rules_connection():
    """Checkout a psycopg2 connection from the rules DB pool and return it on context exit."""
    _init_pools()
    with _pool_lock:
        conn = _rules_pool.getconn()
    try:
        yield conn
    finally:
        if conn and not conn.closed:
            with _pool_lock:
                _rules_pool.putconn(conn)


@contextmanager
def get_reports_connection():
    """Checkout a psycopg2 connection from the reports DB pool and return it on context exit."""
    _init_pools()
    with _pool_lock:
        conn = _reports_pool.getconn()
    try:
        yield conn
    finally:
        if conn and not conn.closed:
            with _pool_lock:
                _reports_pool.putconn(conn)
