"""bge-m3 query embedding client for the research_agent with retry backoff.

Calls the embedding endpoint configured in ``config.py`` and returns
1024-dimensional vectors compatible with pgvector cosine-distance search.
"""

from __future__ import annotations

import logging
import time
import requests

from research_agent.config import EMBEDDING_MODEL, EMBEDDING_URL

logger = logging.getLogger("research_agent.embeddings")


def _post_with_retry(payload: dict, timeout: int = 60) -> dict | None:
    """Execute POST to embedding endpoint with 2 retries on connection/timeout errors."""
    attempts = 3
    backoff = 0.5
    for attempt in range(attempts):
        try:
            resp = requests.post(EMBEDDING_URL, json=payload, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.HTTPError as exc:
            # 4xx errors fail immediately without retry
            if exc.response is not None and 400 <= exc.response.status_code < 500:
                logger.warning("EMBEDDING_DEGRADED: HTTP %s client error for payload: %s", exc.response.status_code, exc)
                return None
            if attempt == attempts - 1:
                logger.warning("EMBEDDING_DEGRADED: Final retry failed with HTTP error: %s", exc)
                return None
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            if attempt == attempts - 1:
                logger.warning("EMBEDDING_DEGRADED: Final retry failed after network/timeout error: %s", exc)
                return None
            time.sleep(backoff)
            backoff *= 3.0
    return None


def embed_query(text: str) -> list[float]:
    """Embed a single query string into its 1024-dim bge-m3 vector."""
    res = _post_with_retry({"model": EMBEDDING_MODEL, "input": [text]}, timeout=60)
    if res and "data" in res and res["data"]:
        return res["data"][0]["embedding"]
    # Fallback: 1024 zero-vector
    return [0.0] * 1024


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed a batch of strings into 1024-dim bge-m3 vectors (order preserved)."""
    if not texts:
        return []
    res = _post_with_retry({"model": EMBEDDING_MODEL, "input": texts}, timeout=120)
    if res and "data" in res and res["data"]:
        data = sorted(res["data"], key=lambda d: d["index"])
        return [d["embedding"] for d in data]
    # Fallback: zero vectors for all texts
    return [[0.0] * 1024 for _ in texts]


def to_vector_literal(text: str) -> str:
    """Embed ``text`` and return a pgvector literal string ``[v1,v2,...]``."""
    return "[" + ",".join(str(x) for x in embed_query(text)) + "]"
