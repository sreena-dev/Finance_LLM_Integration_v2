/**
 * FINDHOST — Financial AI Agent Application Logic
 *
 * Implements stateful chat sessions with localStorage persistence,
 * real-time turn-by-turn tool inspector, zero-hallucination source citation,
 * and session state navigation.
 */

const STORAGE_KEY = "findhost_chat_sessions_v1";

let sessions = [];
let activeSessionId = null;
let isInspectorVisible = true;

document.addEventListener("DOMContentLoaded", () => {
    loadSessionsFromStorage();
    if (sessions.length === 0) {
        createNewSession(false);
    } else {
        switchSession(sessions[0].id);
    }

    const queryInput = document.getElementById("queryInput");
    if (queryInput) {
        queryInput.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submitQuery();
            }
        });
    }
});

// ---------------------------------------------------------------------------
// Session Management (Left Sidebar)
// ---------------------------------------------------------------------------

function loadSessionsFromStorage() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            sessions = JSON.parse(raw);
        }
    } catch (e) {
        console.error("Failed to load sessions from localStorage", e);
        sessions = [];
    }
}

function saveSessionsToStorage() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sessions));
    } catch (e) {
        console.error("Failed to save sessions to localStorage", e);
    }
}

function createNewSession(userInitiated = true) {
    const id = "session_" + Date.now() + "_" + Math.random().toString(36).substr(2, 6);
    const newSession = {
        id: id,
        title: "New Research Session",
        createdAt: new Date().toISOString(),
        messages: [],
        lastInspectorTools: [],
        lastLatency: null
    };

    sessions.unshift(newSession);
    saveSessionsToStorage();

    switchSession(id);

    if (userInitiated) {
        const queryInput = document.getElementById("queryInput");
        if (queryInput) {
            queryInput.value = "";
            queryInput.focus();
        }
    }
}

function switchSession(id) {
    activeSessionId = id;
    const session = sessions.find(s => s.id === id);
    if (!session) return;

    renderSessionList();
    renderSessionChat(session);
}

function deleteSession(e, id) {
    e.stopPropagation();
    sessions = sessions.filter(s => s.id !== id);
    saveSessionsToStorage();

    if (sessions.length === 0) {
        createNewSession(false);
    } else if (activeSessionId === id) {
        switchSession(sessions[0].id);
    } else {
        renderSessionList();
    }
}

function renderSessionList() {
    const container = document.getElementById("sessionList");
    if (!container) return;

    container.innerHTML = "";

    sessions.forEach(session => {
        const item = document.createElement("div");
        item.className = `chat-item ${session.id === activeSessionId ? 'active' : ''}`;
        item.onclick = () => switchSession(session.id);

        const title = escapeHtml(session.title || "Untitled Session");
        const timeStr = new Date(session.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        item.innerHTML = `
            <div class="chat-avatar"><i class="fa-solid fa-message"></i></div>
            <div class="chat-info">
                <div class="chat-title">${title}</div>
                <div class="chat-subtitle">${timeStr} · ${session.messages.length} msg(s)</div>
            </div>
            <button class="icon-btn session-delete-btn" title="Delete Session" onclick="deleteSession(event, '${session.id}')">
                <i class="fa-solid fa-trash"></i>
            </button>
        `;

        container.appendChild(item);
    });
}

function renderSessionChat(session) {
    const chatHistory = document.getElementById("chatHistory");
    const welcomeScreen = document.getElementById("welcomeScreen");
    const inspectorContent = document.getElementById("inspectorContent");
    const turnLatency = document.getElementById("turnLatency");

    if (!chatHistory) return;

    chatHistory.innerHTML = "";

    if (!session.messages || session.messages.length === 0) {
        if (welcomeScreen) welcomeScreen.classList.remove("hidden");
        if (inspectorContent) {
            inspectorContent.innerHTML = `<div class="inspector-empty">No tools executed yet in this session.</div>`;
        }
        if (turnLatency) turnLatency.innerText = "Turn Latency: — ms";
        return;
    }

    if (welcomeScreen) welcomeScreen.classList.add("hidden");

    session.messages.forEach(msg => {
        appendMessageToDom(msg.role, msg.data, false);
    });

    if (session.lastInspectorTools && session.lastInspectorTools.length > 0) {
        populateInspector(session.lastInspectorTools, session.lastLatency || "—");
    } else if (inspectorContent) {
        inspectorContent.innerHTML = `<div class="inspector-empty">No tools executed in recent turn.</div>`;
        if (turnLatency) turnLatency.innerText = "Turn Latency: — ms";
    }

    const outputContainer = document.getElementById("chatOutput");
    if (outputContainer) {
        outputContainer.scrollTop = outputContainer.scrollHeight;
    }
}

// ---------------------------------------------------------------------------
// Tool Inspector Panel (Right Sidebar)
// ---------------------------------------------------------------------------

function toggleInspector() {
    const inspector = document.getElementById("inspectorPanel");
    if (!inspector) return;

    if (isInspectorVisible) {
        inspector.classList.add("hidden");
        isInspectorVisible = false;
    } else {
        inspector.classList.remove("hidden");
        isInspectorVisible = true;
    }
}

function populateInspector(tools, latencyMs) {
    const turnLatency = document.getElementById("turnLatency");
    if (turnLatency) turnLatency.innerText = `Turn Latency: ${latencyMs}ms`;

    const container = document.getElementById("inspectorContent");
    if (!container) return;

    container.innerHTML = "";

    if (!tools || tools.length === 0) {
        container.innerHTML = `<div class="inspector-empty">No tools executed during this turn.</div>`;
        return;
    }

    tools.forEach((tool, index) => {
        const block = document.createElement("div");
        block.className = "inspector-block";

        let hasError = false;
        if (typeof tool.output === 'string') {
            hasError = tool.output.indexOf("error") !== -1;
        } else if (tool.output && typeof tool.output === 'object') {
            hasError = tool.output.status === "error";
        }

        const isPass = !hasError;
        const scoreText = isPass ? "PASS (1.00)" : "ERROR (0.00)";
        const timestamp = tool.timestamp || new Date().toLocaleTimeString();

        const argsJson = escapeHtml(JSON.stringify(tool.arguments || {}, null, 2));

        let sourcesHtml = "";
        if (tool.sources && tool.sources.length > 0) {
            sourcesHtml = `<div class="inspector-json-label" style="margin-top: 10px;">Sources Referenced:</div>
            <ul style="margin: 5px 0; padding-left: 18px; font-size: 0.82em; color: #555;">`;
            tool.sources.forEach(src => {
                const doc = src.doc_id || "Doc";
                const pg = src.page ? ` (p.${src.page})` : "";
                const cls = src.clause_ref ? ` [Clause ${src.clause_ref}]` : "";
                sourcesHtml += `<li>${escapeHtml(doc)}${escapeHtml(pg)}${escapeHtml(cls)}</li>`;
            });
            sourcesHtml += `</ul>`;
        }

        block.innerHTML = `
            <div class="inspector-block-header" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="font-weight: 600;">${index + 1}. ${escapeHtml(tool.tool_name)}</span>
                <span class="status ${isPass ? 'pass' : 'fail'}" style="font-size: 0.8em; padding: 2px 6px; border-radius: 4px; ${isPass ? 'background: #e8f5e9; color: #2e7d32;' : 'background: #ffebee; color: #c62828;'}">${scoreText}</span>
            </div>
            <div style="font-size: 0.78em; color: #777; margin-bottom: 6px;">Executed at: ${escapeHtml(timestamp)}</div>
            <div class="inspector-json-label">Input Parameters:</div>
            <div class="inspector-json" style="background: #f8f9fa; padding: 6px; border-radius: 4px; font-size: 0.8em; font-family: monospace; overflow-x: auto;">${argsJson}</div>
            ${sourcesHtml}
        `;
        container.appendChild(block);
    });
}

// ---------------------------------------------------------------------------
// Chat Workspace & Message Dispatch
// ---------------------------------------------------------------------------

function fillAndSubmit(text) {
    const input = document.getElementById("queryInput");
    if (input) {
        input.value = text;
        submitQuery();
    }
}

function escapeHtml(unsafe) {
    return (unsafe || "").toString()
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

function toggleAccordion(element) {
    const content = element.nextElementSibling;
    if (content) {
        content.classList.toggle("hidden");
    }
}

function appendMessageToDom(role, data, scroll = true) {
    const chatHistory = document.getElementById("chatHistory");
    if (!chatHistory) return;

    const msgDiv = document.createElement("div");
    msgDiv.className = `chat-message message-${role}`;

    if (role === "user") {
        msgDiv.innerHTML = escapeHtml(data);
    } else {
        let html = "";

        if (data.tools_used && data.tools_used.length > 0) {
            let toolsHtml = "";
            let passCount = 0;

            data.tools_used.forEach(tool => {
                let hasError = false;
                if (typeof tool.output === 'string') {
                    hasError = tool.output.indexOf("error") !== -1;
                } else if (tool.output && typeof tool.output === 'object') {
                    hasError = tool.output.status === "error";
                }

                const scoreText = hasError ? "ERROR (0.00)" : "Score: 1.00 (PASS)";
                const scoreClass = hasError ? "fail" : "pass";

                toolsHtml += `
                    <div class="tool-row">
                        <span class="tool-name">${escapeHtml(tool.tool_name)}</span>
                        <span class="tool-score ${scoreClass}">${scoreText}</span>
                    </div>
                `;
            });

            const latency = data.execution_time_seconds ? (data.execution_time_seconds * 1000).toFixed(0) : "850";

            html += `
                <div class="ai-tools-accordion">
                    <div class="ai-tools-summary" onclick="toggleAccordion(this)">
                        <span><i class="fa-solid fa-hammer icon-hammer"></i> Executed ${data.tools_used.length} Tool Call(s) (${latency}ms)</span>
                        <i class="fa-solid fa-caret-down"></i>
                    </div>
                    <div class="ai-tools-content hidden">
                        ${toolsHtml}
                    </div>
                </div>
            `;
        }

        let responseText = typeof data === 'object' ? (data.response || JSON.stringify(data)) : data;
        let contentHtml = window.marked ? marked.parse(responseText) : `<p>${escapeHtml(responseText)}</p>`;
        html += `<div class="markdown-body">${contentHtml}</div>`;

        msgDiv.innerHTML = html;
    }

    chatHistory.appendChild(msgDiv);

    if (scroll) {
        const outputContainer = document.getElementById("chatOutput");
        if (outputContainer) {
            outputContainer.scrollTop = outputContainer.scrollHeight;
        }
    }
}

async function submitQuery() {
    const queryInput = document.getElementById("queryInput");
    if (!queryInput) return;

    const query = queryInput.value.trim();
    if (!query) return;

    const session = sessions.find(s => s.id === activeSessionId);
    if (!session) return;

    if (session.messages.length === 0) {
        session.title = query.length > 32 ? query.substring(0, 32) + "..." : query;
    }

    document.getElementById("welcomeScreen").classList.add("hidden");

    // Push User message
    const userMsg = { role: "user", data: query, timestamp: new Date().toISOString() };
    session.messages.push(userMsg);

    appendMessageToDom("user", query);
    queryInput.value = "";

    const loadingState = document.getElementById("loadingState");
    if (loadingState) loadingState.classList.remove("hidden");

    const submitBtn = document.getElementById("submitBtn");
    if (submitBtn) submitBtn.disabled = true;

    const startTime = Date.now();

    try {
        const response = await fetch("/api/query", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: query, temperature: 0.2 })
        });

        if (!response.ok) {
            throw new Error(`API Error: ${response.statusText}`);
        }

        const data = await response.json();
        const latencyMs = Date.now() - startTime;

        if (loadingState) loadingState.classList.add("hidden");

        const aiMsg = { role: "ai", data: data, timestamp: new Date().toISOString() };
        session.messages.push(aiMsg);

        session.lastInspectorTools = data.tools_used || [];
        session.lastLatency = latencyMs;

        saveSessionsToStorage();
        renderSessionList();

        appendMessageToDom("ai", data);
        populateInspector(data.tools_used || [], latencyMs);

    } catch (err) {
        if (loadingState) loadingState.classList.add("hidden");
        const errMsg = { role: "ai", data: { response: `Error: ${err.message}`, tools_used: [] }, timestamp: new Date().toISOString() };
        session.messages.push(errMsg);
        saveSessionsToStorage();
        appendMessageToDom("ai", errMsg.data);
    } finally {
        if (submitBtn) submitBtn.disabled = false;
        queryInput.focus();
        const outputContainer = document.getElementById("chatOutput");
        if (outputContainer) outputContainer.scrollTop = outputContainer.scrollHeight;
    }
}
