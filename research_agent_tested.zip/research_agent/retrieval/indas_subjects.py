"""Ind AS subject-line lookup table.

Maps each Ind AS standard number to its canonical subject so queries
referencing "Ind AS 2" can be expanded with the subject "Inventories" for
better retrieval recall against annual reports that describe policies by
topic rather than by standard number.
"""

from __future__ import annotations

IND_AS_SUBJECTS: dict[int, str] = {
    1: "Presentation of Financial Statements",
    2: "Inventories",
    7: "Statement of Cash Flows",
    8: "Accounting Policies, Changes in Accounting Estimates and Errors",
    10: "Events after the Reporting Period",
    12: "Income Taxes",
    16: "Property, Plant and Equipment",
    17: "Leases",  # superseded by Ind AS 116
    19: "Employee Benefits",
    20: "Accounting for Government Grants",
    21: "Effects of Changes in Foreign Exchange Rates",
    23: "Borrowing Costs",
    24: "Related Party Disclosures",
    27: "Separate Financial Statements",
    28: "Investments in Associates and Joint Ventures",
    29: "Financial Reporting in Hyperinflationary Economies",
    32: "Financial Instruments: Presentation",
    33: "Earnings per Share",
    34: "Interim Financial Reporting",
    36: "Impairment of Assets",
    37: "Provisions, Contingent Liabilities and Contingent Assets",
    38: "Intangible Assets",
    40: "Investment Property",
    41: "Agriculture",
    101: "First-time Adoption of Ind AS",
    102: "Share-based Payment",
    103: "Business Combinations",
    104: "Insurance Contracts",
    105: "Non-current Assets Held for Sale and Discontinued Operations",
    106: "Exploration for and Evaluation of Mineral Resources",
    107: "Financial Instruments: Disclosures",
    108: "Operating Segments",
    109: "Financial Instruments",
    110: "Consolidated Financial Statements",
    111: "Joint Arrangements",
    112: "Disclosure of Interests in Other Entities",
    113: "Fair Value Measurement",
    114: "Regulatory Deferral Accounts",
    115: "Revenue from Contracts with Customers",
    116: "Leases",
}
