"""SAR (Statutory Auditor Report) section extraction from the annual-report corpus.

Pulls complete auditor-report sections from text_chunks using section-label
filtering (not embedding search), guaranteeing full coverage of the report's
clauses and paragraphs.

Also provides the ``search_line_item_rules`` keyword lookup.
"""

from __future__ import annotations

import logging
import re

from research_agent.db import get_reports_connection, get_rules_connection

logger = logging.getLogger("research_agent.retrieval.sar")

# ---------------------------------------------------------------------------
# Section-name patterns for SAR sections in text_chunks
# ---------------------------------------------------------------------------

_SAR_SECTION_PATTERNS = [
    "%independent auditor%report%",
    "%statutory auditor%report%",
    "%auditor%report%",
    "%basis for%opinion%",
    "%basis of%opinion%",
    "%emphasis of matter%",
    "%other matter%",
    "%key audit matter%",
    "%going concern%",
    "%other legal and regulatory%",
    "%report on other legal%",
    "%rule 11%",
    "%section 143%",
    "%managerial remuneration%",
    "%annexure%to%auditor%",
    "%internal financial control%",
    "%internal control%financial%",
    "%caro%",
    "%caro 2020%",
    "%companies auditor%report%order%",
    "%annexure a%",
    "%annexure b%",
    "%annexure c%",
]

# Sub-section classification
_MAIN_PATTERNS = [
    "%independent auditor%report%",
    "%statutory auditor%report%",
    "%basis for%opinion%",
    "%basis of%opinion%",
    "%emphasis of matter%",
    "%other matter%",
    "%key audit matter%",
    "%going concern%",
    "%other legal and regulatory%",
    "%report on other legal%",
    "%rule 11%",
    "%section 143%",
    "%managerial remuneration%",
]

_CARO_PATTERNS = [
    "%caro%",
    "%caro 2020%",
    "%companies auditor%report%order%",
    "%annexure a%",
    "%annexure b%",
]

_IFC_PATTERNS = [
    "%internal financial control%",
    "%internal control%financial%",
    "%annexure b%",
    "%annexure c%",
]

_DR_PATTERNS = [
    "%director%report%",
    "%directors%report%",
    "%management discussion%",
    "%management%analysis%",
    "%board%report%",
]

# Financial statement sections
_FS_PATTERNS = [
    "%balance sheet%",
    "%statement of profit%",
    "%profit and loss%",
    "%statement of cash flow%",
    "%changes in equity%",
    "%notes to%financial%",
    "%notes forming%",
]


# ---------------------------------------------------------------------------
# Document lookup
# ---------------------------------------------------------------------------


def get_document_info(company: str, fy_start: int, fy_end: int) -> dict | None:
    """Find a document by company name and fiscal year in the reports DB."""
    if fy_end < 100:
        fy_end = 2000 + fy_end
    if fy_start < 100:
        fy_start = 2000 + fy_start
    if fy_end <= fy_start:
        fy_end = fy_start + 1

    clean_company = company.strip()
    company_pattern = f"%{re.sub(r'[\s_]+', '%', clean_company)}%"

    conn = get_reports_connection()
    try:
        with conn.cursor() as cur:
            # 1. Try exact/pattern match with exact FY
            cur.execute(
                """
                SELECT doc_id, company, fy_start, fy_end, doc_name
                FROM documents
                WHERE (company ILIKE %s OR REPLACE(company, '_', ' ') ILIKE %s)
                  AND fy_start = %s AND fy_end = %s
                LIMIT 1
                """,
                (company_pattern, f"%{clean_company}%", fy_start, fy_end),
            )
            row = cur.fetchone()
            if not row:
                # 2. Try company match with fy_start
                cur.execute(
                    """
                    SELECT doc_id, company, fy_start, fy_end, doc_name
                    FROM documents
                    WHERE (company ILIKE %s OR REPLACE(company, '_', ' ') ILIKE %s)
                      AND fy_start = %s
                    LIMIT 1
                    """,
                    (company_pattern, f"%{clean_company}%", fy_start),
                )
                row = cur.fetchone()
            if not row:
                # 3. Try company match alone (latest)
                cur.execute(
                    """
                    SELECT doc_id, company, fy_start, fy_end, doc_name
                    FROM documents
                    WHERE (company ILIKE %s OR REPLACE(company, '_', ' ') ILIKE %s)
                    ORDER BY fy_start DESC
                    LIMIT 1
                    """,
                    (company_pattern, f"%{clean_company}%"),
                )
                row = cur.fetchone()
            if not row:
                return None
            cols = [d.name for d in cur.description]
            return dict(zip(cols, row))
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Full-text section extraction
# ---------------------------------------------------------------------------


def _extract_sections(doc_id, patterns: list[str]) -> str:
    """Pull all text_chunks matching any of the section patterns in reading order."""
    likes_sec = " OR ".join(["c.section ILIKE %s"] * len(patterns))
    likes_cnt = " OR ".join(["c.content ILIKE %s"] * len(patterns))
    sql = f"""
        SELECT c.content, c.page_ocr_start AS page
        FROM text_chunks c
        WHERE c.doc_id = %s AND (({likes_sec}) OR ({likes_cnt}))
        ORDER BY c.page_ocr_start, c.chunk_id
    """
    conn = get_reports_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (doc_id, *patterns, *patterns))
            rows = cur.fetchall()
    finally:
        conn.close()
    if not rows:
        # Fallback: pull top text chunks for this document if pattern match yielded nothing
        fallback_sql = """
            SELECT c.content, c.page_ocr_start AS page
            FROM text_chunks c
            WHERE c.doc_id = %s
            ORDER BY c.page_ocr_start, c.chunk_id
            LIMIT 15
        """
        conn = get_reports_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(fallback_sql, (doc_id,))
                rows = cur.fetchall()
        finally:
            conn.close()

    res = "\n\n".join(r[0] for r in rows if r[0])
    if len(res) > 20000:
        res = res[:20000].rstrip() + "\n\n… (section text truncated to fit model context limit)"
    return res


def extract_main_report(doc_id) -> str:
    """Extract the main statutory auditor report text."""
    return _extract_sections(doc_id, _MAIN_PATTERNS)


def extract_caro_clauses(doc_id) -> str:
    """Extract the CARO 2020 Annexure text."""
    return _extract_sections(doc_id, _CARO_PATTERNS)


def extract_ifc_report(doc_id) -> str:
    """Extract the Internal Financial Controls (IFC) annexure text."""
    return _extract_sections(doc_id, _IFC_PATTERNS)


def extract_directors_report(doc_id) -> str:
    """Extract the Directors' Report and MD&A text."""
    return _extract_sections(doc_id, _DR_PATTERNS)


def extract_fs_tables(doc_id) -> str:
    """Extract financial statement tables as markdown."""
    # Pull table_chunks for the document
    sql = """
        SELECT NULLIF(TRIM(BOTH ': ' FROM COALESCE(t.table_title, '') || ': '
               || COALESCE(t.table_description, '')), '') AS content,
               t.table_md, t.unit, t.currency, t.page_ocr_start AS page
        FROM table_chunks t
        WHERE t.doc_id = %s AND t.is_financial = true
        ORDER BY t.page_ocr_start, t.table_id
    """
    conn = get_reports_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, (doc_id,))
            cols = [d.name for d in cur.description]
            rows = [dict(zip(cols, r)) for r in cur.fetchall()]
    finally:
        conn.close()

    if not rows:
        # Fallback to text_chunks with FS section patterns
        return _extract_sections(doc_id, _FS_PATTERNS)

    blocks = []
    for r in rows:
        header = (r.get("content") or "").strip()
        unit_parts = " · ".join(x for x in (r.get("currency"), r.get("unit")) if x)
        if unit_parts:
            header = f"{header} ({unit_parts})" if header else f"(amounts in {unit_parts})"
        md = (r.get("table_md") or "").strip()
        if md:
            blocks.append(f"{header}\n{md}" if header else md)
        elif header:
            blocks.append(header)
    res = "\n\n---\n\n".join(blocks) if blocks else "Financial statement tables not found."
    if len(res) > 20000:
        res = res[:20000].rstrip() + "\n\n… (financial statement tables truncated to fit model context limit)"
    return res


# ---------------------------------------------------------------------------
# Line-item rules keyword search
# ---------------------------------------------------------------------------


def search_line_item_rules(query: str, top_k: int = 10) -> str:
    """Search the reference line-item rules table for regulation mappings.

    Returns the chunk_text of matching rows (keyword search on chunk_text).
    Falls back gracefully if the table does not exist.
    """
    try:
        conn = get_rules_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT chunk_text FROM line_item_rules
                    WHERE chunk_text ILIKE %s
                    LIMIT %s
                    """,
                    (f"%{query}%", int(top_k)),
                )
                rows = cur.fetchall()
        finally:
            conn.close()
        if not rows:
            return (
                f"No line-item rule entries found for query '{query}'. "
                "The reference sheet may not have been ingested yet."
            )
        return "\n\n---\n\n".join(r[0] for r in rows)
    except Exception as exc:
        return (
            f"search_line_item_rules: could not query table — {exc}. "
            "Ensure the line_item_rules table has been populated."
        )
