"""Hybrid (dense + lexical) retrieval over the annual-report corpus.

Searches ``text_chunks`` and ``table_chunks`` (joined with ``documents``) in
the reports database. Combines dense cosine similarity with keyword-boosted
lexical matching for high recall on company-specific financial data.
"""

from __future__ import annotations

import logging
import re

from research_agent.db import get_reports_connection
from research_agent.embeddings import to_vector_literal
from research_agent.retrieval.indas_subjects import IND_AS_SUBJECTS

logger = logging.getLogger("research_agent.retrieval.annual_report")

_INDAS_RE = re.compile(r"ind\s*as[\s\-]*?(\d{1,3})", re.I)
_STOPWORDS = {"the", "of", "and", "in", "for", "to", "a", "an", "on", "as"}
_QUERY_STOP = {
    "accounting", "policy", "policies", "report", "reports", "annual", "company",
    "companies", "financial", "statement", "statements", "related", "value", "values",
    "amount", "amounts", "under", "about", "detail", "details", "regarding", "which",
    "information", "during", "between", "please", "provide", "total", "their", "there",
    "what", "where", "list", "show", "given", "year", "years", "assets",
}

# cap on a single table's markdown fed to the model
_TABLE_MD_CAP = 4000

# ---------------------------------------------------------------------------
# SQL templates
# ---------------------------------------------------------------------------

_AR_TEXT_SQL = """
    SELECT 'text' AS kind, dc.company, dc.fy_start, dc.fy_end, dc.doc_name,
           c.section, c.page_ocr_start AS page, c.chunk_id AS pos_id, c.content,
           1 - (c.embedding <=> %s::vector) AS score
    FROM text_chunks c
    JOIN documents dc ON dc.doc_id = c.doc_id
    WHERE c.embedding IS NOT NULL{filt}
    ORDER BY c.embedding <=> %s::vector
    LIMIT %s
"""

_AR_TABLE_SQL = """
    SELECT 'table' AS kind, dc.company, dc.fy_start, dc.fy_end, dc.doc_name,
           t.section, t.page_ocr_start AS page, t.table_id AS pos_id,
           NULLIF(TRIM(BOTH ': ' FROM COALESCE(t.table_title, '') || ': '
                  || COALESCE(t.table_description, '')), '') AS content,
           t.table_md, t.unit, t.currency,
           1 - (t.description_embedding <=> %s::vector) AS score
    FROM table_chunks t
    JOIN documents dc ON dc.doc_id = t.doc_id
    WHERE t.description_embedding IS NOT NULL{filt}
    ORDER BY t.description_embedding <=> %s::vector
    LIMIT %s
"""


def _query(sql: str, params: tuple) -> list[dict]:
    conn = get_reports_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [c.name for c in cur.description]
            rows = cur.fetchall()
    finally:
        conn.close()
    return [dict(zip(cols, r)) for r in rows]


# ---------------------------------------------------------------------------
# Query expansion
# ---------------------------------------------------------------------------


def expand_ar_query(query: str) -> tuple[str, list[str]]:
    """Expand query with Ind AS subjects and return ``(expanded, keywords)``."""
    nums = [int(n) for n in _INDAS_RE.findall(query)]
    subjects = [IND_AS_SUBJECTS[n] for n in nums if n in IND_AS_SUBJECTS]

    expanded = query
    if subjects:
        expanded = f"{query} ({'; '.join(subjects)})"

    keywords: list[str] = []
    for subj in subjects:
        for w in re.split(r"[^A-Za-z]+", subj):
            if len(w) > 3 and w.lower() not in _STOPWORDS:
                keywords.append(f"%{w}%")
    for n in nums:
        keywords.append(f"%Ind AS {n}%")
        keywords.append(f"%Ind AS-{n}%")

    # Deduplicate
    seen, out = set(), []
    for k in keywords:
        if k.lower() not in seen:
            seen.add(k.lower())
            out.append(k)
    return expanded, out


# ---------------------------------------------------------------------------
# Main retrieval function
# ---------------------------------------------------------------------------

_KEYWORD_BOOST = 0.15


def retrieve_annual_reports(query: str, top_k: int = 5) -> list[dict]:
    """Hybrid (dense + lexical) annual-report search.

    Combines dense cosine similarity over text_chunks and table_chunks with
    a lexical pass that boosts chunks containing query/subject keywords.
    """
    expanded, keywords = expand_ar_query(query)
    vec = to_vector_literal(expanded)

    filt = ""
    doc_p: list = []

    text_sql = _AR_TEXT_SQL.format(filt=filt)
    table_sql = _AR_TABLE_SQL.format(filt=filt)

    tagged: list[tuple[float, dict]] = []
    for r in _query(text_sql, (vec, *doc_p, vec, top_k)):
        tagged.append((0.0, r))
    for r in _query(table_sql, (vec, *doc_p, vec, max(2, top_k // 2))):
        if r.get("content"):
            tagged.append((0.0, r))

    # Lexical pass: boost chunks matching query/subject keywords
    if keywords:
        cnt = " + ".join(["(c.content ILIKE %s)::int"] * len(keywords))
        kw_sql = f"""
            SELECT 'text' AS kind, dc.company, dc.fy_start, dc.fy_end, dc.doc_name,
                   c.section, c.page_ocr_start AS page, c.chunk_id AS pos_id, c.content,
                   1 - (c.embedding <=> %s::vector) AS score, ({cnt}) AS kwmatches
            FROM text_chunks c
            JOIN documents dc ON dc.doc_id = c.doc_id
            WHERE c.embedding IS NOT NULL AND c.content ILIKE ANY(%s){filt}
            ORDER BY kwmatches DESC, c.embedding <=> %s::vector
            LIMIT %s
        """
        params = (vec, *keywords, keywords, *doc_p, vec, top_k)
        for r in _query(kw_sql, params):
            tagged.append((_KEYWORD_BOOST * max(1, r.get("kwmatches") or 0), r))

    # Deduplicate: keep the highest-boosted version of each chunk
    seen: dict[tuple, int] = {}
    for i, (boost, r) in enumerate(tagged):
        key = (r.get("company"), r.get("fy_start"), r.get("page"), r.get("kind"),
               (r.get("content") or "")[:60])
        if key not in seen:
            seen[key] = i
        else:
            prev_boost = tagged[seen[key]][0]
            if boost > prev_boost:
                seen[key] = i

    deduped = [tagged[i] for i in sorted(seen.values())]
    deduped.sort(key=lambda x: -(x[1].get("score", 0) + x[0]))
    results = [r for _, r in deduped[:top_k]]
    return results


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def _table_body(r: dict) -> str:
    """Header (title + unit/currency) followed by the table's markdown cells."""
    header = (r.get("content") or "").strip()
    unit, cur = r.get("unit"), r.get("currency")
    units = " · ".join(x for x in (cur, unit) if x)
    if units:
        header = f"{header} ({units})" if header else f"(amounts in {units})"
    md = (r.get("table_md") or "").strip()
    if md:
        if len(md) > _TABLE_MD_CAP:
            md = md[:_TABLE_MD_CAP].rstrip() + "\n… (table truncated)"
        return f"{header}\n{md}" if header else md
    return header or "(table content unavailable)"


def ar_blocks(rows: list[dict]) -> list[str]:
    """One citation-tagged block per annual-report chunk."""
    out = []
    for r in rows:
        fy = f"FY{r['fy_start']}-{str(r['fy_end'])[-2:]}"
        if r["kind"] == "table":
            cite = f"[{r['company']} {fy}, Table, p{r['page']}]"
            out.append(f"{cite}\n{_table_body(r)}")
        else:
            tag = r.get("section") or "text"
            cite = f"[{r['company']} {fy}, {tag}, p{r['page']}]"
            out.append(f"{cite}\n{r['content']}")
    return out


def fmt_annual_reports(rows: list[dict]) -> str:
    return "\n\n---\n\n".join(ar_blocks(rows)) if rows else "No annual report results found."
