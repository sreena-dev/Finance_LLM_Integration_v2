"""Dense retrieval over the Ind AS standards corpus.

Searches ``ind_as_chunks`` (joined with ``ind_as_documents``) in the rules
database using pgvector cosine similarity. Also supports enumeration mode
for listing all ingested standards or standards cited in a company's report.
"""

from __future__ import annotations

import logging
import re

from research_agent.db import get_rules_connection, get_reports_connection
from research_agent.embeddings import to_vector_literal
from research_agent.retrieval.indas_subjects import IND_AS_SUBJECTS

logger = logging.getLogger("research_agent.retrieval.ind_as")

_INDAS_RE = re.compile(r"ind\s*as[\s\-]*?(\d{1,3})", re.I)

# ---------------------------------------------------------------------------
# SQL templates
# ---------------------------------------------------------------------------

_IND_AS_SQL = """
    SELECT d.standard_number, d.document_title, c.section_title, c.paragraph_no,
           c.page_no, c.seq, c.text,
           1 - (c.embedding <=> %s::vector) AS score
    FROM ind_as_chunks c
    JOIN ind_as_documents d ON d.doc_id = c.doc_id
    WHERE c.embedding IS NOT NULL{filt}
    ORDER BY c.embedding <=> %s::vector
    LIMIT %s
"""


def _query_rules(sql: str, params: tuple) -> list[dict]:
    try:
        conn = get_reports_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                cols = [c.name for c in cur.description]
                rows = cur.fetchall()
                if rows:
                    return [dict(zip(cols, r)) for r in rows]
        finally:
            conn.close()
    except Exception:
        pass

    conn = get_rules_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [c.name for c in cur.description]
            rows = cur.fetchall()
    finally:
        conn.close()
    return [dict(zip(cols, r)) for r in rows]


def _query_reports(sql: str, params: tuple) -> list[dict]:
    conn = get_reports_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [c.name for c in cur.description]
            rows = cur.fetchall()
    finally:
        conn.close()
    return [dict(zip(cols, r)) for r in rows]


# ---------------------------------------------------------------------------
# Dense retrieval
# ---------------------------------------------------------------------------


def _order_by_document(rows: list[dict]) -> list[dict]:
    """Re-order by document relevance then reading position."""
    best: dict = {}
    for r in rows:
        k = r["standard_number"]
        s = r["score"]
        if k not in best or s > best[k]:
            best[k] = s
    return sorted(rows, key=lambda r: (-best[r["standard_number"]], r["standard_number"], r["seq"]))


def retrieve_ind_as(query: str, top_k: int = 5, vec: str | None = None) -> list[dict]:
    """Return top_k Ind AS chunks by cosine similarity.

    When the query mentions specific standard numbers (e.g. "Ind AS 115"),
    restricts the search to those standards for better precision.
    """
    vec = vec or to_vector_literal(query)
    nums = [int(n) for n in _INDAS_RE.findall(query)]
    if nums:
        sql = _IND_AS_SQL.format(filt=" AND d.standard_number = ANY(%s)")
        rows = _query_rules(sql, (vec, list(nums), vec, top_k))
    else:
        sql = _IND_AS_SQL.format(filt="")
        rows = _query_rules(sql, (vec, vec, top_k))
    return _order_by_document(rows)


# ---------------------------------------------------------------------------
# Enumeration (list mode)
# ---------------------------------------------------------------------------


def list_ind_as_catalog() -> list[tuple[int, str]]:
    """List all Ind AS standards ingested in the rules database."""
    sql = """
        SELECT DISTINCT d.standard_number, d.document_title
        FROM ind_as_documents d
        ORDER BY d.standard_number
    """
    rows = _query_rules(sql, ())
    return [(r["standard_number"], r.get("document_title", "")) for r in rows]


def list_ind_as_in_docs(query: str) -> dict | None:
    """List Ind AS standards substantively cited in a company's report.

    Parses the query to detect a company name and/or FY range, then counts
    in-text citations of "Ind AS N" in the report's text_chunks. Returns
    None if no company context is detected.
    """
    # Simple heuristic: look for company-like words and FY patterns
    fy_match = re.search(r"FY\s*(\d{4})\s*[-–]\s*(\d{2,4})", query, re.I)
    if not fy_match:
        return None

    fy_start = int(fy_match.group(1))
    fy_end_raw = fy_match.group(2)
    fy_end = int(fy_end_raw) if len(fy_end_raw) == 4 else int(str(fy_start)[:2] + fy_end_raw)

    # Extract company name (everything before "FY" or after common prepositions)
    company_part = query[:fy_match.start()].strip()
    company_part = re.sub(r"\b(list|which|what|ind\s*as|standards?|in|of|for|mentioned|cited|are)\b",
                          "", company_part, flags=re.I).strip()
    if not company_part:
        return None

    sql = """
        SELECT dc.doc_id, dc.company, dc.fy_start, dc.fy_end
        FROM documents dc
        WHERE dc.company ILIKE %s AND dc.fy_start = %s AND dc.fy_end = %s
        LIMIT 1
    """
    docs = _query_reports(sql, (f"%{company_part}%", fy_start, fy_end))
    if not docs:
        return None

    doc = docs[0]
    # Count Ind AS citations in the report's text_chunks
    cite_sql = """
        SELECT c.content FROM text_chunks c
        WHERE c.doc_id = %s AND c.content IS NOT NULL
    """
    chunks = _query_reports(cite_sql, (doc["doc_id"],))
    counts: dict[int, int] = {}
    for chunk in chunks:
        for m in _INDAS_RE.finditer(chunk.get("content", "")):
            n = int(m.group(1))
            counts[n] = counts.get(n, 0) + 1

    # Filter out incidental single mentions
    standards = []
    for n, c in sorted(counts.items(), key=lambda x: -x[1]):
        if c >= 2:
            subj = IND_AS_SUBJECTS.get(n, "")
            standards.append((n, subj, c))

    return {
        "docs": [(doc["doc_id"], doc["company"], doc["fy_start"], doc["fy_end"])],
        "standards": standards,
    }


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def ind_as_blocks(rows: list[dict]) -> list[str]:
    """One citation-tagged block per Ind AS chunk (full text; no truncation)."""
    out = []
    for r in rows:
        para = r.get("paragraph_no") or "-"
        cite = f"[Ind AS {r['standard_number']} — {r['section_title']}, para {para}, p{r['page_no']}]"
        out.append(f"{cite}\n{r['text']}")
    return out


def fmt_ind_as(rows: list[dict]) -> str:
    return "\n\n---\n\n".join(ind_as_blocks(rows)) if rows else "No Ind AS results found."


def fmt_catalog(items: list[tuple[int, str]]) -> str:
    lines = [f"- Ind AS {n}: {subj}" if subj else f"- Ind AS {n}" for n, subj in items]
    return f"Ingested Indian Accounting Standards ({len(items)}):\n" + "\n".join(lines)


def fmt_list_in_docs(d: dict) -> str:
    head = ", ".join(f"{c} FY{fs}-{str(fe)[-2:]}" for _, c, fs, fe in d["docs"])
    stds = d["standards"]
    if not stds:
        return f"No Ind AS standards were found substantively cited in: {head}."
    lines = [f"- Ind AS {n}: {subj} ({m} mention{'s' if m != 1 else ''})" if subj
             else f"- Ind AS {n} ({m} mention{'s' if m != 1 else ''})"
             for n, subj, m in stds]
    return (f"Ind AS standards substantively cited in {head} "
            f"({len(stds)} found, most-cited first):\n" + "\n".join(lines) +
            "\n\n(One-off incidental mentions are excluded.)")
