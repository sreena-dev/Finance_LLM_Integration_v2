"""Tests for the response envelope builder."""

import pytest
from research_agent.tools.response import ok, not_found, ambiguous, error, make_source, clamp_confidence


class TestMakeSource:
    def test_minimal(self):
        s = make_source(doc_id="doc1")
        assert s == {"doc_id": "doc1", "page": None, "clause_ref": None, "as_of_date": None}

    def test_full(self):
        s = make_source(doc_id="doc1", page=5, clause_ref="para 9", as_of_date="2024-01-01")
        assert s["page"] == 5
        assert s["clause_ref"] == "para 9"


class TestClampConfidence:
    def test_none(self):
        assert clamp_confidence(None) is None

    def test_normal(self):
        assert clamp_confidence(0.5) == 0.5

    def test_above_one(self):
        assert clamp_confidence(1.5) == 1.0

    def test_below_zero(self):
        assert clamp_confidence(-0.3) == 0.0


class TestOk:
    def test_basic(self):
        r = ok(data={"answer": 42}, confidence=0.9, confidence_basis="exact match")
        assert r["status"] == "ok"
        assert r["data"]["answer"] == 42
        assert r["confidence"] == 0.9
        assert r["confidence_basis"] == "exact match"
        assert r["ambiguity_note"] is None
        assert isinstance(r["sources"], list)

    def test_with_sources(self):
        src = make_source("d1", page=3)
        r = ok(data="text", sources=[src])
        assert len(r["sources"]) == 1
        assert r["sources"][0]["doc_id"] == "d1"


class TestNotFound:
    def test_default(self):
        r = not_found()
        assert r["status"] == "not_found"
        assert "message" in r["data"]

    def test_custom_message(self):
        r = not_found("Nothing here")
        assert r["data"]["message"] == "Nothing here"


class TestAmbiguous:
    def test_structure(self):
        r = ambiguous(candidates=["A", "B"], note="Two matches")
        assert r["status"] == "ambiguous"
        assert r["data"]["candidates"] == ["A", "B"]
        assert r["ambiguity_note"] == "Two matches"


class TestError:
    def test_structure(self):
        r = error("something broke")
        assert r["status"] == "error"
        assert r["data"]["error"] == "something broke"
        assert r["confidence"] is None
