"""Shared test fixtures for the research_agent test suite.

Provides mock database connections and common test data to allow
unit testing without live database access.
"""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Mock database rows
# ---------------------------------------------------------------------------

MOCK_DOCUMENTS = [
    {"doc_id": 1, "company": "ONGC", "fy_start": 2023, "fy_end": 2024, "doc_name": "ONGC_AR_2023-24"},
    {"doc_id": 2, "company": "BPCL", "fy_start": 2023, "fy_end": 2024, "doc_name": "BPCL_AR_2023-24"},
    {"doc_id": 3, "company": "Coal India Limited", "fy_start": 2023, "fy_end": 2024, "doc_name": "CIL_AR_2023-24"},
    {"doc_id": 4, "company": "HPCL", "fy_start": 2023, "fy_end": 2024, "doc_name": "HPCL_AR_2023-24"},
    {"doc_id": 5, "company": "NTPC Limited", "fy_start": 2023, "fy_end": 2024, "doc_name": "NTPC_AR_2023-24"},
    {"doc_id": 6, "company": "IOCL", "fy_start": 2023, "fy_end": 2024, "doc_name": "IOCL_AR_2023-24"},
    {"doc_id": 7, "company": "Oil and Natural Gas Corporation", "fy_start": 2022, "fy_end": 2023, "doc_name": "ONGC_AR_2022-23"},
]

MOCK_IND_AS_CLAUSES = [
    {
        "standard_number": 115, "document_title": "Revenue from Contracts with Customers",
        "section_title": "Recognition", "paragraph_no": "9", "page_no": 5, "seq": 1,
        "text": "An entity shall recognise revenue when (or as) the entity satisfies a performance obligation.",
    },
    {
        "standard_number": 115, "document_title": "Revenue from Contracts with Customers",
        "section_title": "5-Step Model", "paragraph_no": "9-19", "page_no": 5, "seq": 2,
        "text": "Step 1: Identify the contract. Step 2: Identify performance obligations. "
                "Step 3: Determine transaction price. Step 4: Allocate to obligations. Step 5: Recognise revenue.",
    },
    {
        "standard_number": 116, "document_title": "Leases",
        "section_title": "Right-of-Use Asset", "paragraph_no": "22", "page_no": 8, "seq": 1,
        "text": "At the commencement date, a lessee shall recognise a right-of-use asset.",
    },
]

MOCK_EAC_OPINIONS = [
    {
        "query_no": 1, "query_subject": "Government grants for capital assets",
        "opinion_period": "Vol XLVIII", "query": "How to account for government grants received for capital asset acquisition?",
        "opinion": "The grant should be recognised as deferred income or deducted from the asset cost under Ind AS 20.",
        "score": 0.85,
    },
    {
        "query_no": 2, "query_subject": "Revenue recognition for construction contracts",
        "opinion_period": "Vol XLVII", "query": "Revenue recognition for long-term construction contracts",
        "opinion": "Revenue should be recognised over time based on percentage of completion.",
        "score": 0.72,
    },
]


# ---------------------------------------------------------------------------
# Mock cursor and connection
# ---------------------------------------------------------------------------

class MockCursor:
    """Mock psycopg2 cursor that returns pre-configured results."""

    def __init__(self, rows=None, columns=None):
        self._rows = rows or []
        self._columns = columns or []
        self._idx = 0

    @property
    def description(self):
        if not self._columns:
            return None
        return [MagicMock(name=col) for col in self._columns]

    def execute(self, sql, params=None):
        pass

    def fetchall(self):
        return [tuple(row[c] for c in self._columns) for row in self._rows]

    def fetchone(self):
        if self._rows:
            row = self._rows[0]
            return tuple(row[c] for c in self._columns)
        return None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class MockConnection:
    """Mock psycopg2 connection."""

    def __init__(self, cursor_factory=None):
        self._cursor = cursor_factory or MockCursor()

    def cursor(self):
        return self._cursor

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_rules_db():
    """Patch get_rules_connection to return a mock connection."""
    with patch("research_agent.db.get_rules_connection") as mock:
        conn = MockConnection()
        mock.return_value = conn
        yield mock, conn


@pytest.fixture
def mock_reports_db():
    """Patch get_reports_connection to return a mock connection."""
    with patch("research_agent.db.get_reports_connection") as mock:
        conn = MockConnection()
        mock.return_value = conn
        yield mock, conn


@pytest.fixture
def mock_embeddings():
    """Patch embedding functions to return deterministic vectors."""
    dummy_vec = [0.1] * 1024
    dummy_literal = "[" + ",".join(str(x) for x in dummy_vec) + "]"
    with patch("research_agent.embeddings.embed_query", return_value=dummy_vec), \
         patch("research_agent.embeddings.to_vector_literal", return_value=dummy_literal):
        yield dummy_literal


@pytest.fixture
def mock_reranker():
    """Patch the reranker to return linearly decreasing scores."""
    def fake_rerank(query, passages, top_n=10):
        n = len(passages)
        return [max(0.0, 1.0 - i / max(n, 1)) for i in range(n)]

    with patch("research_agent.tools.research_tools._rerank", side_effect=fake_rerank):
        yield
