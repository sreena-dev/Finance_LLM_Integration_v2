"""Tests for ratio_master — formula lookup and alias normalisation."""

import pytest
from research_agent.tools.ratio_master import (
    get_ratio_definition,
    _normalise_ratio_name,
    list_available_ratios,
    BUILTIN_RATIOS,
)
from research_agent.tools.research_tools import compute_ratio_analysis


class TestComputeRatioAnalysisFormulaLookup:
    def test_found(self):
        r = compute_ratio_analysis(ratio_name="current_ratio")
        assert r["status"] == "ok"
        assert r["confidence"] is None  # deterministic lookup

    def test_not_found(self):
        r = compute_ratio_analysis(ratio_name="nonexistent_xyzzy")
        assert r["data"]["ratios"][0]["status"] == "not_found"

    def test_alias(self):
        r = compute_ratio_analysis(ratio_name="ROE")
        assert r["status"] == "ok"

    def test_all_schedule_iii_formulas(self):
        r = compute_ratio_analysis(ratio_name="all_schedule_iii")
        assert r["status"] == "ok"
        assert len(r["data"]["ratios"]) == 11
