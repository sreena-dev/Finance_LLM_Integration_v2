"""Tests for entity tools — resolve_entity_year, get_entity_profile, get_reporting_framework."""

import pytest
from unittest.mock import patch, MagicMock
from research_agent.tools.research_tools import (
    resolve_entity_year,
    get_reporting_framework,
)
from research_agent.tools.entity_resolver import EntityMatch


def _mock_resolution(best=None, is_ambiguous=False, matches=None, error=None):
    """Build a mock resolve_entity return dict."""
    if error:
        return {"matches": [], "best": None, "is_ambiguous": False, "confidence": 0.0, "error": error}
    if best is None and not matches:
        return {"matches": [], "best": None, "is_ambiguous": False, "confidence": 0.0}
    if best is None:
        best = matches[0]
    return {
        "matches": matches or [best],
        "best": best,
        "is_ambiguous": is_ambiguous,
        "confidence": best.confidence,
    }


class TestResolveEntityYear:

    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_exact_match(self, mock_resolve):
        mock_resolve.return_value = _mock_resolution(
            best=EntityMatch("1", "ONGC", 2023, 2024, "1", 1.0, "exact")
        )
        r = resolve_entity_year("ONGC", "FY2023-24")
        assert r["status"] == "ok"
        assert r["confidence"] == 1.0
        assert r["data"]["canonical_name"] == "ONGC"

    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_not_found(self, mock_resolve):
        mock_resolve.return_value = _mock_resolution()
        r = resolve_entity_year("NonexistentCo", "2024")
        assert r["status"] == "not_found"

    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_ambiguous(self, mock_resolve):
        mock_resolve.return_value = _mock_resolution(
            is_ambiguous=True,
            matches=[
                EntityMatch("1", "ONGC", 2023, 2024, "1", 0.8, "ilike"),
                EntityMatch("7", "Oil and Natural Gas Corporation", 2022, 2023, "7", 0.75, "ilike"),
            ],
        )
        r = resolve_entity_year("ONG", "2024")
        assert r["status"] == "ambiguous"
        assert len(r["data"]["candidates"]) == 2

    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_confidence_reflects_match_method(self, mock_resolve):
        # Exact match → high confidence
        mock_resolve.return_value = _mock_resolution(
            best=EntityMatch("1", "ONGC", 2023, 2024, "1", 1.0, "exact")
        )
        r1 = resolve_entity_year("ONGC", "2023-24")

        # Fuzzy match → lower confidence
        mock_resolve.return_value = _mock_resolution(
            best=EntityMatch("1", "ONGC", 2023, 2024, "1", 0.5, "difflib")
        )
        r2 = resolve_entity_year("ONG Corporation", "2024")

        assert r1["confidence"] > r2["confidence"]





class TestGetReportingFramework:

    @patch("research_agent.tools.research_tools._safe_query")
    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_inferred_default(self, mock_resolve, mock_query):
        mock_resolve.return_value = _mock_resolution(
            best=EntityMatch("1", "ONGC", 2023, 2024, "1", 0.9, "ilike")
        )
        mock_query.return_value = []  # no entity_reporting_framework record
        r = get_reporting_framework("ONGC", "2023-24")
        assert r["status"] == "ok"
        assert r["data"]["framework"] == "Ind AS"
        assert r["confidence"] < 0.7  # inferred, so lower confidence
