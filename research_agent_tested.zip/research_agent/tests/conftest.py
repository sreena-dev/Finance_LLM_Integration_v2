"""Shared test fixtures for the research_agent test suite."""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Sample data
# ---------------------------------------------------------------------------

MOCK_DOCUMENTS = [
    {"doc_id": 1, "company": "ONGC", "fy_start": 2023, "fy_end": 2024, "doc_name": "ONGC_AR_2023-24"},
    {"doc_id": 2, "company": "BPCL", "fy_start": 2023, "fy_end": 2024, "doc_name": "BPCL_AR_2023-24"},
    {"doc_id": 3, "company": "Coal India Limited", "fy_start": 2023, "fy_end": 2024, "doc_name": "CIL_AR_2023-24"},
    {"doc_id": 7, "company": "Oil and Natural Gas Corporation", "fy_start": 2022, "fy_end": 2023, "doc_name": "ONGC_AR_2022-23"},
]


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_rules_conn():
    """Patch get_rules_connection to return a controllable mock."""
    with patch("research_agent.db.get_rules_connection") as mock_fn:
        conn = MagicMock()
        mock_fn.return_value = conn
        yield conn


@pytest.fixture
def mock_reports_conn():
    """Patch get_reports_connection to return a controllable mock."""
    with patch("research_agent.db.get_reports_connection") as mock_fn:
        conn = MagicMock()
        mock_fn.return_value = conn
        yield conn


@pytest.fixture
def mock_embeddings():
    """Patch embedding functions to return deterministic vectors."""
    dummy_vec = [0.1] * 1024
    dummy_literal = "[" + ",".join("0.1" for _ in range(1024)) + "]"
    with patch("research_agent.embeddings.embed_query", return_value=dummy_vec), \
         patch("research_agent.embeddings.to_vector_literal", return_value=dummy_literal):
        yield dummy_literal


@pytest.fixture
def mock_reranker():
    """Patch the reranker to return linearly decreasing scores."""
    def fake_rerank(query, passages, top_n=10):
        n = len(passages)
        return [max(0.0, 1.0 - i / max(n, 1)) for i in range(n)]
    with patch("research_agent.tools.research_tools._rerank", side_effect=fake_rerank):
        yield
