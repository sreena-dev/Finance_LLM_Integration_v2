"""Tests for entity_resolver — FY parsing and resolution logic."""

import pytest
from research_agent.tools.entity_resolver import parse_fiscal_year


class TestParseFiscalYear:
    """parse_fiscal_year must handle all common Indian FY formats."""

    def test_fy_range_full(self):
        assert parse_fiscal_year("FY2023-2024") == (2023, 2024)

    def test_fy_range_short(self):
        assert parse_fiscal_year("FY2023-24") == (2023, 2024)

    def test_fy_range_no_prefix(self):
        assert parse_fiscal_year("2023-24") == (2023, 2024)

    def test_fy_range_dash_variant(self):
        assert parse_fiscal_year("2023–2024") == (2023, 2024)

    def test_fy_single_ending(self):
        # "FY24" = FY ending 2024 → start 2023
        assert parse_fiscal_year("FY24") == (2023, 2024)

    def test_fy_single_four_digit(self):
        assert parse_fiscal_year("FY2024") == (2023, 2024)

    def test_bare_year(self):
        assert parse_fiscal_year("2024") == (2023, 2024)

    def test_with_spaces(self):
        assert parse_fiscal_year("  FY 2023 - 24  ") == (2023, 2024)

    def test_invalid_raises(self):
        with pytest.raises(ValueError):
            parse_fiscal_year("abc")

    def test_fy_end_less_than_start_corrected(self):
        # If end <= start, correct to start+1
        assert parse_fiscal_year("2024-23") == (2024, 2025)
