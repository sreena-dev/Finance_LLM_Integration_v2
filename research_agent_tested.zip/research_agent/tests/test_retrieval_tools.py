"""Tests for retrieval tools — envelope, confidence, and match-quality correlation."""

import pytest
from unittest.mock import patch, MagicMock
from research_agent.tools.research_tools import (
    lookup_clause_exact,
    compare_standards,
)


class TestLookupClauseExact:
    """Exact clause lookup must return 1.0 confidence or not_found — no fuzzy."""

    @patch("research_agent.tools.research_tools._safe_query")
    def test_exact_match_confidence_is_one(self, mock_query):
        mock_query.return_value = [
            {
                "standard_number": 115,
                "document_title": "Revenue from Contracts with Customers",
                "section_title": "Recognition",
                "paragraph_no": "9",
                "page_no": 5,
                "text": "An entity shall recognise revenue...",
            }
        ]
        result = lookup_clause_exact("Ind AS 115", "9")
        assert result["status"] == "ok"
        assert result["confidence"] == 1.0
        assert len(result["data"]) >= 1

    @patch("research_agent.tools.research_tools._safe_query")
    def test_no_match_returns_not_found(self, mock_query):
        mock_query.return_value = []
        result = lookup_clause_exact("Ind AS 999", "para 999")
        assert result["status"] == "not_found"

    @patch("research_agent.tools.research_tools._safe_query")
    def test_confidence_strictly_binary(self, mock_query):
        """Exact lookup must never return intermediate confidence."""
        mock_query.return_value = [
            {"standard_number": 116, "document_title": "Leases",
             "section_title": "ROU", "paragraph_no": "22",
             "page_no": 8, "text": "Right-of-use asset"}
        ]
        result = lookup_clause_exact("Ind AS 116", "22")
        assert result["confidence"] in (1.0, None) or result["status"] == "not_found"

    def test_envelope_shape(self):
        """Every response must have the required envelope keys."""
        result = lookup_clause_exact("Ind AS 115", "nonexistent")
        assert "status" in result
        assert "data" in result
        assert "confidence" in result
        assert "confidence_basis" in result
        assert "sources" in result
        assert "ambiguity_note" in result


class TestCompareStandards:
    """compare_standards confidence = min(conf_a, conf_b)."""

    @patch("research_agent.tools.research_tools.search_knowledge_base")
    def test_confidence_is_min(self, mock_search):
        mock_search.side_effect = [
            {"status": "ok", "data": [{"text": "A rule"}], "confidence": 0.9,
             "confidence_basis": "", "sources": [], "ambiguity_note": None},
            {"status": "ok", "data": [{"text": "B rule"}], "confidence": 0.6,
             "confidence_basis": "", "sources": [], "ambiguity_note": None},
        ]
        result = compare_standards("IndAS", "CARO", "revenue")
        assert result["status"] == "ok"
        assert result["confidence"] == pytest.approx(0.6, abs=0.01)

    @patch("research_agent.tools.research_tools.search_knowledge_base")
    def test_both_not_found(self, mock_search):
        mock_search.return_value = {
            "status": "not_found", "data": {"message": "none"}, "confidence": 0.0,
            "confidence_basis": "", "sources": [], "ambiguity_note": None,
        }
        result = compare_standards("IndAS", "CARO", "xyzzy_topic")
        assert result["status"] == "not_found"
