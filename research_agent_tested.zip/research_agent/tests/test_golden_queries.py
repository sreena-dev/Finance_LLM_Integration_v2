"""Golden query regression tests — ~25 queries per framework.

These tests assert that status="ok" with confidence above threshold
for known-good queries. They are designed to run against the live
databases and should be executed on every ingestion/index update.

Mark with ``@pytest.mark.integration`` so they can be skipped in
unit-test-only CI runs.
"""

import pytest

# These tests require live database connections.
# Skip if not available.
pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

CONFIDENCE_THRESHOLD = 0.5  # minimum acceptable confidence for golden queries


def assert_golden(result: dict, query_label: str):
    """Assert a golden query result is ok with confidence above threshold."""
    assert result["status"] == "ok", (
        f"Golden query [{query_label}] returned status={result['status']}: "
        f"{result.get('data', {}).get('message', '')}"
    )
    conf = result.get("confidence")
    if conf is not None:  # computation tools have None
        assert conf >= CONFIDENCE_THRESHOLD, (
            f"Golden query [{query_label}] confidence={conf} < threshold={CONFIDENCE_THRESHOLD}"
        )


# ---------------------------------------------------------------------------
# Ind AS Golden Queries (~25)
# ---------------------------------------------------------------------------

class TestIndASGoldenQueries:
    """Golden queries for Indian Accounting Standards retrieval."""

    QUERIES = [
        ("IndAS-001", "search_knowledge_base", {"query": "revenue recognition 5-step model", "framework": "IndAS"}),
        ("IndAS-002", "search_knowledge_base", {"query": "lease right of use asset recognition", "framework": "IndAS"}),
        ("IndAS-003", "search_knowledge_base", {"query": "impairment of assets indicators", "framework": "IndAS"}),
        ("IndAS-004", "search_knowledge_base", {"query": "financial instruments classification", "framework": "IndAS"}),
        ("IndAS-005", "search_knowledge_base", {"query": "employee benefits defined benefit obligation", "framework": "IndAS"}),
        ("IndAS-006", "search_knowledge_base", {"query": "property plant equipment depreciation", "framework": "IndAS"}),
        ("IndAS-007", "search_knowledge_base", {"query": "provisions contingent liabilities recognition criteria", "framework": "IndAS"}),
        ("IndAS-008", "search_knowledge_base", {"query": "government grants accounting treatment", "framework": "IndAS"}),
        ("IndAS-009", "search_knowledge_base", {"query": "borrowing costs capitalisation", "framework": "IndAS"}),
        ("IndAS-010", "search_knowledge_base", {"query": "related party disclosures requirements", "framework": "IndAS"}),
        ("IndAS-011", "search_knowledge_base", {"query": "earnings per share diluted", "framework": "IndAS"}),
        ("IndAS-012", "search_knowledge_base", {"query": "business combinations goodwill measurement", "framework": "IndAS"}),
        ("IndAS-013", "search_knowledge_base", {"query": "fair value measurement hierarchy levels", "framework": "IndAS"}),
        ("IndAS-014", "search_knowledge_base", {"query": "income taxes deferred tax recognition", "framework": "IndAS"}),
        ("IndAS-015", "search_knowledge_base", {"query": "inventories cost formula weighted average", "framework": "IndAS"}),
        ("IndAS-016", "search_knowledge_base", {"query": "foreign currency translation functional currency", "framework": "IndAS"}),
        ("IndAS-017", "search_knowledge_base", {"query": "consolidated financial statements control", "framework": "IndAS"}),
        ("IndAS-018", "search_knowledge_base", {"query": "intangible assets useful life amortisation", "framework": "IndAS"}),
        ("IndAS-019", "search_knowledge_base", {"query": "operating segments reportable", "framework": "IndAS"}),
        ("IndAS-020", "search_knowledge_base", {"query": "presentation of financial statements minimum disclosure", "framework": "IndAS"}),
        ("IndAS-021", "lookup_clause_exact", {"standard_name": "Ind AS 115", "clause_reference": "9"}),
        ("IndAS-022", "lookup_clause_exact", {"standard_name": "Ind AS 116", "clause_reference": "22"}),
        ("IndAS-023", "search_knowledge_base", {"query": "expected credit loss model Ind AS 109", "framework": "IndAS"}),
        ("IndAS-024", "search_knowledge_base", {"query": "share based payment equity settled", "framework": "IndAS"}),
        ("IndAS-025", "search_knowledge_base", {"query": "investment property fair value model", "framework": "IndAS"}),
    ]

    @pytest.mark.parametrize("label,tool_name,params", QUERIES)
    def test_golden_indas(self, label, tool_name, params):
        from research_agent.tools import research_tools
        tool_fn = getattr(research_tools, tool_name)
        result = tool_fn(**params)
        assert_golden(result, label)


# ---------------------------------------------------------------------------
# CARO Golden Queries (~25)
# ---------------------------------------------------------------------------

class TestCAROGoldenQueries:

    QUERIES = [
        ("CARO-001", "search_knowledge_base", {"query": "fixed assets physical verification", "framework": "CARO"}),
        ("CARO-002", "search_knowledge_base", {"query": "inventory physical verification discrepancy", "framework": "CARO"}),
        ("CARO-003", "search_knowledge_base", {"query": "loans granted to subsidiaries", "framework": "CARO"}),
        ("CARO-004", "search_knowledge_base", {"query": "compliance with section 185 186 Companies Act", "framework": "CARO"}),
        ("CARO-005", "search_knowledge_base", {"query": "deposits public deposits repayment", "framework": "CARO"}),
        ("CARO-006", "search_knowledge_base", {"query": "cost records maintenance central government", "framework": "CARO"}),
        ("CARO-007", "search_knowledge_base", {"query": "statutory dues provident fund ESI", "framework": "CARO"}),
        ("CARO-008", "search_knowledge_base", {"query": "default in repayment of loans financial institutions", "framework": "CARO"}),
        ("CARO-009", "search_knowledge_base", {"query": "money raised by public offer term loans utilisation", "framework": "CARO"}),
        ("CARO-010", "search_knowledge_base", {"query": "fraud by the company or on the company", "framework": "CARO"}),
        ("CARO-011", "search_knowledge_base", {"query": "managerial remuneration section 197", "framework": "CARO"}),
        ("CARO-012", "search_knowledge_base", {"query": "nidhi company compliance", "framework": "CARO"}),
        ("CARO-013", "search_knowledge_base", {"query": "related party transactions arm's length", "framework": "CARO"}),
        ("CARO-014", "search_knowledge_base", {"query": "preferential allotment private placement shares", "framework": "CARO"}),
        ("CARO-015", "search_knowledge_base", {"query": "non-cash transactions directors persons connected", "framework": "CARO"}),
        ("CARO-016", "search_knowledge_base", {"query": "registration under section 45-IA RBI", "framework": "CARO"}),
        ("CARO-017", "search_knowledge_base", {"query": "cash losses current year preceding year", "framework": "CARO"}),
        ("CARO-018", "search_knowledge_base", {"query": "resignation of statutory auditors", "framework": "CARO"}),
        ("CARO-019", "search_knowledge_base", {"query": "material uncertainty going concern", "framework": "CARO"}),
        ("CARO-020", "search_knowledge_base", {"query": "unspent CSR amount transfer fund", "framework": "CARO"}),
        ("CARO-021", "search_knowledge_base", {"query": "qualifications reservations adverse remarks", "framework": "CARO"}),
        ("CARO-022", "search_knowledge_base", {"query": "immovable properties title deeds", "framework": "CARO"}),
        ("CARO-023", "search_knowledge_base", {"query": "undisclosed income tax assessment", "framework": "CARO"}),
        ("CARO-024", "search_knowledge_base", {"query": "whistle-blower complaints", "framework": "CARO"}),
        ("CARO-025", "search_knowledge_base", {"query": "CARO clause 3 sub-clause xxi", "framework": "CARO"}),
    ]

    @pytest.mark.parametrize("label,tool_name,params", QUERIES)
    def test_golden_caro(self, label, tool_name, params):
        from research_agent.tools import research_tools
        tool_fn = getattr(research_tools, tool_name)
        result = tool_fn(**params)
        assert_golden(result, label)


# ---------------------------------------------------------------------------
# SA Golden Queries (~25)
# ---------------------------------------------------------------------------

class TestSAGoldenQueries:

    QUERIES = [
        ("SA-001", "search_knowledge_base", {"query": "unmodified opinion conditions", "framework": "SA"}),
        ("SA-002", "search_knowledge_base", {"query": "qualified opinion material misstatement", "framework": "SA"}),
        ("SA-003", "search_knowledge_base", {"query": "adverse opinion pervasive misstatement", "framework": "SA"}),
        ("SA-004", "search_knowledge_base", {"query": "disclaimer of opinion limitation of scope", "framework": "SA"}),
        ("SA-005", "search_knowledge_base", {"query": "key audit matters communication", "framework": "SA"}),
        ("SA-006", "search_knowledge_base", {"query": "emphasis of matter paragraph requirements", "framework": "SA"}),
        ("SA-007", "search_knowledge_base", {"query": "other matter paragraph circumstances", "framework": "SA"}),
        ("SA-008", "search_knowledge_base", {"query": "going concern assessment auditor responsibility", "framework": "SA"}),
        ("SA-009", "search_knowledge_base", {"query": "auditor report format elements", "framework": "SA"}),
        ("SA-010", "search_knowledge_base", {"query": "basis for opinion paragraph", "framework": "SA"}),
        ("SA-011", "search_knowledge_base", {"query": "management responsibility financial statements", "framework": "SA"}),
        ("SA-012", "search_knowledge_base", {"query": "auditor independence ethical requirements", "framework": "SA"}),
        ("SA-013", "search_knowledge_base", {"query": "other information annual report SA 720", "framework": "SA"}),
        ("SA-014", "search_knowledge_base", {"query": "comparative information corresponding figures", "framework": "SA"}),
        ("SA-015", "search_knowledge_base", {"query": "material uncertainty going concern disclosure", "framework": "SA"}),
        ("SA-016", "search_knowledge_base", {"query": "internal control over financial reporting", "framework": "SA"}),
        ("SA-017", "search_knowledge_base", {"query": "audit evidence sufficient appropriate", "framework": "SA"}),
        ("SA-018", "search_knowledge_base", {"query": "subsequent events after reporting period", "framework": "SA"}),
        ("SA-019", "search_knowledge_base", {"query": "written representations management", "framework": "SA"}),
        ("SA-020", "search_knowledge_base", {"query": "communication with those charged with governance", "framework": "SA"}),
        ("SA-021", "search_knowledge_base", {"query": "statutory audit requirements", "framework": "SA"}),
        ("SA-022", "search_knowledge_base", {"query": "going concern auditor responsibility", "framework": "SA"}),
        ("SA-023", "search_knowledge_base", {"query": "key audit matters communication", "framework": "SA"}),
        ("SA-024", "search_knowledge_base", {"query": "group audit component auditor", "framework": "SA"}),
        ("SA-025", "search_knowledge_base", {"query": "fraud detection auditor responsibility", "framework": "SA"}),
    ]

    @pytest.mark.parametrize("label,tool_name,params", QUERIES)
    def test_golden_sa(self, label, tool_name, params):
        from research_agent.tools import research_tools
        tool_fn = getattr(research_tools, tool_name)
        result = tool_fn(**params)
        assert_golden(result, label)


# ---------------------------------------------------------------------------
# Schedule III Golden Queries (~25)
# ---------------------------------------------------------------------------

class TestScheduleIIIGoldenQueries:

    QUERIES = [
        ("SIII-001", "search_knowledge_base", {"query": "balance sheet format current non-current", "framework": "ScheduleIII"}),
        ("SIII-002", "search_knowledge_base", {"query": "trade receivables ageing schedule", "framework": "ScheduleIII"}),
        ("SIII-003", "search_knowledge_base", {"query": "trade payables micro small medium enterprises", "framework": "ScheduleIII"}),
        ("SIII-004", "search_knowledge_base", {"query": "borrowings current maturities long term", "framework": "ScheduleIII"}),
        ("SIII-005", "search_knowledge_base", {"query": "property plant equipment disclosure requirements", "framework": "ScheduleIII"}),
        ("SIII-006", "search_knowledge_base", {"query": "statement of profit and loss format", "framework": "ScheduleIII"}),
        ("SIII-007", "search_knowledge_base", {"query": "other equity components reserves", "framework": "ScheduleIII"}),
        ("SIII-008", "search_knowledge_base", {"query": "right of use assets lease presentation", "framework": "ScheduleIII"}),
        ("SIII-009", "search_knowledge_base", {"query": "provisions current non-current classification", "framework": "ScheduleIII"}),
        ("SIII-010", "search_knowledge_base", {"query": "inventories classification raw materials work in progress", "framework": "ScheduleIII"}),
        ("SIII-011", "search_knowledge_base", {"query": "cash and cash equivalents bank balances", "framework": "ScheduleIII"}),
        ("SIII-012", "search_knowledge_base", {"query": "other current assets advance to suppliers", "framework": "ScheduleIII"}),
        ("SIII-013", "search_knowledge_base", {"query": "deferred tax assets liabilities presentation", "framework": "ScheduleIII"}),
        ("SIII-014", "search_knowledge_base", {"query": "revenue from operations other income", "framework": "ScheduleIII"}),
        ("SIII-015", "search_knowledge_base", {"query": "employee benefit expenses disclosure", "framework": "ScheduleIII"}),
        ("SIII-016", "search_knowledge_base", {"query": "depreciation and amortisation statement", "framework": "ScheduleIII"}),
        ("SIII-017", "search_knowledge_base", {"query": "finance costs interest expense", "framework": "ScheduleIII"}),
        ("SIII-018", "search_knowledge_base", {"query": "exceptional items disclosure", "framework": "ScheduleIII"}),
        ("SIII-019", "search_knowledge_base", {"query": "earnings per share basic diluted presentation", "framework": "ScheduleIII"}),
        ("SIII-020", "search_knowledge_base", {"query": "capital work in progress ageing schedule", "framework": "ScheduleIII"}),
        ("SIII-021", "search_knowledge_base", {"query": "intangible assets under development", "framework": "ScheduleIII"}),
        ("SIII-022", "search_knowledge_base", {"query": "goodwill on consolidation", "framework": "ScheduleIII"}),
        ("SIII-023", "search_knowledge_base", {"query": "loan receivable ageing schedule", "framework": "ScheduleIII"}),
        ("SIII-024", "list_applicable_rules", {"line_item_name": "Trade receivables"}),
        ("SIII-025", "list_applicable_rules", {"line_item_name": "PPE"}),
    ]

    @pytest.mark.parametrize("label,tool_name,params", QUERIES)
    def test_golden_schedule_iii(self, label, tool_name, params):
        from research_agent.tools import research_tools
        tool_fn = getattr(research_tools, tool_name)
        result = tool_fn(**params)
        assert_golden(result, label)


# ---------------------------------------------------------------------------
# Annual Reports Golden Queries (~25)
# ---------------------------------------------------------------------------

class TestAnnualReportsGoldenQueries:

    QUERIES = [
        ("AR-001", "search_company_disclosures", {"company_name": "ONGC", "fiscal_year": "2023-24", "topic": "trade receivables"}),
        ("AR-002", "search_company_disclosures", {"company_name": "BPCL", "fiscal_year": "2023-24", "topic": "lease liabilities"}),
        ("AR-003", "search_company_disclosures", {"company_name": "ONGC", "fiscal_year": "2023-24", "topic": "revenue recognition"}),
        ("AR-004", "get_audit_report_highlights", {"company_name": "ONGC", "fiscal_year": "2023-24"}),
        ("AR-005", "get_audit_report_highlights", {"company_name": "HPCL", "fiscal_year": "2023-24"}),
        ("AR-006", "check_caro_clauses", {"company_name": "ONGC", "fiscal_year": "2023-24"}),
        ("AR-007", "check_caro_clauses", {"company_name": "Coal India", "fiscal_year": "2023-24"}),
        ("AR-008", "check_rule_11g", {"company_name": "ONGC", "fiscal_year": "2023-24"}),
        ("AR-009", "get_accounting_policy_note", {"company_name": "ONGC", "fiscal_year": "2023-24", "policy_area": "revenue"}),
        ("AR-010", "get_accounting_policy_note", {"company_name": "BPCL", "fiscal_year": "2023-24", "policy_area": "depreciation"}),
        ("AR-011", "search_company_disclosures", {"company_name": "NTPC", "fiscal_year": "2023-24", "topic": "borrowings"}),
        ("AR-012", "search_company_disclosures", {"company_name": "IOCL", "fiscal_year": "2023-24", "topic": "inventory"}),
        ("AR-013", "get_schedule_note", {"company_name": "ONGC", "fiscal_year": "2023-24", "schedule_name": "Property Plant Equipment"}),
        ("AR-014", "get_schedule_note", {"company_name": "BPCL", "fiscal_year": "2023-24", "schedule_name": "Borrowings"}),
        ("AR-015", "resolve_entity_year", {"company_name": "ONGC", "fiscal_year_string": "FY2023-24"}),
        ("AR-016", "resolve_entity_year", {"company_name": "BPCL", "fiscal_year_string": "2023-24"}),
        ("AR-017", "resolve_entity_year", {"company_name": "Coal India", "fiscal_year_string": "FY24"}),
        ("AR-018", "resolve_entity_year", {"company_name": "ONGC", "fiscal_year_string": "2024"}),
        ("AR-019", "get_reporting_framework", {"company_name": "ONGC", "fiscal_year": "2023-24"}),
        ("AR-020", "search_company_disclosures", {"company_name": "ONGC", "fiscal_year": "2023-24", "topic": "CSR expenditure"}),
        ("AR-021", "search_company_disclosures", {"company_name": "HPCL", "fiscal_year": "2023-24", "topic": "contingent liabilities"}),
        ("AR-022", "lookup_report_reference", {"company_name": "ONGC", "fiscal_year": "2023-24", "note_or_section_ref": "Note 1"}),
        ("AR-023", "search_company_disclosures", {"company_name": "NTPC", "fiscal_year": "2023-24", "topic": "deferred tax"}),
        ("AR-024", "search_company_disclosures", {"company_name": "IOCL", "fiscal_year": "2023-24", "topic": "related party transactions"}),
        ("AR-025", "get_schedule_note", {"company_name": "ONGC", "fiscal_year": "2023-24", "schedule_name": "Provisions"}),
    ]

    @pytest.mark.parametrize("label,tool_name,params", QUERIES)
    def test_golden_annual_reports(self, label, tool_name, params):
        from research_agent.tools import research_tools
        tool_fn = getattr(research_tools, tool_name)
        result = tool_fn(**params)
        assert_golden(result, label)
