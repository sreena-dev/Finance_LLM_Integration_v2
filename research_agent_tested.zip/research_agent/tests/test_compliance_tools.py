"""Tests for compliance tools — check_statement_compliance, check_caro_clauses, check_rule_11g."""

import pytest
from unittest.mock import patch, MagicMock
from research_agent.tools.research_tools import (
    check_caro_clauses,
    check_rule_11g,
)
from research_agent.tools.entity_resolver import EntityMatch


def _ok_resolution():
    best = EntityMatch("1", "ONGC", 2023, 2024, "1", 0.95, "exact")
    return {"matches": [best], "best": best, "is_ambiguous": False, "confidence": 0.95}


class TestCheckCaroClauses:

    @patch("research_agent.retrieval.sar_retrieval._extract_sections")
    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_found(self, mock_resolve, mock_extract):
        mock_resolve.return_value = _ok_resolution()
        mock_extract.return_value = (
            "CARO 2020 Annexure\n"
            "clause (i): Fixed assets maintained properly.\n"
            "clause (ii): Inventory verified. No discrepancies.\n"
            "clause (iii): Loans given to related parties.\n"
        )
        r = check_caro_clauses("ONGC", "2023-24")
        assert r["status"] == "ok"
        assert r["data"]["clauses_identified"] >= 2
        assert r["confidence"] > 0

    @patch("research_agent.retrieval.sar_retrieval._extract_sections")
    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_not_found(self, mock_resolve, mock_extract):
        mock_resolve.return_value = _ok_resolution()
        mock_extract.return_value = ""
        r = check_caro_clauses("ONGC", "2023-24")
        assert r["status"] == "not_found"


class TestCheckRule11g:

    @patch("research_agent.tools.research_tools._query_reports")
    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_found_with_audit_trail(self, mock_resolve, mock_query):
        mock_resolve.return_value = _ok_resolution()
        mock_query.return_value = [
            {"content": "Rule 11(g): The company has maintained audit trail feature...",
             "section": "Other Legal Requirements", "page": 45},
        ]
        r = check_rule_11g("ONGC", "2023-24")
        assert r["status"] == "ok"
        assert r["data"]["audit_trail_mentioned"] is True
        assert r["data"]["rule_11_mentioned"] is True

    @patch("research_agent.tools.research_tools._query_reports")
    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_not_found(self, mock_resolve, mock_query):
        mock_resolve.return_value = _ok_resolution()
        mock_query.return_value = []
        r = check_rule_11g("ONGC", "2023-24")
        assert r["status"] == "not_found"

    @patch("research_agent.tools.research_tools._query_reports")
    @patch("research_agent.tools.research_tools.resolve_entity")
    def test_exception_detected(self, mock_resolve, mock_query):
        mock_resolve.return_value = _ok_resolution()
        mock_query.return_value = [
            {"content": "Audit trail was not enabled for certain periods...",
             "section": "Rule 11", "page": 47},
        ]
        r = check_rule_11g("ONGC", "2023-24")
        assert r["status"] == "ok"
        assert r["data"]["exceptions_noted"] is True
