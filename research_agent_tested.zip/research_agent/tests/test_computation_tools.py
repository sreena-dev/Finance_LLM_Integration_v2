"""Tests for the AST-based calculate tool and financial_math module."""

import pytest
from research_agent.tools.financial_math import evaluate, ratio, pct_change, cagr
from research_agent.tools.research_tools import calculate


class TestEvaluate:
    """Tests for the core AST expression evaluator."""

    def test_simple_addition(self):
        r = evaluate("2 + 3")
        assert r["result"] == 5.0

    def test_division(self):
        r = evaluate("10 / 4")
        assert r["result"] == 2.5

    def test_with_variables(self):
        r = evaluate("a + b * c", {"a": 1, "b": 2, "c": 3})
        assert r["result"] == 7.0

    def test_parentheses(self):
        r = evaluate("(a + b) * c", {"a": 1, "b": 2, "c": 3})
        assert r["result"] == 9.0

    def test_power(self):
        r = evaluate("2 ** 10")
        assert r["result"] == 1024.0

    def test_modulo(self):
        r = evaluate("17 % 5")
        assert r["result"] == 2.0

    def test_abs_function(self):
        r = evaluate("abs(-42)")
        assert r["result"] == 42.0

    def test_round_function(self):
        r = evaluate("round(3.14159, 2)")
        assert r["result"] == 3.14

    def test_min_max(self):
        assert evaluate("min(3, 7)")["result"] == 3.0
        assert evaluate("max(3, 7)")["result"] == 7.0

    def test_division_by_zero(self):
        r = evaluate("1 / 0")
        assert "error" in r

    def test_undefined_variable(self):
        r = evaluate("x + 1")
        assert "error" in r

    def test_unsupported_function(self):
        r = evaluate("eval('bad')")
        assert "error" in r

    def test_comma_formatted_numbers(self):
        r = evaluate("1,00,000 + 50,000")
        assert r["result"] == 150000.0

    def test_complex_ratio(self):
        r = evaluate(
            "current_assets / current_liabilities",
            {"current_assets": 450000, "current_liabilities": 300000},
        )
        assert abs(r["result"] - 1.5) < 0.0001

    def test_pct_change_formula(self):
        r = evaluate(
            "(current - prior) / abs(prior) * 100",
            {"current": 120, "prior": 100},
        )
        assert abs(r["result"] - 20.0) < 0.0001

    def test_empty_expression(self):
        r = evaluate("")
        assert "error" in r

    def test_negative_numbers(self):
        r = evaluate("-5 + 3")
        assert r["result"] == -2.0


class TestRatio:
    def test_normal(self):
        assert ratio(100, 50) == 2.0

    def test_zero_denominator(self):
        assert ratio(100, 0) is None

    def test_none_numerator(self):
        assert ratio(None, 50) is None


class TestPctChange:
    def test_positive_growth(self):
        assert pct_change(120, 100) == 20.0

    def test_negative_growth(self):
        assert pct_change(80, 100) == -20.0

    def test_zero_prior(self):
        assert pct_change(100, 0) is None


class TestCagr:
    def test_normal(self):
        result = cagr(100, 200, 5)
        assert result is not None
        assert abs(result - 14.87) < 0.1

    def test_negative_begin(self):
        assert cagr(-100, 200, 5) is None


class TestCalculateTool:
    """Tests for the calculate tool (envelope wrapper)."""

    def test_returns_envelope(self):
        r = calculate("2 + 3")
        assert r["status"] == "ok"
        assert r["data"]["result"] == 5.0
        assert r["confidence"] is None  # computation tool

    def test_error_envelope(self):
        r = calculate("1 / 0")
        assert r["status"] == "error"

    def test_empty_expression_error(self):
        r = calculate("")
        assert r["status"] == "error"

    def test_with_variables(self):
        r = calculate("x * y", {"x": 4, "y": 5})
        assert r["status"] == "ok"
        assert r["data"]["result"] == 20.0

    def test_no_confidence_for_computation(self):
        r = calculate("1 + 1")
        assert r["confidence"] is None
        assert "deterministic" in r["confidence_basis"]


class TestComputeRatioAnalysis:
    """Tests for the consolidated compute_ratio_analysis tool."""

    def test_formula_only_mode(self):
        from research_agent.tools.research_tools import compute_ratio_analysis
        r = compute_ratio_analysis(ratio_name="Current Ratio")
        assert r["status"] == "ok"
        assert r["data"]["mode"] == "formula_lookup"
        assert r["confidence"] is None

    def test_all_schedule_iii_formula_lookup(self):
        from research_agent.tools.research_tools import compute_ratio_analysis
        r = compute_ratio_analysis(ratio_name="all_schedule_iii")
        assert r["status"] == "ok"
        assert r["data"]["total_ratios"] == 11
        assert r["data"]["schedule_iii_mandatory_11"] is True

    def test_gail_annual_report_ratios(self):
        from research_agent.tools.research_tools import compute_ratio_analysis
        r = compute_ratio_analysis("all_schedule_iii", company_name="GAIL_India", fiscal_year="2023-24")
        assert r["status"] in ("ok", "ambiguous", "not_found")
        if r["status"] == "ok":
            assert r["data"]["company"] is not None
            assert r["data"]["schedule_iii_mandatory_11"] is True
            assert r["confidence"] is None
