"""Integration tests for production hardening of Research Agent.

Tests:
  1. get_accounting_policy_note retry loop (exact match, synonym retry, prefix retry, not_found)
  2. DB connection pool concurrency check (20 concurrent checkouts)
  3. Single agent build at app startup across N simulated requests
"""

from __future__ import annotations

import concurrent.futures
from unittest.mock import MagicMock, patch

import pytest
from fastapi.testclient import TestClient

from research_agent.db import get_reports_connection, get_rules_connection
from research_agent.tools.entity_resolver import EntityMatch
from research_agent.tools.research_tools import get_accounting_policy_note


def _make_mock_resolution(company="ONGC", fy="2023-24"):
    return {
        "matches": [
            EntityMatch(
                entity_id="1",
                canonical_name=company,
                fy_start=2023,
                fy_end=2024,
                doc_id="1",
                confidence=1.0,
                match_method="exact",
            )
        ],
        "best": EntityMatch(
            entity_id="1",
            canonical_name=company,
            fy_start=2023,
            fy_end=2024,
            doc_id="1",
            confidence=1.0,
            match_method="exact",
        ),
        "is_ambiguous": False,
        "confidence": 1.0,
    }


def test_accounting_policy_note_exact_match(mock_reports_conn):
    """Test get_accounting_policy_note when exact SQL keyword match succeeds immediately."""
    with patch("research_agent.tools.research_tools.resolve_entity", return_value=_make_mock_resolution("ONGC", "2023-24")), \
         patch("research_agent.tools.research_tools._query_reports") as mock_q:
        mock_q.return_value = [
            {"content": "ONGC follows Ind AS 115 for revenue recognition.", "section": "Significant Accounting Policies", "page": 42}
        ]

        result = get_accounting_policy_note("ONGC", "2023-24", "revenue recognition")

        assert result["status"] == "ok"
        assert result["confidence"] > 0.8
        assert "exact SQL keyword match" in result["confidence_basis"]


def test_accounting_policy_note_synonym_retry(mock_reports_conn):
    """Test get_accounting_policy_note when exact SQL fails, but synonym retry succeeds in search_company_disclosures."""
    with patch("research_agent.tools.research_tools.resolve_entity", return_value=_make_mock_resolution("ONGC", "2023-24")), \
         patch("research_agent.tools.research_tools._query_reports", return_value=[]), \
         patch("research_agent.tools.research_tools.search_company_disclosures") as mock_disc:
        mock_disc.side_effect = [
            {"status": "not_found"},  # Attempt 1: "depreciation" fails
            {                         # Attempt 2: "property plant equipment useful life" succeeds
                "status": "ok",
                "confidence": 0.88,
                "data": {"results": [{"content": "PPE is depreciated using straight-line method.", "page": 45}]},
                "sources": [{"doc_id": "1", "page": 45}]
            }
        ]

        result = get_accounting_policy_note("ONGC", "2023-24", "depreciation")

        assert result["status"] == "ok"
        assert result["data"]["retry_attempt"] == 2
        assert "attempt 2" in result["confidence_basis"]


def test_accounting_policy_note_prefix_retry(mock_reports_conn):
    """Test get_accounting_policy_note when exact and synonym fail, but prefix retry succeeds."""
    with patch("research_agent.tools.research_tools.resolve_entity", return_value=_make_mock_resolution("BPCL", "2023-24")), \
         patch("research_agent.tools.research_tools._query_reports", return_value=[]), \
         patch("research_agent.tools.research_tools.search_company_disclosures") as mock_disc:
        mock_disc.side_effect = [
            {"status": "not_found"},  # Attempt 1
            {"status": "not_found"},  # Attempt 2
            {                         # Attempt 3: "accounting policy custom_area" succeeds
                "status": "ok",
                "confidence": 0.80,
                "data": {"results": [{"content": "Custom accounting policy details...", "page": 80}]},
                "sources": [{"doc_id": "2", "page": 80}]
            }
        ]

        result = get_accounting_policy_note("BPCL", "2023-24", "custom_area")

        assert result["status"] == "ok"
        assert result["data"]["retry_attempt"] == 3


def test_accounting_policy_note_all_failed(mock_reports_conn):
    """Test get_accounting_policy_note when all 3 reformulations return not_found."""
    with patch("research_agent.tools.research_tools.resolve_entity", return_value=_make_mock_resolution("IRCTC", "2023-24")), \
         patch("research_agent.tools.research_tools._query_reports", return_value=[]), \
         patch("research_agent.tools.research_tools.search_company_disclosures") as mock_disc:
        mock_disc.return_value = {"status": "not_found"}

        result = get_accounting_policy_note("IRCTC", "2023-24", "nonexistent_policy")

        assert result["status"] == "not_found"
        assert "after 3 reformulations" in result["data"]["message"]


def test_db_connection_pool_concurrency():
    """Verify that 20 concurrent threads checking out connection pool managers succeed without pool exhaustion."""
    def checkout_rules():
        with get_rules_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                return cur.fetchone()[0]

    def checkout_reports():
        with get_reports_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                return cur.fetchone()[0]

    with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
        rules_futures = [executor.submit(checkout_rules) for _ in range(10)]
        reports_futures = [executor.submit(checkout_reports) for _ in range(10)]

        for f in rules_futures:
            assert f.result() == 1
        for f in reports_futures:
            assert f.result() == 1


def test_single_agent_instance_at_startup():
    """Assert that build_research_agent is invoked ONCE at app startup across multiple requests."""
    from research_agent.server import app

    with patch("research_agent.server.build_research_agent") as mock_build:
        mock_agent = MagicMock()
        mock_agent.run.return_value = {"response": "Mocked response", "tools_used": []}
        mock_build.return_value = mock_agent

        with TestClient(app) as client:
            # Send 5 simulated query requests
            for i in range(5):
                resp = client.post("/api/query", json={"query": f"Test question {i}?"})
                assert resp.status_code == 200

            # Verify build_research_agent was called exactly 1 time during lifespan startup
            assert mock_build.call_count == 1
