-- ============================================================
-- Expected DB schemas for the new tool layer.
-- Run against the Rules DB unless noted otherwise.
-- Tables use CREATE TABLE IF NOT EXISTS so they are safe to
-- re-run without destroying existing data.
-- ============================================================

-- Enable trigram fuzzy matching (needed for entity resolution)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ── Rules DB tables ──────────────────────────────────────────

-- Amendment / supersession metadata
CREATE TABLE IF NOT EXISTS amendment_metadata (
    id              SERIAL PRIMARY KEY,
    standard_name   TEXT NOT NULL,         -- e.g. "Ind AS 115"
    clause_reference TEXT,                 -- e.g. "para 9" (nullable = whole standard)
    amendment_date  DATE NOT NULL,
    superseded_by   TEXT,                  -- replacement standard/clause if any
    status          TEXT NOT NULL DEFAULT 'active',  -- active | amended | superseded
    description     TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_amendment_std_clause
    ON amendment_metadata (LOWER(standard_name), LOWER(clause_reference));

-- Cross-reference / mapping between standards and clauses
CREATE TABLE IF NOT EXISTS cross_references (
    id                  SERIAL PRIMARY KEY,
    source_standard     TEXT NOT NULL,
    source_clause       TEXT NOT NULL,
    target_standard     TEXT NOT NULL,
    target_clause       TEXT NOT NULL,
    relationship_type   TEXT NOT NULL DEFAULT 'related',  -- related | amends | replaces | supplements
    confidence          FLOAT DEFAULT 1.0,  -- 1.0 for direct, <1.0 for inferred
    created_at          TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_xref_source
    ON cross_references (LOWER(source_standard), LOWER(source_clause));

-- Ratio formula definitions (optional — builtins exist in Python)
CREATE TABLE IF NOT EXISTS ratio_formulas (
    id                SERIAL PRIMARY KEY,
    ratio_name        TEXT NOT NULL UNIQUE,
    formula           TEXT NOT NULL,
    numerator_items   TEXT[] NOT NULL,      -- line-item codes
    denominator_items TEXT[] NOT NULL,
    benchmark         JSONB,               -- {"healthy": [lo, hi], "warning": [...]}
    interpretation    TEXT,
    created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Audit requirements by SA standard / topic
CREATE TABLE IF NOT EXISTS audit_requirements (
    id                SERIAL PRIMARY KEY,
    sa_standard       TEXT NOT NULL,        -- e.g. "SA 700", "SA 200"
    topic             TEXT NOT NULL,
    requirement_text  TEXT NOT NULL,
    engagement_types  TEXT[],               -- e.g. {"statutory", "limited_review"}
    created_at        TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_req_topic
    ON audit_requirements USING gin (to_tsvector('english', topic));

-- Compliance rules (per framework)
CREATE TABLE IF NOT EXISTS compliance_rules (
    id                SERIAL PRIMARY KEY,
    framework         TEXT NOT NULL,        -- IndAS | ScheduleIII | CARO
    rule_id           TEXT NOT NULL,
    description       TEXT NOT NULL,
    line_items_needed TEXT[] NOT NULL,       -- line-item codes the check requires
    check_type        TEXT NOT NULL DEFAULT 'presence',  -- presence | range | cross_check
    check_params      JSONB,               -- framework-specific parameters
    severity          TEXT NOT NULL DEFAULT 'warning',   -- pass | warning | fail
    created_at        TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_compliance_framework
    ON compliance_rules (LOWER(framework));


-- ── Reports DB tables ────────────────────────────────────────
-- (Run these against the Reports DB)

-- Entity master (canonical company info)
CREATE TABLE IF NOT EXISTS entity_master (
    entity_id       SERIAL PRIMARY KEY,
    canonical_name  TEXT NOT NULL,
    cin             TEXT,                  -- Corporate Identity Number
    industry        TEXT,
    listing_type    TEXT,                  -- listed | unlisted | psu
    aliases         JSONB DEFAULT '[]',    -- alternative names / subsidiaries
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_entity_name
    ON entity_master USING gin (canonical_name gin_trgm_ops);

-- Entity reporting framework per fiscal year
CREATE TABLE IF NOT EXISTS entity_reporting_framework (
    id                  SERIAL PRIMARY KEY,
    entity_id           INT REFERENCES entity_master(entity_id),
    fiscal_year_start   INT NOT NULL,
    fiscal_year_end     INT NOT NULL,
    framework           TEXT NOT NULL,     -- IndAS | AS | IFRS
    schedule_iii_division TEXT,            -- I | II | III
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Structured financial facts (line items with values)
CREATE TABLE IF NOT EXISTS report_facts (
    id              SERIAL PRIMARY KEY,
    doc_id          INT,                   -- FK to documents
    entity_id       INT,
    fiscal_year     INT NOT NULL,          -- fy_end year
    line_item_code  TEXT NOT NULL,
    value           NUMERIC,
    unit            TEXT DEFAULT 'INR',
    source_page     INT,
    as_of_date      DATE,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_facts_entity_fy
    ON report_facts (entity_id, fiscal_year, line_item_code);
