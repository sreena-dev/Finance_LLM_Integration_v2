"""research_agent — Standalone retrieval-grounded research agent for Indian
financial auditing built on the Yukta framework.

Usage::

    from research_agent.agents.research_agent import build_research_agent

    collector: list = []          # tool hits accumulate here
    agent = build_research_agent(collector)
    result = agent.run("Does ONGC's trade-receivable disclosure comply with Schedule III?")
    print(result["response"])
"""

__version__ = "0.1.0"
