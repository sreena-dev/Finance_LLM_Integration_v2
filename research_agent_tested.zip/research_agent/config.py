"""Configuration for the research_agent system (env-overridable).

Reads from the ``.env`` file in the project root and exports all connection
strings, embedding/LLM endpoints, and retrieval tuning constants.
"""

from __future__ import annotations

import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    # Load .env from the research_agent project root
    _env_path = Path(__file__).resolve().parent / ".env"
    load_dotenv(_env_path)
except Exception:  # python-dotenv is optional at import time
    pass

# ── Rules database (Ind AS, SA 700, CARO/CAG, EAC, Schedule III) ──────────
RULES_DB_URL = os.getenv("RULES_DB_URL")
if not RULES_DB_URL:
    raise RuntimeError("RULES_DB_URL environment variable is required. Please set it in your environment or .env file.")

# ── Reports database (company annual reports: documents / text_chunks / table_chunks) ──
ANNUAL_REPORTS_DB_URL = os.getenv("ANNUAL_REPORTS_DB_URL")
if not ANNUAL_REPORTS_DB_URL:
    raise RuntimeError("ANNUAL_REPORTS_DB_URL environment variable is required. Please set it in your environment or .env file.")

# ── Security & Authentication ──────────────────────────────────────────────
API_KEY = os.getenv("API_KEY", os.getenv("RESEARCH_AGENT_API_KEY", ""))
ALLOWED_ORIGINS = [
    o.strip() for o in os.getenv("ALLOWED_ORIGINS", "http://localhost:8000,http://127.0.0.1:8000").split(",") if o.strip()
]

# ── Embedding endpoint (bge-m3, 1024-dim) ──────────────────────────────────
EMBEDDING_URL = os.getenv("EMBEDDING_BASE_URL", "http://192.168.200.22:11450/v1/embeddings")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "bge-m3")

# ── LLM endpoint (OpenAI-compatible) ───────────────────────────────────────
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "http://10.10.116.215:30004")
LLM_ENDPOINT = os.getenv("LLM_ENDPOINT", "http://10.10.116.215:30004/v1")
LLM_MODEL_NAME = os.getenv("LLM_MODEL_NAME", "gemma-4-26b-a4b-it")

# ── Reranker endpoint ──────────────────────────────────────────────────────
RERANKER_BASE_URL = os.getenv("RERANKER_BASE_URL", "http://192.168.200.22:11451")
RERANKER_MODEL = os.getenv("RERANKER_MODEL", "bge-reranker")

# ── Retrieval tuning ──────────────────────────────────────────────────────
TOP_K = int(os.getenv("TOP_K_OVERALL", "10"))
TOP_K_PER_TABLE = int(os.getenv("TOP_K_PER_TABLE", "5"))
TOP_K_PRE_RERANK = int(os.getenv("TOP_K_PRE_RERANK", "50"))
SIMILARITY_THRESHOLD = float(os.getenv("SIMILARITY_THRESHOLD", "0.0"))

# ── Agent tuning ──────────────────────────────────────────────────────────
MAX_TOOL_ITERATIONS = int(os.getenv("MAX_TOOL_ITERATIONS", "8"))

# ── Generation defaults ───────────────────────────────────────────────────
GENERATION_MAX_OUTPUT_TOKENS = int(os.getenv("GENERATION_MAX_OUTPUT_TOKENS", "2048"))
GENERATION_TIMEOUT = int(os.getenv("GENERATION_TIMEOUT", "60"))

# ── Phoenix / OpenTelemetry tracing ──────────────────────────────────────
ENABLE_TRACING = os.getenv("ENABLE_TRACING", "false").lower() == "true"
PHOENIX_ENDPOINT = os.getenv("PHOENIX_ENDPOINT", "http://10.10.116.160:6006/v1/traces")
PHOENIX_PROJECT_NAME = os.getenv("PHOENIX_PROJECT_NAME", "research-agent")

