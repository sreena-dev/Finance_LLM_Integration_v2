"""Query Preprocessing Pipeline — rephrase → embed → intent classify → entity extract.

Runs *before* the LLM agent sees the query.  Deterministic intent classification
steers the agent toward the correct tool subset, preventing spurious ratio-table
responses for non-computation queries.

The rephrase step uses the same Gemma model configured in config.py.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

import requests

from research_agent.config import (
    EMBEDDING_URL,
    EMBEDDING_MODEL,
    LLM_ENDPOINT,
    LLM_MODEL_NAME,
)
from research_agent.embeddings import embed_query

logger = logging.getLogger("research_agent.pipeline")

# ---------------------------------------------------------------------------
# QueryContext — output of the pipeline
# ---------------------------------------------------------------------------


@dataclass
class QueryContext:
    """Structured output of the query preprocessing pipeline."""

    raw_query: str
    rephrased_query: str
    embedding: list[float] = field(default_factory=list, repr=False)
    intent: str = "GENERAL_RETRIEVAL"
    company_name: Optional[str] = None
    fiscal_year: Optional[str] = None
    tool_hints: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Step 1 — Rephrase (Gemma LLM call)
# ---------------------------------------------------------------------------

_REPHRASE_SYSTEM = (
    "You are a query rewriter for a financial auditing research system. "
    "Rewrite the user's question into a concise, retrieval-optimized search query. "
    "Keep entity names, standard references (Ind AS, SA, CARO), and fiscal years intact. "
    "Output ONLY the rewritten query, nothing else. Maximum 40 words."
)


def _rephrase_query(raw_query: str) -> str:
    """Rephrase the user query using the LLM for better retrieval with retry backoff."""
    import time
    attempts = 3
    backoff = 0.5
    url = f"{LLM_ENDPOINT}/chat/completions"
    payload = {
        "model": LLM_MODEL_NAME,
        "messages": [
            {"role": "system", "content": _REPHRASE_SYSTEM},
            {"role": "user", "content": raw_query},
        ],
        "temperature": 0.1,
        "max_tokens": 100,
    }

    for attempt in range(attempts):
        try:
            resp = requests.post(url, json=payload, timeout=15)
            resp.raise_for_status()
            rephrased = resp.json()["choices"][0]["message"]["content"].strip()
            if not rephrased or len(rephrased) > 500:
                return raw_query
            return rephrased
        except requests.exceptions.HTTPError as exc:
            if exc.response is not None and 400 <= exc.response.status_code < 500:
                logger.warning("REPHRASE_DEGRADED: HTTP %s client error during rephrase: %s", exc.response.status_code, exc)
                break
            if attempt == attempts - 1:
                logger.warning("REPHRASE_DEGRADED: Rephrase failed after HTTP error: %s", exc)
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
            if attempt == attempts - 1:
                logger.warning("REPHRASE_DEGRADED: Rephrase connection/timeout failed after retries: %s", exc)
            else:
                time.sleep(backoff)
                backoff *= 3.0
        except Exception as exc:
            logger.warning("REPHRASE_DEGRADED: Rephrase unexpected error: %s", exc)
            break

    return raw_query


# ---------------------------------------------------------------------------
# Step 2 — Embed
# ---------------------------------------------------------------------------

def _embed(text: str) -> list[float]:
    """Embed the rephrased query using bge-m3."""
    try:
        return embed_query(text)
    except Exception as exc:
        logger.debug("Embedding failed: %s", exc)
        return []


# ---------------------------------------------------------------------------
# Step 3 — Deterministic Intent Classification
# ---------------------------------------------------------------------------

# Order matters: more specific patterns checked first
_INTENT_RULES: list[tuple[str, list[str], list[str]]] = [
    # (intent_name, regex_patterns, tool_hints)
    (
        "RATIO_COMPUTATION",
        [
            r"\bratio\b", r"\bcurrent\s+ratio\b", r"\broe\b", r"\broce\b",
            r"\bdebt[\s-]to[\s-]equity\b", r"\bnet\s+profit\s+ratio\b",
            r"\binventory\s+turnover\b", r"\btrade\s+(receivable|payable)\s+turnover\b",
            r"\bdscr\b", r"\bnet\s+capital\s+turnover\b",
            r"\breturn\s+on\s+(equity|capital|investment)\b",
            r"\bschedule\s+iii\s+ratio", r"\ball.{0,10}ratio",
        ],
        ["compute_ratio_analysis"],
    ),
    (
        "COMPLIANCE_CHECK",
        [
            r"\bcompl(y|iance|ies)\b", r"\bdisclosure\s+(correct|adequate|proper)\b",
            r"\bas\s+per\b.*\b(schedule|ind\s*as|caro|sa)\b",
            r"\bmeets?\s+(the\s+)?requirement", r"\bin\s+accordance\s+with\b",
            r"\bwhether\b.*\b(correct|proper|adequate)\b",
            r"\bverif(y|ication)\b.*\bdisclosure\b",
        ],
        ["search_knowledge_base", "search_company_disclosures", "list_applicable_rules"],
    ),
    (
        "STANDARD_LOOKUP",
        [
            r"\bind\s*as\s+\d+", r"\bsa\s+\d+", r"\bcaro\s+20\d{2}\b",
            r"\bschedule\s+iii\b", r"\bwhat\s+does\b.*\bsay\b",
            r"\brequirements?\s+(under|of|for)\b",
            r"\bexplain\b.*\b(standard|ind\s*as|sa|caro)\b",
            r"\baccounting\s+standard\b",
        ],
        ["search_knowledge_base", "lookup_clause_exact", "explain_rule"],
    ),
    (
        "AUDITOR_REPORT",
        [
            r"\bauditor", r"\bqualification\b", r"\bkam\b",
            r"\bkey\s+audit\s+matter", r"\bemphasis\s+of\s+matter\b",
            r"\bgoing\s+concern\b", r"\bifc\b.*\breport\b",
            r"\binternal\s+financial\s+control",
        ],
        ["get_audit_report_highlights", "search_knowledge_base"],
    ),
    (
        "EAC_OPINION",
        [
            r"\beac\b", r"\bexpert\s+advisory\b",
            r"\bicai\b.*\b(opinion|advisory)\b",
            r"\baccounting\s+treatment\s+for\b",
        ],
        ["get_eac_opinion_by_topic", "search_knowledge_base"],
    ),
    (
        "PL_FACTS",
        [
            r"\bchanges\s+in\s+inventor", r"\brevenue\s+from\s+operation", r"\bother\s+income\b",
            r"\bcost\s+of\s+material", r"\bpurchase\s+of\s+stock\b", r"\bcatering\s+services\s+expense",
            r"\btourism\s+expense", r"\bemployee\s+benefit\s+expense", r"\bfinance\s+cost",
            r"\bdepreciation\b", r"\bexceptional\s+item", r"\btax\s+expense", r"\bprofit\s+for\s+the\s+period\b",
            r"\bearnings\s+per\s+share\b", r"\bprofit\s+and\s+loss\b", r"\bincome\s+statement\b",
        ],
        ["search_company_disclosures"],
    ),
    (
        "COMPANY_FACTS",
        [
            r"\brevenue\b", r"\bbalance\s+sheet\b", r"\bprofit\b",
            r"\bshow\s+me\b", r"\bwhat\s+is\b.*\bfor\s+fy\b",
            r"\btotal\s+assets\b", r"\bborrowing", r"\btrade\s+(receivable|payable)\b",
            r"\baccounting\s+polic(y|ies)\b", r"\bnote\s+\d+\b",
            r"\binventor(y|ies)\b", r"\bchanges\s+in\b", r"\bamount\s+shown\b",
            r"\bintangible\s+asset", r"\bproperty[\s,]+plant\b", r"\bppe\b",
            r"\bnon-current\s+asset", r"\bcurrent\s+asset", r"\bcapital\s+work",
            r"\bfinancial\s+statement", r"\brecognized\s+in\b", r"\bas\s+(on|at)\s+31",
            r"\bbalance\s+sheet\s+item", r"\bnotes?\s+to\s+(the\s+)?account",
        ],
        ["get_schedule_note", "search_company_disclosures", "get_accounting_policy_note", "lookup_report_reference"],
    ),
    (
        "GENERAL_RETRIEVAL",
        [],  # fallback — always matches
        ["search_knowledge_base", "search_company_disclosures"],
    ),
]


def _classify_intent(query: str) -> tuple[str, list[str]]:
    """Classify query intent using deterministic regex patterns.

    Returns (intent_name, tool_hints).
    """
    q_lower = query.lower()
    for intent, patterns, hints in _INTENT_RULES:
        if not patterns:
            # Fallback intent
            return intent, hints
        for pat in patterns:
            if re.search(pat, q_lower):
                return intent, hints
    return "GENERAL_RETRIEVAL", ["search_knowledge_base", "search_company_disclosures"]


# ---------------------------------------------------------------------------
# Step 4 — Entity / Fiscal Year Extraction
# ---------------------------------------------------------------------------

# Common company names found in the database
_KNOWN_COMPANIES = [
    "ONGC", "GAIL", "GAIL_India", "GAIL_Gas", "BPCL", "HPCL", "IOCL",
    "Coal India", "NTPC", "SAIL", "BHEL", "Power Grid", "NHPC",
    "Indian Oil", "Hindustan Petroleum", "IRCTC",
]

_FY_PATTERNS = [
    re.compile(r"\bFY\s*(\d{4})[\s\-–]+(\d{2,4})\b", re.IGNORECASE),
    re.compile(r"\bFY\s*(\d{4})\b", re.IGNORECASE),
    re.compile(r"\b(\d{4})[\s\-–]+(\d{2,4})\b"),
    re.compile(r"\bFY\s*(\d{2})\b", re.IGNORECASE),
    re.compile(r"\b(?:31st|31th|31)?\s*(?:March|Mar)\s*(\d{4})\b", re.IGNORECASE),
]


def _extract_entity_fy(query: str) -> tuple[Optional[str], Optional[str]]:
    """Extract company name and fiscal year from query text."""
    company = None
    for c in _KNOWN_COMPANIES:
        if re.search(re.escape(c), query, re.IGNORECASE):
            company = c
            break

    fiscal_year = None
    for pat in _FY_PATTERNS:
        m = pat.search(query)
        if m:
            fiscal_year = m.group(0)
            break

    return company, fiscal_year


# ---------------------------------------------------------------------------
# Main Pipeline Entry Point
# ---------------------------------------------------------------------------


def preprocess_query(raw_query: str) -> QueryContext:
    """Run the full preprocessing pipeline on a raw user query.

    Steps:
        1. Rephrase → retrieval-optimized query via Gemma LLM
        2. Embed → bge-m3 1024-dim vector
        3. Intent Classify → deterministic regex patterns
        4. Entity/FY Extract → regex extraction of company + fiscal year

    Returns a QueryContext with all enriched metadata.
    """
    # Step 1: Rephrase
    rephrased = _rephrase_query(raw_query)
    logger.info("Pipeline: raw=%r → rephrased=%r", raw_query, rephrased)

    # Step 2: Embed
    embedding = _embed(rephrased)

    # Step 3: Intent classify (run on BOTH raw and rephrased for best coverage)
    intent, tool_hints = _classify_intent(raw_query)
    if intent == "GENERAL_RETRIEVAL":
        # Try again on rephrased in case patterns match better
        intent2, hints2 = _classify_intent(rephrased)
        if intent2 != "GENERAL_RETRIEVAL":
            intent, tool_hints = intent2, hints2

    # Step 4: Entity / FY extraction
    company, fy = _extract_entity_fy(raw_query)

    logger.info(
        "Pipeline result: intent=%s, company=%s, fy=%s, hints=%s",
        intent, company, fy, tool_hints,
    )

    return QueryContext(
        raw_query=raw_query,
        rephrased_query=rephrased,
        embedding=embedding,
        intent=intent,
        company_name=company,
        fiscal_year=fy,
        tool_hints=tool_hints,
    )
