"""Production-Grade FastAPI Server for Research Agent.

Provides REST APIs for financial auditing research queries, system status health checks,
and 10 curated production test questions.
"""

from __future__ import annotations

import concurrent.futures
import logging
import os
import sys
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional

# Ensure both current directory and parent directory are on sys.path
_current_dir = Path(__file__).resolve().parent
_parent_dir = _current_dir.parent
if str(_current_dir) not in sys.path:
    sys.path.insert(0, str(_current_dir))
if str(_parent_dir) not in sys.path:
    sys.path.insert(0, str(_parent_dir))

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from research_agent.agents.research_agent import build_research_agent
from research_agent.config import (
    ALLOWED_ORIGINS,
    ANNUAL_REPORTS_DB_URL,
    API_KEY,
    ENABLE_TRACING,
    GENERATION_TIMEOUT,
    LLM_BASE_URL,
    LLM_MODEL_NAME,
    PHOENIX_ENDPOINT,
    PHOENIX_PROJECT_NAME,
    RULES_DB_URL,
)
from research_agent.db import get_reports_connection, get_rules_connection
from research_agent.query_pipeline import preprocess_query

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("research_agent.server")

# ---------------------------------------------------------------------------
# Phoenix / OpenTelemetry Tracing — initialise before any agent is built
# ---------------------------------------------------------------------------
try:
    from yukta import init_tracing
    _tracing_ok = init_tracing(
        endpoint=PHOENIX_ENDPOINT,
        project_name=PHOENIX_PROJECT_NAME,
        enabled=ENABLE_TRACING,
    )
    if _tracing_ok:
        logger.info("Phoenix tracing initialised → %s (project=%s)", PHOENIX_ENDPOINT, PHOENIX_PROJECT_NAME)
    else:
        logger.info("Phoenix tracing skipped (ENABLE_TRACING=%s)", ENABLE_TRACING)
except Exception as _e:
    logger.warning("Could not initialise Phoenix tracing: %s", _e)
    _tracing_ok = False

# Global agent & collector singletons created at startup
_app_agent = None
_app_collector: list = []
_agent_build_count = 0


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan event handler — builds the Research Agent ONCE at server startup."""
    global _app_agent, _app_collector, _agent_build_count
    logger.info("Building Research Agent single-instance at server startup...")
    _app_collector = []
    _app_agent = build_research_agent(collector=_app_collector, temperature=0.2)
    _agent_build_count += 1
    app.state.agent = _app_agent
    app.state.collector = _app_collector
    app.state.build_count = _agent_build_count
    yield
    logger.info("Server shutting down...")


app = FastAPI(
    title="Research Agent — Financial Audit Intelligence",
    description="Hi! This is a Financial auditor assistant tool to assist in audit related queries related to Ind AS, Schedule III, EAC Opinions, CARO 2020, SA 700 and from Annual reports.",
    version="1.0.0",
    lifespan=lifespan,
)

# Explicit CORS origins
origins = ALLOWED_ORIGINS if ALLOWED_ORIGINS else ["http://localhost:8000", "http://127.0.0.1:8000"]
allow_credentials = "*" not in origins

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=allow_credentials,
    allow_methods=["*"],
    allow_headers=["*"],
)


def verify_api_key(request: Request):
    """Enforce X-API-Key header authentication if API_KEY is configured in env."""
    if API_KEY:
        header_key = request.headers.get("X-API-Key") or request.headers.get("x-api-key")
        if not header_key or header_key != API_KEY:
            raise HTTPException(
                status_code=401,
                detail="Unauthorized: Invalid or missing X-API-Key header.",
            )


# ---------------------------------------------------------------------------
# Request / Response Schemas
# ---------------------------------------------------------------------------


class QueryRequest(BaseModel):
    query: str = Field(..., example="Does ONGC's trade-receivable disclosure comply with Schedule III?")
    temperature: float = Field(0.2, ge=0.0, le=1.0)


class QueryResponse(BaseModel):
    query: str
    response: str
    sources: List[Dict[str, Any]]
    tools_used: List[Dict[str, Any]]
    execution_time_seconds: float


# ---------------------------------------------------------------------------
# 10 Curated Production Test Questions
# ---------------------------------------------------------------------------

# PRODUCTION_TEST_QUESTIONS = [
#     {
#         "id": "q1",
#         "category": "Schedule III & Presentation",
#         "title": "ONGC Trade Receivables Ageing & Impairment",
#         "query": "Does ONGC's trade-receivable disclosure comply with Schedule III requirements regarding ageing and impairment?",
#         "description": "Evaluates trade receivables ageing schedule, expected credit loss (ECL) disclosures, and Schedule III Part I balance sheet presentation.",
#         "badge": "Schedule III",
#         "target_company": "ONGC",
#         "tools_highlight": ["fetch_fs_tables", "search_schedule_iii", "search_annual_reports"]
#     },
#     {
#         "id": "q2",
#         "category": "Ind AS Standard Accounting",
#         "title": "BPCL Lease Accounting (Ind AS 116)",
#         "query": "How does BPCL account for right-of-use (ROU) assets and lease liabilities under Ind AS 116?",
#         "description": "Verifies recognition, measurement, discount rate application, and balance sheet classification of leases.",
#         "badge": "Ind AS 116",
#         "target_company": "BPCL",
#         "tools_highlight": ["get_accounting_policy", "search_ind_as", "fetch_fs_tables"]
#     },
#     {
#         "id": "q3",
#         "category": "CARO 2020 & Audit Trail",
#         "title": "Rule 11(g) Audit Trail & Edit Log Compliance",
#         "query": "What are the auditor's reporting responsibilities regarding accounting software edit logs under Rule 11(g) of Companies (Audit and Auditors) Rules?",
#         "description": "Cross-references CARO 2020 Clause 3(i) and Rule 11(g) audit trail requirements with company disclosures.",
#         "badge": "CARO 2020 / Rule 11(g)",
#         "target_company": "General / All",
#         "tools_highlight": ["search_caro_directions", "search_rule_corpus", "get_audit_opinion"]
#     },
#     {
#         "id": "q4",
#         "category": "EAC Opinion & Guidance",
#         "title": "Grant Recognition Accounting Treatment (ICAI EAC)",
#         "query": "What accounting treatment has IRCTC adopted for government grants related to revenue expenditure, and how does it compare with ICAI EAC opinions?",
#         "description": "Searches ICAI Expert Advisory Committee opinions and compares with company notes to accounts.",
#         "badge": "EAC Opinion",
#         "target_company": "IRCTC",
#         "tools_highlight": ["search_eac_opinions", "get_accounting_policy", "compare_frameworks"]
#     },
#     {
#         "id": "q5",
#         "category": "Financial Statement & Ratio Analysis",
#         "title": "IOCL Inventory Valuation & Debt Service Coverage",
#         "query": "What is IOCL's inventory valuation method and what is its Debt Service Coverage Ratio for FY 2023-24?",
#         "description": "Retrieves Inventory note disclosures and computes deterministic DSCR financial ratio.",
#         "badge": "Ratio Analysis",
#         "target_company": "IOCL",
#         "tools_highlight": ["get_accounting_policy", "compute_financial_ratios", "search_annual_reports"]
#     },
#     {
#         "id": "q6",
#         "category": "Statutory Audit Opinion (SA 700)",
#         "title": "GAIL Key Audit Matters & Qualification Check",
#         "query": "Did GAIL receive a clean audit opinion or qualified opinion for FY 2023-24? Summarise Key Audit Matters (KAM).",
#         "description": "Extracts Independent Auditor's Report sections, Emphasis of Matter, and KAMs per SA 700.",
#         "badge": "SA 700",
#         "target_company": "GAIL",
#         "tools_highlight": ["get_audit_opinion", "search_annual_reports"]
#     },
#     {
#         "id": "q7",
#         "category": "P&L Line Item Breakdown",
#         "title": "NTPC Employee Benefit Expense & Finance Costs",
#         "query": "What are the total Employee Benefit Expenses and Finance Costs reported by NTPC for FY 2023-24?",
#         "description": "Fetches P&L note disclosures and sub-item breakdowns for employee costs and interest expenses.",
#         "badge": "P&L Analysis",
#         "target_company": "NTPC",
#         "tools_highlight": ["fetch_fs_tables", "search_annual_reports"]
#     },
#     {
#         "id": "q8",
#         "category": "CAG Supplementary Audit",
#         "title": "CAG Audit Directions for Central Public Sector Enterprises",
#         "query": "What specific directions has CAG issued regarding physical verification of fixed assets under Section 143(5)?",
#         "description": "Queries CAG sub-audit directions, CARO cross-references, and CPSE supplementary audit guidelines.",
#         "badge": "CAG Directions",
#         "target_company": "CPSEs",
#         "tools_highlight": ["search_caro_directions", "search_rule_corpus"]
#     },
#     {
#         "id": "q9",
#         "category": "Impairment & Provisions",
#         "title": "HPCL Property, Plant & Equipment Impairment (Ind AS 36)",
#         "query": "Has HPCL recognized any impairment loss on Property, Plant & Equipment under Ind AS 36 during FY 2023-24?",
#         "description": "Cross-references Ind AS 36 impairment testing disclosures with HPCL balance sheet note tables.",
#         "badge": "Ind AS 36",
#         "target_company": "HPCL",
#         "tools_highlight": ["get_accounting_policy", "fetch_fs_tables", "search_ind_as"]
#     },
#     {
#         "id": "q10",
#         "category": "Framework Comparison",
#         "title": "Ind AS 115 Revenue vs Old AS 9 Revenue Recognition",
#         "query": "Compare the revenue recognition criteria for performance obligations under Ind AS 115 vs AS 9.",
#         "description": "Performs side-by-side regulatory rule comparison between Ind AS 115 and legacy Accounting Standard 9.",
#         "badge": "Rule Comparison",
#         "target_company": "Regulatory Corpus",
#         "tools_highlight": ["compare_frameworks", "search_ind_as", "search_rule_corpus"]
#     }
# ]


# ---------------------------------------------------------------------------
# Health & Status Endpoints
# ---------------------------------------------------------------------------


@app.get("/api/health")
def check_health():
    """Health check endpoint checking DB pool connectivity and endpoints."""
    rules_ok = False
    reports_ok = False
    try:
        with get_rules_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                rules_ok = cur.fetchone()[0] == 1
    except Exception as e:
        logger.warning("Rules DB health check failed: %s", e)

    try:
        with get_reports_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                reports_ok = cur.fetchone()[0] == 1
    except Exception as e:
        logger.warning("Reports DB health check failed: %s", e)

    status = "healthy" if (rules_ok and reports_ok) else "degraded"
    return {
        "status": status,
        "agent_build_count": _agent_build_count,
        "rules_db": "connected" if rules_ok else "error",
        "reports_db": "connected" if reports_ok else "error",
        "llm_model": LLM_MODEL_NAME,
        "llm_endpoint": LLM_BASE_URL,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }


# @app.get("/api/questions")
# def get_questions():
#     """Returns the 10 curated production test questions."""
#     return {"questions": PRODUCTION_TEST_QUESTIONS}


@app.get("/api/status")
def get_status():
    """Compatibility alias for /api/health."""
    return check_health()


@app.get("/api/tools")
def get_tools(request: Request, _auth: None = Depends(verify_api_key)):
    """Return basic metadata for the registered research tools."""
    try:
        from research_agent.tools.research_tools import build_research_tools
        tools = build_research_tools(collector=[])
        tools_meta = []
        for t in tools:
            meta = {
                "name": getattr(t, "name", str(t)),
                "description": getattr(t, "description", ""),
                "parameters": getattr(t, "parameters", []),
            }
            tools_meta.append(meta)
        return {"tools": tools_meta}
    except Exception as e:
        logger.exception("Failed to build tools metadata: %s", e)
        raise HTTPException(status_code=500, detail=f"Cannot enumerate tools: {e}")


@app.post("/api/query", response_model=QueryResponse)
def execute_query(req: QueryRequest, request: Request, _auth: None = Depends(verify_api_key)):
    """Executes a financial research query using the pre-built single-instance Research Agent.

    Per-request: resets collector without rebuilding agent/LLM client.
    Enforces a bounded execution timeout.
    """
    query = req.query.strip()
    if not query:
        raise HTTPException(status_code=400, detail="Query cannot be empty.")

    logger.info("Executing query: %s (temperature=%.2f)", query, req.temperature)
    start_time = time.time()

    # --- Query Preprocessing Pipeline ---
    try:
        ctx = preprocess_query(query)
        logger.info(
            "Pipeline: intent=%s, company=%s, fy=%s, hints=%s",
            ctx.intent, ctx.company_name, ctx.fiscal_year, ctx.tool_hints,
        )
    except Exception as exc:
        logger.warning("Pipeline preprocessing failed (%s), using raw query", exc)
        from research_agent.query_pipeline import QueryContext
        ctx = QueryContext(raw_query=query, rephrased_query=query)

    hint_str = ", ".join(ctx.tool_hints) if ctx.tool_hints else "search_knowledge_base"
    augmented_query = (
        f"[Intent: {ctx.intent}] [Recommended tools: {hint_str}]\n"
        f"{ctx.rephrased_query}"
    )

    # Use single-instance agent and reset per-request collector
    agent = getattr(app.state, "agent", _app_agent)
    collector = getattr(app.state, "collector", _app_collector)
    if agent is None:
        collector = []
        agent = build_research_agent(collector=collector, temperature=req.temperature)

    # Clear collector for current turn
    collector.clear()

    try:
        # Bounded execution with explicit timeout
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(agent.run, augmented_query)
            result = future.result(timeout=GENERATION_TIMEOUT)

        elapsed = time.time() - start_time
        response_text = result.get("response", "") if isinstance(result, dict) else str(result)

        formatted_sources = []
        tools_used = []
        seen_tool_names = set()
        seen_source_keys = set()

        for item in list(collector):
            if "tool" in item and "result" in item:
                tool_name = item["tool"]
                result_env = item["result"]
                if tool_name not in seen_tool_names:
                    seen_tool_names.add(tool_name)
                    tools_used.append({
                        "tool_name": tool_name,
                        "timestamp": item.get("timestamp") or time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
                        "status": result_env.get("status", "completed"),
                        "confidence": result_env.get("confidence"),
                        "confidence_basis": result_env.get("confidence_basis", ""),
                        "arguments": item.get("arguments", {}),
                        "output": result_env,
                        "sources": result_env.get("sources", [])
                    })

                for src in result_env.get("sources", []):
                    doc_id = src.get("doc_id", "")
                    page = src.get("page")
                    clause_ref = src.get("clause_ref", "")
                    sk = f"{doc_id}_{page}_{clause_ref}"
                    if sk not in seen_source_keys:
                        seen_source_keys.add(sk)
                        formatted_sources.append({
                            "source": tool_name,
                            "doc_id": doc_id,
                            "page": page,
                            "clause_ref": clause_ref,
                            "as_of_date": src.get("as_of_date"),
                        })
            else:
                cid = f"{item.get('source', '')}_{item.get('chunk_id', '')}_{item.get('doc_id', '')}_{item.get('section_title', '')}"
                if cid not in seen_source_keys:
                    seen_source_keys.add(cid)
                    formatted_sources.append(item)

        if not tools_used:
            source_types = {s.get("source") for s in formatted_sources if s.get("source")}
            for st in source_types:
                tools_used.append({"name": f"retrieval_{st}", "status": "completed"})

        return QueryResponse(
            query=query,
            response=response_text,
            sources=formatted_sources,
            tools_used=tools_used,
            execution_time_seconds=round(elapsed, 2),
        )

    except concurrent.futures.TimeoutError:
        logger.error("Agent execution timed out after %ds for query: %s", GENERATION_TIMEOUT, query)
        raise HTTPException(
            status_code=504,
            detail=f"Agent execution timed out after {GENERATION_TIMEOUT}s. Please try a simpler query.",
        )
    except Exception as e:
        logger.exception("Error executing agent query: %s", e)
        raise HTTPException(status_code=500, detail=f"Agent execution failed: {str(e)}")


# ---------------------------------------------------------------------------
# Static Files & SPA Mounting
# ---------------------------------------------------------------------------

static_path = _current_dir / "static"
if not static_path.exists():
    static_path.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(static_path)), name="static")


@app.get("/", response_class=HTMLResponse)
def read_root():
    """Serves the main UI SPA."""
    index_file = static_path / "index.html"
    if index_file.exists():
        return HTMLResponse(content=index_file.read_text(encoding="utf-8"))
    return HTMLResponse(content="<h1>Research Agent API is running. index.html pending building.</h1>")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
